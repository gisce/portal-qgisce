# coding=utf-8
""""Small utilities for common operations

.. note:: This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

"""

__author__ = 'elpaso@itopen.it'
__date__ = '2019-02-05'
__copyright__ = 'Copyright 2019, GISCE'



from qgis.core import QgsExpression, QgsFeatureRequest


def get_feature_by_erp_id(layer, erp_id):
    """Search a layer for a feature with the give erp_id and returns
    that feature, it may raise IndexError if the feature is not found.

    :param layer: search layer
    :type layer: QgsVectorLayer instance
    :param erp_id: the ERP id
    :type erp_id: int
    :return: the feature with the given ERP id
    :rtype: QgsFeature instance
    :raise: IndexError
    """

    return [f for f in layer.getFeatures(QgsFeatureRequest(QgsExpression("\"id\" = %s" % erp_id)))][0]
