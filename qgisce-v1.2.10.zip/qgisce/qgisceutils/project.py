# coding=utf-8
"""QGIS Project related functions: connections to logger ans sync plus Koo form
on new features.


.. note:: This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

"""

__author__ = 'elpaso@itopen.it'
__date__ = '2018-05-29'
__copyright__ = 'Copyright 2018, GISCE-TI S.L.'


import ast
import json
import os
from collections import OrderedDict
from shutil import copyfile

from pyplugin_installer.version_compare import compareVersions
from qgis.core import QgsProject, QgsRectangle, QgsSettings

from .literals import *


def catalog_id_for_layer(layer):
    """Checks whether the given layer is managed by QGISCE plugin and return
    the catalog id (or None)

    :param layer: the layer to be checked
    :type layer: QgsVectorLayer
    :return: the catalog id if the layer is managed by QGISCE plugin, None if
    it is not
    :rtype: int or None
    """
    try:
        return int(layer.customProperty(QGISCE_LAYER_CUSTOM_PROPERTY_CATALOG_ID))
    except (TypeError, RuntimeError):
        return None


def field_mapping_for_layer(layer):
    """Checks whether the given layer is managed by QGISCE plugin and return
    the field mapping (or [])

    :param layer: the layer to be checked
    :type layer: QgsVectorLayer
    :return: the field_mapping the layer is managed by QGISCE plugin, or an
    empty list if it is not
    :rtype: list of dictionaries
    """
    try:
        field_mapping = json.JSONDecoder(
            object_pairs_hook=OrderedDict).decode(
            layer.customProperty(QGISCE_LAYER_CUSTOM_PROPERTY_FIELD_MAPPING)
        )
    except (SyntaxError, ValueError, TypeError):
        field_mapping = []

    return field_mapping


def managed_layers():
    """Scan current project for layers that are managed by QGISCE plugin

    :return: the layers managed by QGISCE plugin
    :rtype: dictionary of QgsVectorLayer keyed by catalog_id
    """
    return {catalog_id_for_layer(v): v for k, v in QgsProject.instance().mapLayers().items() if catalog_id_for_layer(v) is not None}

def search_result_layers():
    """
    Scan current project for layers that are the result of a Qgisce Search Bar
    :return: the layers that are the result of the Qgisce Search Bar
    :rtype: list of QgsVectorLayer
    """

    ret = [
        value for key, value in QgsProject.instance().mapLayers().items()
        if value.customProperty("search_result_layer")
    ]
    return ret

def search_custom_cartography_layers():
    """
    Scan current project for layers that are custom cartography
    :return: the layers that are custom cartography
    :rtype: list of QgsRasterLayer
    """

    return QgsProject.instance().mapLayersByName('Custom Cartography')

def model_for_layer(layer):
    """Checks whether the given layer is managed by QGISCE plugin and return
    the model (or None)

    :param layer: the layer to be checked
    :type layer: QgsVectorLayer
    :return: the model internal name if the layer is managed by QGISCE plugin,
    None if it is not
    :rtype: string or None
    """
    return layer.customProperty(QGISCE_LAYER_CUSTOM_PROPERTY_MODEL_INTERNAL_NAME)


def model_id_for_layer(layer):
    """Checks whether the given layer is managed by QGISCE plugin and return
    the model_id (or None)

    :param layer: the layer to be checked
    :type layer: QgsVectorLayer
    :return: the model id if the layer is managed by QGISCE plugin, None if it
    is not
    :rtype: int or None
    """
    model_id = layer.customProperty(QGISCE_LAYER_CUSTOM_PROPERTY_MODEL_ID)
    return int(model_id) if model_id is not None else None


def style_name_for_layer(layer):
    """Checks whether the given layer is managed by QGISCE plugin and return
    the style name (or None)

    :param layer: the layer to be checked
    :type layer: QgsVectorLayer
    :return: the style name if the layer is managed by QGISCE plugin, None if
    it is not or style_name is not set
    :rtype: string or None
    """
    return layer.customProperty(QGISCE_LAYER_CUSTOM_PROPERTY_STYLE_NAME)


def not_topology_for_layer(layer):
    """Checks whether the given layer is managed by QGISCE plugin and return
    the not_topology flag (or None)

    :param layer: the layer to be checked
    :type layer: QgsVectorLayer
    :return: the not_topology flag if the layer is managed by QGISCE plugin, None if
    it is not or not_topology is not set
    :rtype: bool or None
    """
    value = layer.customProperty(QGISCE_LAYER_CUSTOM_PROPERTY_NOT_TOPOLOGY)
    if value is None:
        return value
    return layer.customProperty(QGISCE_LAYER_CUSTOM_PROPERTY_NOT_TOPOLOGY) == 'true'


def read_only_for_layer(layer):
    """Checks whether the given layer is managed by QGISCE plugin and return
    the read_only flag (or None)

    :param layer: the layer to be checked
    :type layer: QgsVectorLayer
    :return: the read_only flag if the layer is managed by QGISCE plugin, None if
    it is not or read_only is not set
    :rtype: bool or None
    """
    return layer.customProperty(QGISCE_LAYER_CUSTOM_PROPERTY_READ_ONLY) == 'true'


def snap_to_for_layer(layer):
    """Return the snap_to layer catalog id (or None if not set of if not managed)

    :param layer: the layer to be checked
    :type layer: QgsVectorLayer
    :return: the list of snap_to layer catalog ids if the layer is managed by QGISCE plugin, None if
    it is not or snap_to is not set
    :rtype: list or None
    """
    value = layer.customProperty(QGISCE_LAYER_CUSTOM_PROPERTY_SNAP_TO)
    if value is None:
        return None
    try:
        return json.loads(value)
    except:
        return []


def z_index_for_layer(layer):
    """Checks whether the given layer is managed by QGISCE plugin and return
    the z_index (or None)

    :param layer: the layer to be checked
    :type layer: QgsVectorLayer
    :return: the z index if the layer is managed by QGISCE plugin, None if
    it is not or z index is not set
    :rtype: integer or None
    """
    try:
        return int(layer.customProperty(QGISCE_LAYER_CUSTOM_PROPERTY_Z_INDEX))
    except TypeError:
        return None


def symbol_name_for_layer(layer):
    """Checks whether the given layer is managed by QGISCE plugin and return
    the symbol name (or None)

    :param layer: the layer to be checked
    :type layer: QgsVectorLayer
    :return: the symbol name if the layer is managed by QGISCE plugin, None if
    it is not or symbol name is not set
    :rtype: string or None
    """
    return layer.customProperty(QGISCE_LAYER_CUSTOM_PROPERTY_SYMBOL_NAME)


def model_name_for_layer(layer):
    """Checks whether the given layer is managed by QGISCE plugin and return
    the model descriptive name (or None)

    :param layer: the layer to be checked
    :type layer: QgsVectorLayer
    :return: the model descriptive name if the layer is managed by QGISCE
    plugin, None if it is not
    :rtype: string or None
    """
    return layer.customProperty(QGISCE_LAYER_CUSTOM_PROPERTY_MODEL_DESCRIPTIVE_NAME)


def domain_for_layer(layer):
    """Checks whether the given layer is managed by QGISCE plugin and return
    the domain filter condition

    :param layer: the layer to be checked
    :type layer: QgsVectorLayer
    :return: the domain filter condition if the layer is managed by QGISCE
    plugin, an empty list in case it's not
    :rtype: list
    """
    try:
        domain = ast.literal_eval(layer.customProperty(
            QGISCE_LAYER_CUSTOM_PROPERTY_DOMAIN))
    except (SyntaxError, ValueError):
        domain = []

    return domain


def layers_for_model(model_name):
    """Search for managed layers for the given model_name  and returns them

    :type model_name: string
    :return: the layers managed by QGISCE plugin for the given model
    :rtype: list of QgsVectorLayer
    """
    return [l for l in managed_layers().values() if model_for_layer(l) == model_name]


def layer_for_catalog_id(catalog_id):
    """Search for managed layers for the given model_name  and returns them

    :param catalog_id:
    :type model_name: string
    :return: the layers managed by QGISCE plugin for the given model
    :rtype: QgsVectorLayer or None
    """
    return managed_layers().get(catalog_id, None)


def bbox_for_layer(layer):
    """Checks whether the given layer is managed by QGISCE plugin and return
    the bbox (or None)

    :param layer: the layer to be checked
    :type layer: QgsVectorLayer
    :return: the bounding box if the layer is managed by QGISCE plugin, an
    empty BBOX if its is not
    :rtype: QgsRectangle
    """
    polygon_wkt = layer.customProperty(QGISCE_LAYER_CUSTOM_PROPERTY_BBOX, None)
    if not polygon_wkt:
        return QgsRectangle()
    else:
        return QgsRectangle.fromWkt(polygon_wkt)


def fields_for_layer(layer):
    """Checks whether the given layer is managed by QGISCE plugin and return
    the fields (or None)

    :param layer: the layer to be checked
    :type layer: QgsVectorLayer
    :return: the fields list if the layer is managed by QGISCE plugin, an
    empty list if its is not
    :rtype: list
    """
    try:
        fields = json.JSONDecoder(
            object_pairs_hook=OrderedDict).decode(
            layer.customProperty(QGISCE_LAYER_CUSTOM_PROPERTY_FIELDS)
        )
    except (SyntaxError, ValueError, TypeError):
        fields = []

    return fields


def layer_set_managed(layer, layer_specs):
    """Adopt this layer by setting QGISCE custom properties

    :param layer: vector layer to adopt
    :type layer: QgsVectorLayer
    :param layer_specs: layer specifications
    :type layer_specs: LayerSpecs
    """
    layer.setCustomProperty(
        QGISCE_LAYER_CUSTOM_PROPERTY_MODEL_ID, layer_specs.model_id)
    layer.setCustomProperty(
        QGISCE_LAYER_CUSTOM_PROPERTY_MODEL_INTERNAL_NAME, layer_specs.model)
    layer.setCustomProperty(
        QGISCE_LAYER_CUSTOM_PROPERTY_MODEL_DESCRIPTIVE_NAME, layer_specs.model_name)
    layer.setCustomProperty(
        QGISCE_LAYER_CUSTOM_PROPERTY_DOMAIN, str(layer_specs.domain))
    layer.setCustomProperty(QGISCE_LAYER_CUSTOM_PROPERTY_FIELDS, json.dumps(
        layer_specs.fields))
    layer.setCustomProperty(QGISCE_LAYER_CUSTOM_PROPERTY_FIELD_MAPPING, json.dumps(
        layer_specs.field_mapping))
    layer.setCustomProperty(
        QGISCE_LAYER_CUSTOM_PROPERTY_CATALOG_ID, layer_specs.catalog_id)
    layer.setCustomProperty(
        QGISCE_LAYER_CUSTOM_PROPERTY_STYLE_NAME, layer_specs.style_name)
    layer.setCustomProperty(
        QGISCE_LAYER_CUSTOM_PROPERTY_SYMBOL_NAME, layer_specs.symbol_name)
    layer.setCustomProperty(
        QGISCE_LAYER_CUSTOM_PROPERTY_BBOX, layer_specs.bbox.asWktPolygon(
        ) if layer_specs.bbox is not None else QgsRectangle().asWktPolygon())
    layer.setCustomProperty(
        QGISCE_LAYER_CUSTOM_PROPERTY_Z_INDEX, layer_specs.z_index)
    layer.setCustomProperty(
        QGISCE_LAYER_CUSTOM_PROPERTY_NOT_TOPOLOGY, 'true' if layer_specs.not_topology else 'false')
    layer.setCustomProperty(
        QGISCE_LAYER_CUSTOM_PROPERTY_READ_ONLY, 'true' if layer_specs.read_only else 'false')
    layer.setCustomProperty(
        QGISCE_LAYER_CUSTOM_PROPERTY_SNAP_TO, json.dumps(layer_specs.snap_to) if layer_specs.snap_to is not None else '[]')


def layer_set_loading_completed(layer, loading_completed):
    """Set the loading_completed status when loading was successfull

    :param layer: vector layer to set
    :type layer: QgsVectorLayer
    :param loading_completed: boolean flag
    :type loading_completed: bool
    """
    layer.setCustomProperty(
        QGISCE_LAYER_CUSTOM_PROPERTY_LOADING_COMPLETED, loading_completed)


def layer_loading_completed(layer):
    """Get the loading_completed status

    :param layer: vector layer to set
    :type layer: QgsVectorLayer
    :return: True if layer was successfully loaded
    :rtype: bool
    """
    return layer.customProperty(
        QGISCE_LAYER_CUSTOM_PROPERTY_LOADING_COMPLETED,
        False
    )


def project_set_catalog_autoload():
    """Set a flag in the project that will trigger a catalog load when project is opened"""
    QgsProject.instance().setCustomVariables(
        {QGISCE_PROJECT_VARIABLE_CATALOG_AUTOLOAD: True})


def project_catalog_autoload():
    """Checks whether the current project is managed by the plugin and
    autoload is active

    :return: true if the project is managed by QGISCE plugin
    :rtype: bool
    """
    custom_vars = QgsProject.instance().customVariables()
    return custom_vars.get(QGISCE_PROJECT_VARIABLE_CATALOG_AUTOLOAD) == 'true'


def project_get_template_version():
    """Return the project's QGISCE template version

    :return: the QGISCE project template version
    :rtype: str
    """

    custom_vars = QgsProject.instance().customVariables()
    return custom_vars.get(QGISCE_PROJECT_VARIABLE_TEMPLATE_VERSION, None)


def project_template_is_newer(template_path=None):
    """Checks whether the default template version is newer than
    the version of the template the current project is based on

    :param template_path: template path for testing purposes only, defaults to None and will be automatically filled with current template path.
    :param template_path: str, optional
    :return: true if the template is newer
    :rtype: bool
    """

    assert template_path is None or os.environ.get('CI', False)
    current_version = project_get_template_version()
    if template_path is None:  # Not None is for testing only!!!
        resource_path = os.path.join(os.path.dirname(
            __file__), os.path.pardir, 'resources')
        template_path = os.path.join(
            resource_path, 'qgisce_project_template.qgs')
    prj = QgsProject()
    prj.read(template_path)
    available_version = prj.customVariables().get(
        QGISCE_PROJECT_VARIABLE_TEMPLATE_VERSION, None)
    if available_version is None:
        return False
    if current_version is None:
        return True
    return compareVersions(available_version, current_version) == 1


def project_setup_default_project():
    """
    Setup QGIS to automatically open the default QGISCE template project at
    start

    :return:
    """
    QgsSettings().setValue("/qgis/projOpenAtLaunch", 2)  # Specific
    # Make a copy of the template
    resource_path = os.path.join(os.path.dirname(
        __file__), os.path.pardir, 'resources')
    template_path = os.path.join(resource_path, 'qgisce_project_template.qgs')
    project_path = os.path.join(resource_path, 'qgisce_project.qgs')
    i = 0
    while os.path.exists(project_path):
        project_path = os.path.join(resource_path, 'qgisce_project_%s.qgs' % i)
        i += 1
    copyfile(template_path, project_path)
    QgsSettings().setValue("/qgis/projOpenAtLaunchPath", project_path)
    return project_path


def project_is_using_qgisce_template():
    """Checks whether current project is using a QGISCE template

    """

    custom_vars = QgsProject.instance().customVariables()
    return (custom_vars.get(QGISCE_PROJECT_VARIABLE_CATALOG_AUTOLOAD) is not None) or \
        custom_vars.get(QGISCE_PROJECT_VARIABLE_TEMPLATE_VERSION) is not None
