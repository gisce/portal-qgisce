# coding=utf-8
"""QGISCE Layer specification


.. note:: This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

"""

__author__ = 'elpaso@itopen.it'
__date__ = '2018-06-15'
__copyright__ = 'Copyright 2018, GISCE-TI S.L.'

from .project import *
from .erp_client import ERPClient
from qgis.core import QgsRectangle, QgsCoordinateReferenceSystem


class LayerSpecs():
    """Information about a QGISCE layer

    This class encapsulate the information about a catalog entry coming from
    the catalog and all what is needed to create the layer
    """

    @classmethod
    def from_layer(cls, layer):
        """Factory method to extract QGISCE layer information from an
        existing layer

        style information is not stored in the layer and it is not
        necessary in this context because the layer already exists

        :param layer: an existing layer
        :type layer: QgsVectorLayer
        :return: layer information
        :rtype: LayerSpecs
        """

        catalog_id = catalog_id_for_layer(layer)
        model_name = model_name_for_layer(layer)
        not_topology = not_topology_for_layer(layer)
        model = model_for_layer(layer)
        model_id = model_id_for_layer(layer)
        domain = domain_for_layer(layer)
        bbox = bbox_for_layer(layer)
        z_index = z_index_for_layer(layer)
        fields = fields_for_layer(layer)
        # Remove geom filters from domain
        domain = [d for d in domain if d[0] != 'geom']
        field_mapping = field_mapping_for_layer(layer)
        symbol_name = symbol_name_for_layer(layer)
        style_name = style_name_for_layer(layer)
        read_only = read_only_for_layer(layer)
        snap_to = snap_to_for_layer(layer)
        return LayerSpecs(
            catalog_id, layer.name(), model_name, model, model_id, domain,
            layer.wkbType(), fields, field_mapping, layer.crs(),
            symbol_name, style_name, bbox, z_index, not_topology, read_only, snap_to
        )

    def __init__(self,
        catalog_id,
        layer_name,
        model_name,
        model,
        model_id,
        domain,
        geometry_type,
        fields,
        field_mapping,
        crs,
        symbol_name,
        style_name,
        bbox=QgsRectangle(),
        z_index=0,
        not_topology=True,
        read_only=False,
        snap_to=[]
        ):
        """[summary]

        :param catalog_id: primary key of the catalog entry
        :type catalog_id: int
        :param name: Layer name
        :type name: str
        :param model_name: the model descriptive name, for example:
        "Escomeses"
        :type model_name: str
        :param model: the model name, for example: "giscedata.cups.escomesa"
        :type model: str
        :param model_id: the model id
        :type model: int
        :param domain: query that contains the filter to get layer data from
        erp
        :type domain: list
        :param geometry_type: Layer geometry type
        :type geometry_type: QgsWkbTypes
        :param fields: a list of the additional fields
        :type fields: list
        :param field_mapping: an ordered dictionary describing the field types
        :type field_mapping: OrderedDicts
        :param crs: Layer's CRS
        :type crs: str
        :param symbol_name: name of the symbol SVG file
        :type symbol_name: str
        :param style_name: name of the style QML file
        :type style_name: str
        :param bbox: bounding box of the features to accept in layer's CRS,
        default to an empty QgsRectangle (accept all features in that case)
        :param bbox: QgsRectangle
        :param z_index: Z index, optional, default to 0
        :type z_index: int
        :param not_topology: not_topology flag, optional, default to True
        :type not_topology: bool
        :param read_only: flag, optional, default to False
        :type read_only: bool
        :param snap_to: catalog ids of the layers to snap to, optional, default to an empty list
        :type snap_to: list of int, or None

        """

        self.catalog_id = catalog_id
        self.layer_name = layer_name
        self.model_name = model_name
        assert isinstance(domain, list)
        self.domain = domain
        self.model = model
        self.model_id = model_id
        self.geometry_type = geometry_type
        self.fields = fields
        self.field_mapping = field_mapping
        assert isinstance(crs, QgsCoordinateReferenceSystem)
        self.crs = crs
        self.symbol_name = symbol_name
        self.style_name = style_name
        self.bbox = bbox
        self.z_index = z_index
        self.not_topology = not_topology
        self.read_only = read_only
        self.snap_to = snap_to

    def __repr__(self):
        return "<LayerSpecs %s %s #%s>" % \
               (self.layer_name, self.model_name, self.catalog_id)

    def _compare(self, other):
        """Check if objects are equal"""
        diffs = []
        if isinstance(other, LayerSpecs):
            for attr in ('catalog_id', 'layer_name', 'domain', 'model', 'model_id', 'geometry_type', 'fields', 'field_mapping', 'crs', 'symbol_name', 'style_name', 'bbox', 'z_index', 'not_topology', 'read_only', 'snap_to'):
                if not getattr(self, attr) == getattr(other, attr):
                    diffs.append(
                        (attr, getattr(self, attr), getattr(other, attr))
                    )
        return diffs

    def __eq__(self, other):
        """Overrides the default implementation"""
        if isinstance(other, LayerSpecs):
            return len(self._compare(other)) == 0
        return False
