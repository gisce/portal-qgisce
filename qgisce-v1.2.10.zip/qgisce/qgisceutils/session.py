# coding=utf-8
"""QGIS Session related functions, exceptions are raised


.. note:: This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

"""

__author__ = 'elpaso@itopen.it'
__date__ = '2018-06-26'
__copyright__ = 'Copyright 2018, GISCE-TI S.L.'

import os
import json
import base64

from enum import Enum
from qgis.utils import iface
from qgis.core import QgsRectangle, QgsGeometry, QgsProject, QgsFeatureRequest, QgsExpression, Qgis, QgsWkbTypes, QgsApplication
from qgis.PyQt import QtCore, QtWidgets

# FIXME: this is a server bug, remove when fixed
from xmlrpc.client import Fault

from qgisceutils.erp_client import ERPClient, ERPClientException
from qgisceutils.i18n import tr
from qgisceutils.literals import *
from qgiscegui.utils import create_snapshot, message_log
from qgisceutils.utils import get_feature_by_erp_id
from qgisceutils.project import layers_for_model, fields_for_layer

PREVIEW_IMAGE_SIZE = 300

class SessionError(Exception):
    """Base exception for session errors"""
    pass


class SessionSearchError(SessionError):
    pass


class SessionReadError(SessionError):
    pass


class SessionCreationError(SessionError):
    pass


class SessionUpdateError(SessionError):
    pass


class SessionDiscardError(SessionError):
    pass


class SessionDiscardChangesError(SessionError):
    pass


class SessionConfirmChangesError(SessionError):
    pass


class SessionDeleteError(SessionError):
    pass


class SessionMergeError(SessionError):
    pass


class SessionRequiredError(SessionError):
    pass


class Session():
    """This static class handles all session communication with ERP backend

    TODO: eventually turn this class in a real singleton (just a style change, no functional requirements)
    """

    class __SessionDispatcher(QtCore.QObject):
        """Singleton to dispatch signals

        Note: this needs to be an instance in order to emit signals
        """

        # Emitted when a new change has been logged, it triggers a change load in the model
        change_logged = QtCore.pyqtSignal(object)
        # Emitted when log has been cleared reset
        log_cleared = QtCore.pyqtSignal(object)
        # Emitted when a feature add has been detected (log is deferred)
        feature_added = QtCore.pyqtSignal(object)
        # Emitted when a split operation has been completed (ERPSync finished)
        split_completed = QtCore.pyqtSignal(object)


    # Session list cache
    _session_data = {}

    _active_session = None

    # Data model storage
    _session_changes = {}

    # Session layer visibility status
    _layer_visibility_memory = None

    _dispatcher = __SessionDispatcher()
    _preview_cache_dir = None
    _dirty_changes_ids = 'a'

    class DirtyStatus(Enum):
        """Session change dirty status"""

        DIRTY = 1
        CLEAN = 2

        def description(self):
            """Convert enum to a localized string

            :return: the enum value description
            :rtype: str
            """

            return tr('Dirty') if self == self.DIRTY else tr('Clean')

    class ChangeType(Enum):
        """Change type"""

        ADD = 1
        DELETE = 2
        SINGLE_ATTRIBUTE_CHANGE = 3
        # This is not currently used, but it's implemented and tested
        # so I'd leave it for future uses
        MULTIPLE_ATTRIBUTE_CHANGE = 4
        GEOMETRY_CHANGE = 5

        def description(self):
            """Convert enum to a localized string

            :return: the enum value description
            :rtype: str
            """
            if self == self.ADD:
                return tr('Add')
            elif self == self.DELETE:
                return tr('Delete')
            elif self == self.GEOMETRY_CHANGE:
                return tr('Geometry change')
            elif self == self.SINGLE_ATTRIBUTE_CHANGE:
                return tr('Attribute change')

    @classmethod
    def dispatcher(cls):
        return cls._dispatcher

    @classmethod
    def _ensure_session(cls):
        """Raise an exception if there is no active session

        :raises SessionRequiredError: An active session is required
        """

        if cls._active_session is None:
            raise SessionRequiredError()

    @classmethod
    def search(cls, *args, **kwargs):
        """Return a list of all matched session IDs from ERP

        :param filter: list of search filters (ERP search tuple filters)
        :type filter: list
        :return: List with all matched session IDs
        :rtype: list
        """

        try:
            model = ERPClient.model(QGISCE_SESSION_MODEL_NAME)
            return model.search(*args, **kwargs)
        except Exception as e:
            raise SessionSearchError(e)

    @classmethod
    def __get_change_desc(cls, change_type, layer):
        """Format change description"""
        if change_type == Session.ChangeType.ADD:
            description = tr("New {}").format(layer.name())
        elif change_type == Session.ChangeType.DELETE:
            description = tr("{} deleted").format(layer.name())
        elif change_type == Session.ChangeType.GEOMETRY_CHANGE:
            description = tr("{} geometry changed").format(layer.name())
        elif change_type == Session.ChangeType.SINGLE_ATTRIBUTE_CHANGE:
            description = tr("{} single attribute changed").format(layer.name())
        elif change_type == Session.ChangeType.MULTIPLE_ATTRIBUTE_CHANGE:
            description = tr("{} multiple attribute changed").format(layer.name())
        return description

    @classmethod
    def log_change(cls, layer, layer_specs, change_type, feature_id, *args):
        """Log a QGIS local session change, before it is synchronized with the server.

        When the change is saved to the server, it becomes a remote session change.

        Note: deferred creation of features is not logged

        :param layer: QGIS layer
        :type layer: QgsVectorLayer
        :param layer_specs: layer information
        :type layer_specs: LayerSpecs
        :param change_type: change type
        :type change_type: ChangeType
        :param feature_id: feature id
        :type feature_id: int
        """
        # ToDo: S'HA DE REVISAR AQUESTA PART JA QUE PUTSE EL LOG S'HA DE FER NOMES A DEMANDA A L'HORA DE VALIDAR
        # No circular imports
        from qgisceutils.erp_sync import ERPSync

        if layer.id() not in cls._session_changes:
            cls._session_changes[layer.id()] = []

        geometry = None
        layer_id = layer.id()
        changes = {}

        # Get feature information
        feature = layer.getFeature(feature_id)

        # Avoid assert error
        # assert change_type == Session.ChangeType.DELETE or feature.isValid()
        if not feature.isValid() and change_type != Session.ChangeType.DELETE:
            return

        field_name = None
        if change_type == Session.ChangeType.SINGLE_ATTRIBUTE_CHANGE:
            field_name = feature.fields()[args[0]].name()

        # Collect information about changes
        description = cls.__get_change_desc(change_type, layer)
        erp_id = ERPSync.get_erp_id(layer, feature_id)
        # May be None in case of delete
        geometry = feature.geometry()
        if change_type == Session.ChangeType.SINGLE_ATTRIBUTE_CHANGE:
            changes = {field_name: args[1]}
        elif change_type == Session.ChangeType.MULTIPLE_ATTRIBUTE_CHANGE:
            changes = args[0]
        elif change_type == Session.ChangeType.ADD:
            # Do not add erp_data to changes...
            changes = {fld: feature[fld] for fld in feature.fields().names()}
        elif change_type == Session.ChangeType.DELETE:
            # Feature was deleted: we need to retrieve it from ERP again to
            # get the geometry
            if erp_id is not None and feature_id > 0:
                model = ERPClient.model(layer_specs.model)
                if cls.active_id():
                    context = {
                        'session': cls.active_id(),
                        'cataleg': layer_specs.catalog_id
                    }
                else:
                    context = {'cataleg': layer_specs.catalog_id}
                if layer_specs.model not in QGISCE_TOPOLOGY_MODEL_NAMES:
                    geometry = QgsGeometry.fromWkt(
                        model.read(erp_id, ['geom'], context=context)['geom']
                    )
        else:
            geometry = args[0]
            changes['geom'] = geometry.asWkt()

        change = {
            'scope': Session.DirtyStatus.DIRTY,
            'description': description,
            'type': change_type,
            'layer_name': layer.name(),
            'layer_id': layer_id,
            'feature_id': feature_id,
            'dirty': True,
            'erp_id': erp_id,
            'name': feature['name'] if 'name' in feature.fields().names() else None,
            'geometry': geometry,
            'changes': changes,
            'change_id': cls._dirty_changes_ids
        }
        cls._dirty_changes_ids = chr(ord(cls._dirty_changes_ids) + 1)

        # Skip individual changes if there is no erp_id (because they were triggered before the final save)
        if change_type == Session.ChangeType.SINGLE_ATTRIBUTE_CHANGE and erp_id is None:
            message_log("Session log_change DEFERRED SINGLE_ATTRIBUTE_CHANGE %s %s %s: %s" % (layer.name(), change_type, feature_id, changes))
            return

        # Handle the case for feature split and move/copy
        current_tool = None
        if iface and iface.mapCanvas() and iface.mapCanvas().mapTool():
            tool = iface.mapCanvas().mapTool()
            action = tool.action()
            if action:
                current_tool = action.objectName()
        open_form = (
            change_type == Session.ChangeType.ADD and
            (current_tool == 'mActionSplitFeatures' or
             current_tool in QGIS_MOVE_FEATURE_ACTIONS_NAMES)
        )
        if open_form:
            #cls._log_remote_load(layer_id)
            message_log("Session log_change DEFERRED ADD %s %s %s: %s" % (layer.name(), change_type, feature_id, changes))
            cls.dispatcher().feature_added.emit(change)
            return


        # And skip deferred creation/deletion
        if change_type == Session.ChangeType.ADD:
            #cls._log_remote_load(layer_id)
            message_log("Session log_change DEFERRED ADD %s %s %s: %s" % (layer.name(), change_type, feature_id, changes))
            cls.dispatcher().feature_added.emit(change)
            return

        # Skip unsynced features
        if change_type == Session.ChangeType.DELETE and erp_id is None:
            message_log("Session log_change DEFERRED DELETE %s %s %s" % (layer.name(), change_type, feature_id))
            return

        #cls._log_remote_load(layer_id)
        message_log("Session log_change LOGGED %s %s %s erp_id: %s %s" % (layer.name(), change_type, feature_id, erp_id, changes))

    @classmethod
    def log_clear(cls, layer_id=None):
        """Clear the log for the optionally specified layer_id

        :param layer_id: layer id
        :type layer_id: str
        """
        # TODO: remove this debug message
        message_log("Session log clear request for layer id: %s" % layer_id)
        if layer_id is not None:
            if layer_id in cls._session_changes:
                del(cls._session_changes[layer_id])
        else:
            cls._session_changes = {}

        #if cls.is_active():
        #    cls._log_remote_load(layer_id)

        # Notify
        cls._dispatcher.log_cleared.emit(layer_id)

    @classmethod
    def _log_remote_load(cls, layer_id=None):
        """This function will load the remote session changes for the active session into the data storage.
        It needs to be called when all session layers have been downloaded."""

        cls._ensure_session()
        cls._session_changes = {}
        fake_change_id = 0

        # No circular imports
        from qgisceutils.project import catalog_id_for_layer, layer_for_catalog_id, model_for_layer

        search_criteria = [('session_id', '=', cls.active_id())]

        session_changes_model = ERPClient.model(QGISCE_SESSION_CHANGES_MODEL_NAME)
        changes_ids = session_changes_model.search(search_criteria)
        changes_to_fetch = session_changes_model.read(changes_ids)
        for res in changes_to_fetch:
            catalog_id = res['cataleg_id'][0]
            layer = layer_for_catalog_id(catalog_id)
            layer_id = layer.id()

            if res['status'] == 'A':
                change_type = Session.ChangeType.ADD
            elif res['status'] == 'D':
                change_type = Session.ChangeType.DELETE
            else:
                if 'geom' in res['data']:
                    change_type = Session.ChangeType.GEOMETRY_CHANGE
                else:
                    change_type = Session.ChangeType.SINGLE_ATTRIBUTE_CHANGE

            erp_ids = res['res_id']
            if isinstance(erp_ids, list):
                for erp_id in erp_ids:
                    if res['status'] != 'D':
                        # This may raise if the feature has been added and then deleted
                        try:
                            if 'active' in res['data'] and not res['data'][
                                'active']:
                                change_type = Session.ChangeType.DELETE
                                res['status'] = 'D'
                                feature_id = None
                            else:
                                feature_id = get_feature_by_erp_id(layer, erp_id).id()
                        except IndexError:
                            feature_id = None
                        geometry = None
                    else:
                        feature_id = None
                        geometry = None

                    description = cls.__get_change_desc(change_type, layer)

                    if res['dirty']:
                        scope = Session.DirtyStatus.DIRTY
                    else:
                        scope = Session.DirtyStatus.CLEAN

                    change = {
                        'scope': scope,
                        'description': description,
                        'type': change_type,
                        'layer_name': layer.name(),
                        'layer_id': layer_id,
                        'feature_id': feature_id,
                        'dirty': res['dirty'],
                        'erp_id': erp_id,
                        'geometry': geometry,
                        'changes': res['data'],
                        'change_id': res['id']
                    }
                    if not layer_id in cls._session_changes:
                        cls._session_changes[layer_id] = []
                    if res['res_model'] == 'giscegis.edge' and res[
                        'status'] == 'A':
                        start_node = res['data']['start_node']
                        end_node = res['data']['end_node']
                        nodes_layer = QgsProject.instance().mapLayersByName(
                            QGISCE_NODES_LAYER_NAME
                        )[0]
                        nodes_layer_id = nodes_layer.id()
                        description = cls.__get_change_desc(change_type,
                                                            nodes_layer)
                        if isinstance(start_node, list):
                            try:
                                start_node_feature_id = get_feature_by_erp_id(
                                    nodes_layer, start_node[0][2]['id']
                                ).id()
                            except IndexError:
                                start_node_feature_id = False
                            start_node_erp_id = start_node[0][2]['id']
                            start_node_changes = start_node[0][2]
                            change_start_node = {
                                'scope': scope,
                                'description': description,
                                'type': change_type,
                                'layer_name': nodes_layer.name(),
                                'layer_id': nodes_layer_id,
                                'feature_id': start_node_feature_id,
                                'dirty': res['dirty'],
                                'erp_id': start_node_erp_id,
                                'geometry': None,
                                'changes': start_node_changes,
                                'change_id': fake_change_id
                            }
                            fake_change_id -= 1
                            if not nodes_layer_id in cls._session_changes:
                                cls._session_changes[nodes_layer_id] = []
                            cls._session_changes[nodes_layer_id].append(
                                change_start_node
                            )
                        if isinstance(end_node, list):
                            try:
                                end_node_feature_id = get_feature_by_erp_id(
                                    nodes_layer, end_node[0][2]['id']
                                ).id()
                            except IndexError:
                                end_node_feature_id = False
                            end_node_erp_id = end_node[0][2]['id']
                            end_node_changes = end_node[0][2]
                            change_end_node = {
                                'scope': scope,
                                'description': description,
                                'type': change_type,
                                'layer_name': nodes_layer.name(),
                                'layer_id': nodes_layer_id,
                                'feature_id': end_node_feature_id,
                                'dirty': res['dirty'],
                                'erp_id': end_node_erp_id,
                                'geometry': None,
                                'changes': end_node_changes,
                                'change_id': fake_change_id
                            }
                            fake_change_id -= 1
                            if not nodes_layer_id in cls._session_changes:
                                cls._session_changes[nodes_layer_id] = []
                            cls._session_changes[nodes_layer_id].append(
                                change_end_node)

                    cls._session_changes[layer_id].append(change)
                    if change['layer_name'] not in QGISCE_TOPOLOGY_LAYER_NAMES:
                        cls.dispatcher().change_logged.emit(change)
            else:
                erp_id = erp_ids
                if res['status'] != 'D':
                    # This may raise if the feature has been added and then deleted
                    try:
                        if 'active' in res['data'] and not res['data']['active']:
                            change_type = Session.ChangeType.DELETE
                            res['status'] = 'D'
                            feature_id = None
                        else:
                            feature_id = get_feature_by_erp_id(layer, erp_id).id()
                    except IndexError:
                        feature_id = None
                    geometry = None
                else:
                    feature_id = None
                    geometry = None

                description = cls.__get_change_desc(change_type, layer)

                if res['dirty']:
                    scope = Session.DirtyStatus.DIRTY
                else:
                    scope = Session.DirtyStatus.CLEAN

                change = {
                    'scope': scope,
                    'description': description,
                    'type': change_type,
                    'layer_name': layer.name(),
                    'layer_id': layer_id,
                    'feature_id': feature_id,
                    'dirty': res['dirty'],
                    'erp_id': erp_id,
                    'geometry': geometry,
                    'changes': res['data'],
                    'change_id': res['id']
                }
                if not layer_id in cls._session_changes:
                    cls._session_changes[layer_id] = []
                if res['res_model'] == 'giscegis.edge' and res['status'] == 'A':
                    start_node = res['data']['start_node']
                    end_node = res['data']['end_node']
                    nodes_layer = QgsProject.instance().mapLayersByName(
                        QGISCE_NODES_LAYER_NAME
                    )[0]
                    nodes_layer_id = nodes_layer.id()
                    description = cls.__get_change_desc(change_type, nodes_layer)
                    if isinstance(start_node, list):
                        try:
                            start_node_feature_id = get_feature_by_erp_id(
                                nodes_layer, start_node[0][2]['id']
                            ).id()
                        except IndexError:
                            start_node_feature_id = False
                        start_node_erp_id = start_node[0][2]['id']
                        start_node_changes = start_node[0][2]
                        change_start_node = {
                            'scope': scope,
                            'description': description,
                            'type': change_type,
                            'layer_name': nodes_layer.name(),
                            'layer_id': nodes_layer_id,
                            'feature_id': start_node_feature_id,
                            'dirty': res['dirty'],
                            'erp_id': start_node_erp_id,
                            'geometry': None,
                            'changes': start_node_changes,
                            'change_id': fake_change_id
                        }
                        fake_change_id -= 1
                        if not nodes_layer_id in cls._session_changes:
                            cls._session_changes[nodes_layer_id] = []
                        cls._session_changes[nodes_layer_id].append(change_start_node)
                    if isinstance(end_node, list):
                        try:
                            end_node_feature_id = get_feature_by_erp_id(
                                nodes_layer, end_node[0][2]['id']
                            ).id()
                        except IndexError:
                            end_node_feature_id = False
                        end_node_erp_id = end_node[0][2]['id']
                        end_node_changes = end_node[0][2]
                        change_end_node = {
                            'scope': scope,
                            'description': description,
                            'type': change_type,
                            'layer_name': nodes_layer.name(),
                            'layer_id': nodes_layer_id,
                            'feature_id': end_node_feature_id,
                            'dirty': res['dirty'],
                            'erp_id': end_node_erp_id,
                            'geometry': None,
                            'changes': end_node_changes,
                            'change_id': fake_change_id
                        }
                        fake_change_id -= 1
                        if not nodes_layer_id in cls._session_changes:
                            cls._session_changes[nodes_layer_id] = []
                        cls._session_changes[nodes_layer_id].append(change_end_node)

                cls._session_changes[layer_id].append(change)
                if change['layer_name'] not in QGISCE_TOPOLOGY_LAYER_NAMES:
                    cls.dispatcher().change_logged.emit(change)

    @classmethod
    def changes(cls):
        """Return session changes

        :return: session changes
        :rtype: dict
        """

        return cls._session_changes


    @classmethod
    def _scope_filtered_changes(cls, scope_filter: DirtyStatus):
        # Here is where I think I should have remained to PASCAL and BASIC:
        return {lid2:v2 for lid2, v2 in {lid:[v for v in chg if v['scope'] \
            == scope_filter] for lid, chg in \
            Session._session_changes.items()}.items() if v2}

    @classmethod
    def local_changes(cls):
        """Return local session changes

        :return: local session changes
        :rtype: dict
        """

        return cls._scope_filtered_changes(Session.DirtyStatus.DIRTY)

    @classmethod
    def network_changes(cls):
        """Return local session changes suitable for network update

        :return: local session network changes
        :rtype: list of dicts
        """
        from qgisceutils.project import model_for_layer
        cls._log_remote_load()
        change_list = []

        def _type_map(t):
            """Map session change types to network validator types

            [NOTE][HACK] : this map is an equivalence of the original
                pandapower_validator.network.ChangeType:
                    ADD = 1
                    DELETE = 2
                    MODIFY = 3
            """
            if t == Session.ChangeType.ADD:
                return 1 # like ChangeType.ADD
            elif t == Session.ChangeType.DELETE:
                return 2 # like ChangeType.DELETE
            elif t in (
                    Session.ChangeType.GEOMETRY_CHANGE,
                    Session.ChangeType.SINGLE_ATTRIBUTE_CHANGE,
                    Session.ChangeType.MULTIPLE_ATTRIBUTE_CHANGE):
                return 3 # like ChangeType.MODIFY
            else:
                raise Exception("Unsupported PandaPowerValidator change type: %s" % t)

        def _add(layer_id, layer_changes):
            """Add changes to the list"""
            layer = QgsProject.instance().mapLayer(layer_id)
            model = model_for_layer(layer)
            node_layer = QgsProject.instance().mapLayersByName(
                QGISCE_NODES_LAYER_NAME
            )[0]
            node_obj = ERPClient.model(QGISCE_NODES_MODEL_NAME)
            edge_layer = QgsProject.instance().mapLayersByName(
                QGISCE_EDGES_LAYER_NAME
            )[0]
            edge_obj = ERPClient.model(QGISCE_EDGES_MODEL_NAME)

            for change in layer_changes:
                if layer.geometryType() == QgsWkbTypes.PointGeometry:
                    try:
                        node = layer.getFeature(change['feature_id'])['node_id']
                    except:
                        node = (
                            change['erp_id'] if model == QGISCE_NODES_MODEL_NAME
                            else None
                        )

                    # Search the ERP node name to feed the validator
                    node_features = list(
                        node_layer.getFeatures("id = '{}'".format(node))
                    )

                    # If the node have been delete we won't find it on the
                    # existing features so we must manage that situation
                    if node_features:
                        node_name = node_features[0]['name']
                    elif node is not None:
                        node_exist = node_obj.search([('id', '=', node)])
                        if node_exist:
                            node_name = node_obj.read(node, ['name'])['name']
                        else:
                            node_name = None
                    else:
                        node_name = None

                    # Use the provisional feature id instead of erp_id if it
                    # is None
                    erp_id = (
                        change['erp_id'] if change['erp_id'] is not None
                        else change['feature_id']
                    )
                    change_list.append({
                        "change_id": change['change_id'],
                        "type": _type_map(change['type']),
                        "element": erp_id,
                        "model": model,
                        "node": node,
                        "node_name": node_name,
                        "changes": change['changes'],
                    })
                elif layer.geometryType() == QgsWkbTypes.LineGeometry:
                    try:
                        edge = layer.getFeature(change['feature_id'])['edge_id']
                    except:
                        edge = (
                            change['erp_id'] if model == QGISCE_EDGES_MODEL_NAME
                            else None
                        )

                    # Search the ERP node name to feed the validator
                    edge_features = list(
                        edge_layer.getFeatures("id = '{}'".format(edge))
                    )

                    # If the edge have been delete we won't find it on the
                    # existing features so we must manage that situation
                    if edge_features:
                        edge_name = edge_features[0]['name']
                        start_node_id = edge_features[0]['start_node']
                        end_node_id = edge_features[0]['end_node']
                    elif edge is not None:
                        edge_exist = edge_obj.search([('id', '=', edge)])
                        if edge_exist:
                            edge_data = edge_obj.read(
                                edge, ['name', 'start_node', 'end_node']
                            )
                            edge_name = edge_data['name']
                            start_node_id = edge_data['start_node'][0]
                            end_node_id = edge_data['end_node'][0]
                        else:
                            edge_name = None
                            start_node_id = None
                            end_node_id = None
                    else:
                        edge_name = None
                        start_node_id = None
                        end_node_id = None

                    # Use the provisional feature id instead of erp_id if it
                    # is None
                    erp_id = (
                        change['erp_id'] if change['erp_id'] is not None
                        else change['feature_id']
                    )
                    change_list.append({
                        "change_id": change['change_id'],
                        "type": _type_map(change['type']),
                        "element": erp_id,
                        "model": model,
                        "edge": edge,
                        "edge_name": edge_name,
                        "start_node_id": start_node_id,
                        "end_node_id": end_node_id,
                        "changes": change['changes']
                    })

        # Remote first
        for layer_id, layer_changes in cls.remote_changes().items():
            _add(layer_id, layer_changes)

        for layer_id, layer_changes in cls.local_changes().items():
            _add(layer_id, layer_changes)

        return change_list

    @classmethod
    def remote_changes(cls):
        """Return remote session changes

        :return: remote session changes
        :rtype: dict
        """

        return cls._scope_filtered_changes(Session.DirtyStatus.CLEAN)

    @classmethod
    def feature_changes(cls, layer_id, feature_id):
        """Return session changes for a given layer and feature id

        :return: session changes
        :rtype: dict
        """
        result = []
        for changes in [chg for lid, chg in Session._session_changes.items() if lid == layer_id]:
            for c in changes:
                if c['feature_id'] == feature_id:
                    result.append(c)
        return result

    @classmethod
    def preview_cache_dir(cls):
        """Directory of the preview cached images

        :return: cache dir path
        :rtype: str
        """

        if cls._preview_cache_dir is None:
            cls._preview_cache_dir = os.path.join(os.path.dirname(
                __file__), os.path.pardir, 'session_preview_cache')
            if not os.path.exists(cls._preview_cache_dir):
                os.mkdir(cls._preview_cache_dir)
        return cls._preview_cache_dir

    @classmethod
    def preview_path(cls, session_id):
        """Calculate the preview image cache path for the given session id

        :param session_id: session id
        :type session_id: int
        :return: the full path to the cached preview image
        :rtype: str
        """

        return os.path.join(cls.preview_cache_dir(), "session_%s.png" % session_id)

    @classmethod
    def make_preview_snapshot(cls, session_id=None, bbox=None):
        """Create the preview image and store it into the preview path

        :return: True if the operation was successfull
        :rtype: bool
        """
        session_id = session_id or cls.active_id()
        bbox = bbox or cls._active_session['bbox']

        if session_id and getattr(iface,  'mapCanvas', False):

            # Ajustem el bbox perque aparegui la sessió amb una mica de marge:
            margin = max(bbox.height(), bbox.width())
            if margin > 10:
                margin /= 10
            bbox = bbox.buffered(margin)

            # Previament a enviar les dades per generar l'snapshot, posarem
            # totes les capes a visible:
            hidden_layers = []

            for legend in QgsProject.instance().layerTreeRoot().findLayers():
                if not legend.isVisible():
                    hidden_layers.append(legend);
                    legend.setItemVisibilityChecked(True)

            canvas = iface.mapCanvas()

            # HACK: esperem la finalització síncrona dels events pendents a
            # l'aplicació. Altrament caldria implementar-ho amb signals.
            QgsApplication.processEvents()

            # Creació de l'snapshot:
            create_snapshot(canvas, cls.preview_path(session_id),
                            PREVIEW_IMAGE_SIZE, PREVIEW_IMAGE_SIZE, bbox)

            # Posteriorment a la generació de l'snapshot tornarem a amagar les
            # capes que inicialment estaven amagades:
            for legend in hidden_layers:
                legend.setItemVisibilityChecked(False)

            return True

        return False

    @classmethod
    def update_preview(cls, preview_path=None, session_id=None, bbox=None):
        """Store the active session preview on the server, if the preview path is None, it is
        automatically calculated and the image is recreated.

        If a preview path is given, the function assumes that no cached image
        creation is necessary (this behavior was introduced mainly for testability)

        :param preview_path: path to the cached preview image, defaults to None
        :param preview_path: str, optional
        :return: True if the operation was successfull
        :rtype: bool
        """

        if not Session.is_active() and not session_id:
            return
        if not Session.is_active() and not bbox:
            return

        if Session.is_active():
            bbox = bbox or cls._active_session['bbox']
            session_id = session_id or cls.active_id()

        if preview_path is None:
            preview_path = cls.preview_path(session_id)
            if not cls.make_preview_snapshot(session_id=session_id, bbox=bbox):
                return False
        if not os.path.exists(preview_path):
            return False

        with open(preview_path, 'rb') as f:
            image_data = base64.encodebytes(f.read()).decode('utf-8')
            try:
                cls.update(session_id, {'screenshot' : image_data})
                return True
            except SessionUpdateError:
                return False
        return False

    @classmethod
    def _cache_preview_image(cls, session_id, image_data):
        """Write the preview image to disk"""
        if image_data:
            with open(cls.preview_path(session_id), 'wb+') as f:
                f.write(base64.decodebytes(image_data.encode('utf-8')))


    @classmethod
    def list(cls):
        """Return a list of all sessions from ERP

        :return: Dictionary with session id as a key and all session
        information as values
        :rtype: dict
        """
        session_list = {}
        session = ERPClient.model(QGISCE_SESSION_MODEL_NAME)
        try:
            for session_id in session.search([]):
                session_data = session.read(
                    session_id,
                    ['screenshot', 'bbox', 'name', 'active', 'state',
                     'create_uid', 'create_date', 'write_uid', 'write_date']
                )
                # Cache the preview image
                cls._cache_preview_image(session_id, session_data['screenshot'])
                if session_data['bbox']:
                    session_data['bbox'] = QgsRectangle.fromWkt(session_data['bbox'])
                session_list[session_id] = session_data
        except Exception as e:
            raise SessionReadError(e)

        return session_list


    @classmethod
    def create(cls, name, bbox):
        """Create a new session

        :param name: session name (must be unique)
        :type name: str
        :param bbox: bounding box for this session
        :type bbox: QgsRectangle
        :raises SessionCreationError: an error during session creation in case
        of validation issues
        :return: session record
        :rtype: Record
        """
        assert isinstance(bbox, QgsRectangle)
        assert not bbox.isEmpty()
        try:
            if name in [s['name'] for s in cls.list().values()]:
                raise SessionCreationError(
                    tr("A session with this name (%s) already exists, please choose a different name.") % name)
            new_session_id = ERPClient.model(QGISCE_SESSION_MODEL_NAME).create({
                'name': name,
                'bbox': bbox.asWktPolygon(),
            })
            # Put it into the session data cache
            new_session_data = cls.read(new_session_id)
            cls._session_data[new_session_id] = new_session_data
            return new_session_data
        except Exception as e:
            raise SessionCreationError(e)

    @classmethod
    def read(cls, session_id):
        """Read a session

        :param session_id: [session id
        :type session_id: int
        :raises SessionReadError: on error
        :return: session data
        :rtype: dict
        """
        try:
            session_data = ERPClient.call(
                '/object', 'execute', QGISCE_SESSION_MODEL_NAME,
                'read', session_id
            )
            # OpenERP read() with single ID returns a list with one dict
            if isinstance(session_data, list) and len(session_data) > 0:
                session_data = session_data[0]

            if not session_data or not isinstance(session_data, dict):
                raise SessionReadError(
                    "Session %s not found or invalid API response" % session_id
                )

            if session_data.get('bbox'):
                session_data['bbox'] = QgsRectangle.fromWkt(session_data['bbox'])
            return session_data
        except SessionReadError:
            raise
        except Exception as e:
            raise SessionReadError(e)

    @classmethod
    def activate(cls, session_id):
        """Load and activate a session.

        Note: this function does not load layers data but only session related data,
              use layer_loader and pass the session_id to load vector data.

        :param session_id: session id
        :type session_id: int
        :raises SessionReadError: on error
        :return: active session information
        :rtype: dict
        """
        try:
            cls._active_session = cls.read(session_id)
            cls._session_changes = {}
            # Handle session layer visibility (only if layer is loaded)
            if cls._layer_visibility_memory is None:
                session_layers = layers_for_model(QGISCE_SESSION_MODEL_NAME)
                if session_layers:  # Only if session layer exists in project
                    layer = session_layers[0]
                    legend = QgsProject.instance().layerTreeRoot().findLayer(
                        layer.id()
                    )
                    if legend is not None:
                        cls._layer_visibility_memory = legend.isVisible()
                        legend.setItemVisibilityChecked(False)
            return cls._active_session
        except Exception as e:
            raise SessionReadError(e)

    @classmethod
    def active(cls):
        """Return active session

        :return: active session information
        :rtype: dict or None if no active session exists
        """

        return cls._active_session

    @classmethod
    def is_active(cls):
        """Return True if there is an active session

        :return: True if there is an active session
        :rtype: bool
        """

        return cls._active_session is not None

    @classmethod
    def active_id(cls):
        """Return active session id

        :return: active session id
        :rtype: int or None if no active session exists
        """

        return cls._active_session['id'] if cls._active_session is not None else None

    @classmethod
    def clear(cls):
        """Clear active session
        """
        cls._session_changes = {}
        cls._active_session = None

    @classmethod
    def close(cls):
        """Close active session
        """
        if cls._layer_visibility_memory is not None:
            layer = layers_for_model(QGISCE_SESSION_MODEL_NAME)[0]
            legend = QgsProject.instance().layerTreeRoot().findLayer(
                layer.id()
            )
            legend.setItemVisibilityChecked(cls._layer_visibility_memory)
            cls._layer_visibility_memory = None
        cls._session_changes = {}
        cls._active_session = None


    @classmethod
    def network(cls, *args):
        """Return the network data from ERP session,
        downloads the data if they are not yet downloaded.

        :return: network data
        :rtype: dictionary
        """
        session_fields = ERPClient.call(
            '/object', 'execute', QGISCE_NETWORK_MODEL_NAME, 'fields_get',
            ['network_id']
        )
        if 'network_id' not in session_fields:
            return None
        if not cls.is_active() or cls.active()['network_id'] is None:
            return None
        if 'network' not in cls._active_session or cls._active_session['network'] is None:
            if cls._active_session['network_id']:
                network = ERPClient.call(
                    '/object', 'execute', QGISCE_NETWORK_MODEL_NAME, 'read',
                    cls._active_session['network_id'][0], ['network']
                )
                cls._active_session['network'] = json.loads(
                    base64.b64decode(network).decode('utf8')
                )
            else:
                return None
        return cls._active_session['network']

    @classmethod
    def update(cls, session_id, session_changes, update_layer_manually=False):
        """Update session

        :param session_id: session id
        :type session_id: int
        :param session_changes: new session configuration
        :type session_changes: dict
        :raises SessionUpdateError: on error
        """

        if 'bbox' in session_changes:
            session_changes['bbox'] = session_changes['bbox'].asWktPolygon()
        try:
            result = ERPClient.model(QGISCE_SESSION_MODEL_NAME).write([session_id], session_changes)
        except Exception as e:
            raise SessionUpdateError(e)
        # Modificar la capa de sessions manualment
        if update_layer_manually:
            layer = layers_for_model(QGISCE_SESSION_MODEL_NAME)[0]
            fields = fields_for_layer(layer)
            fields = fields + ['bbox']
            data = ERPClient.model(QGISCE_SESSION_MODEL_NAME).qread(
                session_id, fields
            )
            request = QgsFeatureRequest(
                QgsExpression(
                    '"id" = {}'.format(data['id'])
                )
            )
            layer.setReadOnly(False)
            layer.startEditing()
            feature = next(layer.getFeatures(request))
            for field in fields:
                idx = feature.fieldNameIndex(field)
                layer.changeAttributeValue(feature.id(), idx, data[field])
            layer.changeGeometry(
                feature.id(), QgsGeometry.fromWkt(data['bbox'])
            )
            layer.commitChanges()
            layer.rollBack()
            layer.triggerRepaint()
            layer.setReadOnly(True)


        return result

    @classmethod
    def merge(cls, session_id):
        """Merge the session specified by session_id

        :param session_id: session id
        :type session_id: int
        :raises SessionMergeError: on error
        :return: True on success
        :rtype: bool
        """

        try:
            context = {
                'cataleg': False
            }
            session_object = ERPClient.model(QGISCE_SESSION_MODEL_NAME)
            result = session_object.merge([session_id], context=context)
            return result
        except Exception as e:
            raise SessionMergeError(e)

    @classmethod
    def discard(cls, session_id):
        """Discard the session specified by session_id, also clear current
        session if it was discarded

        :param session_id: session id
        :type session_id: int
        :raises SessionDiscardError: on error
        :return: True on success
        :rtype: bool
        """

        try:
            session_object = ERPClient.model(QGISCE_SESSION_MODEL_NAME)
            result = session_object.discard([session_id])
        except Exception as e:
            raise SessionDiscardError(e)
        try:
            layer = layers_for_model(QGISCE_SESSION_MODEL_NAME)[0]
            request = QgsFeatureRequest(
                QgsExpression(
                    '"id" = {}'.format(session_id)
                )
            )
            layer.setReadOnly(False)
            layer.startEditing()
            feature = next(layer.getFeatures(request))
            layer.deleteFeature(feature.id())
            layer.commitChanges()
            layer.rollBack()
            layer.triggerRepaint()
            layer.setReadOnly(True)
        except (StopIteration, IndexError):
            pass
        return result


    @classmethod
    def reject_changes(cls, session_id, layer_specs):
        """Discards all dirty changes for the given session and catalog
        """

        if not cls.is_active():
            message_log("Calling feature_added without an active session!", Qgis.Warning)
            return

        catalog_id = layer_specs.catalog_id

        try:
            session_object = ERPClient.model(QGISCE_SESSION_MODEL_NAME)
            result = session_object.reject_changes(
                [session_id], context={'cataleg_id': catalog_id}
            )
            message_log(
                "Reject session changes for %s" % layer_specs.layer_name
            )
            return result
        except Exception as e:
            raise SessionDiscardChangesError(e)

    @classmethod
    def confirm_changes(cls, session_id, layer_specs):
        """Confirm all dirty changes for the given session and catalog
        """

        if not cls.is_active():
            message_log(
                "Calling feature_added without an active session!", Qgis.Warning
            )
            return

        catalog_id = layer_specs.catalog_id

        try:
            session_object = ERPClient.model(QGISCE_SESSION_MODEL_NAME)
            result = session_object.confirm_changes(
                [session_id], context={'cataleg_id': catalog_id}
            )
            message_log(
                "Confirm session changes for %s" % layer_specs.layer_name
            )
            return result
        except Exception as e:
            raise SessionConfirmChangesError(e)

