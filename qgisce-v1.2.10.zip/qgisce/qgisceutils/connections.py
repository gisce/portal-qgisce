# coding=utf-8
""""QGIS Layers connections with topology and synchronizer

.. note:: This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

"""

__author__ = 'elpaso@itopen.it'
__date__ = '2019-02-01'
__copyright__ = 'Copyright 2019, GISCE'

from qgisceutils.literals import *
from qgiscegui.notifications import message_log
from qgisceutils.session import Session
from qgis.PyQt.QtCore import Qt, QVariant, QTimer
from functools import partial
from qgisceutils.erp_sync import ERPSync
from qgisceutils.topology import *


def setup_connections(layer, layer_specs):
    """Connect layer signals to the synchronizer

    :param layer: the layer to be connected
    :type layer: QgsVectorLayer
    :param layer_specs: layer specifications
    :type layer_specs: LayerSpecs
    """
    # Session layer don't need to be connected to any signal
    if layer_specs.model == QGISCE_SESSION_MODEL_NAME:
        return
    def _make_connection(method, function, unique=False, queued=False):
        """Store the connections to lambdas and partials to be able to
        disconnect them all

        :param method: connection name
        :type method: str
        :param function: function
        :type function: callable
        :param unique: if the connection must be unique, defaults to False
        :param unique: bool, optional
        :param queued: if the connection must be queued, defaults to False
        :param queued: bool, optional
        """

        if not hasattr(layer, '_connections'):
            layer._connections = []
        if not hasattr(layer, '_forms'):
            layer._forms = []
        layer._connections.append((method, function))
        flags = None
        if unique:
            flags = Qt.UniqueConnection
        if queued:
            if flags is not None:
                flags |= Qt.QueuedConnection
        if flags is not None:
            getattr(layer, method).connect(function, flags)
        else:
            getattr(layer, method).connect(function)

    def dirty_sync(what, layer, layer_specs):
        """Calls session dirty changes hooks before commits
        and after rollbacks, in the latter case topology garbage
        collection is performed"""

        if not Session.is_active():
            message_log("Calling dirty_sync without an active sessions.")
            return

        if layer.isEditable():
            if what == 'beforeCommitChanges':
                Session.confirm_changes(Session.active_id(), layer_specs)
            elif what == 'afterRollBack':
                # Need to rollback all changes
                Session.reject_changes(Session.active_id(), layer_specs)
            if layer_specs.model not in QGISCE_TOPOLOGY_MODEL_NAMES:
                topology_garbage_collect(
                    bbox=Session.active()['bbox'], layer_specs=layer_specs
                )

    def rollback_status_setter(layer, status):
        """Update rollback status setter on the layer instance"""

        layer.is_rolling_back = status

    def commit_changes_status_setter(layer, status):
        """Update commit_changesstatus setter on the layer instance"""

        layer.is_committing_changes = status

    def set_edit_forms_status(layer, status):
        if hasattr(layer, '_forms'):
            for form in layer._forms:
                form.setReadOnly(status)


    ###########################################################################
    # Connect signals for ALL layers (topology and NOT topology)
    ###########################################################################

    # Build/destroy the fid mapping cache kept internally by the
    # Session class
    _make_connection('editingStarted', partial(
        ERPSync.editing_started, layer), True)
    _make_connection('editingStopped', partial(
        ERPSync.editing_stopped, layer), True)

    # Enable or disable the edition of the docked forms related to the layer
    _make_connection(
        'editingStarted', partial(set_edit_forms_status, layer, False), True
    )
    _make_connection(
        'editingStopped', partial(set_edit_forms_status, layer, True), True
    )

    # Dirty changes
    _make_connection('beforeCommitChanges', partial(
        dirty_sync, 'beforeCommitChanges', layer, layer_specs), True)
    _make_connection('afterRollBack', partial(
        dirty_sync, 'afterRollBack', layer, layer_specs), True)

    # Set rollback flag
    _make_connection('beforeRollBack', partial(
        rollback_status_setter, layer, True), True)
    _make_connection('afterRollBack', partial(
        rollback_status_setter, layer, False), True)
    # Set commit_changes flag
    _make_connection('beforeCommitChanges', partial(
        commit_changes_status_setter, layer, True), True)
    _make_connection('afterCommitChanges', partial(
        commit_changes_status_setter, layer, False), True)

    # Clear session changes cache when editing is started or stopped
    _make_connection('editingStopped', partial(
        Session.log_clear, layer.id()), True)
    # Session log changes
    _make_connection('featureAdded', partial(
        Session.log_change, layer, layer_specs, Session.ChangeType.ADD), True)
    _make_connection('featureDeleted', partial(
        Session.log_change, layer, layer_specs, Session.ChangeType.DELETE),
                     True)
    _make_connection('attributeValueChanged', partial(
        Session.log_change, layer, layer_specs,
        Session.ChangeType.SINGLE_ATTRIBUTE_CHANGE), True)
    _make_connection('geometryChanged', partial(
        Session.log_change, layer, layer_specs,
        Session.ChangeType.GEOMETRY_CHANGE), True)


    ###########################################################################
    # Connect signals for all layers except for read only and
    # QGISCE_TOPOLOGY_MODEL_NAMES
    ###########################################################################
    if not layer_specs.read_only and layer_specs.model not in QGISCE_TOPOLOGY_MODEL_NAMES:

        # Update session preview image
        _make_connection('editingStopped', Session.update_preview, True)

        # Connect signals that keep fields in sync with erp_data
        # _make_connection('attributeValueChanged', partial(erp_data_sync, 'attributeValueChanged', layer), True)
        # _make_connection('geometryChanged', partial(erp_data_sync, 'geometryChanged', layer), True)

        # ERP sync (not_topology flag is checked inside the individual slots)
        _make_connection('geometryChanged', partial(
            ERPSync.geometry_changed, layer, layer_specs), True)
        _make_connection('attributeValueChanged', partial(
            ERPSync.attribute_value_changed, layer, layer_specs), True)
        _make_connection('featureDeleted', partial(
            ERPSync.feature_deleted, layer, layer_specs), True)
        _make_connection('featureAdded', partial(
            ERPSync.feature_added, layer, layer_specs), True)

    # Snapping
    if not layer_specs.read_only and layer_specs.snap_to:
        _make_connection('editingStarted', partial(
            snapping_setup, layer, layer_specs.snap_to), True)
        _make_connection('editingStopped', clear_snapping_setup, True)

    layer.is_rolling_back = False
    layer.is_committing_changes = False

    message_log(tr("Synchronization signals connected to layer %s") %
                layer.name())


def clear_connections(layer):
    """Disconnect the layer from the synchronizer"""

    for signal_name, function in layer._connections:
        getattr(layer, signal_name).disconnect(function)

    layer._connections = []
