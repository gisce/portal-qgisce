from qgis.core import QgsSettings
from configparser import ConfigParser
import copy
import os
import json

# Default settings
default_settings = {
    "erp": {
        "host": "localhost",
        "port": "8069",
        "user": "user",
        "password": "password",
        "database": "db",
        "protocol": "http",
    },
    "qgisce": {
        "debug": False,
        "open_session_dialog_at_start": False,
        "progressive_download_enabled": True,
        "sentry_dsn": "",
        "enable_sentry": False,
        "identify_radius": 10.0,
        "current_version": 0,
        "hide_about_dialog": False,
        "max_forms_open": 10,
    },
    "custom_layers": '[]'
}


class QgisceConfig:
    """
    Implementation of the configuration data manager
    """

    PREFIX = 'QGISCE'

    def __init__(self):
        """
        Initialize a QGISCE Config instance
        """

        self.settings = QgsSettings()

    @classmethod
    def get(cls, key, default=None, data_type=None):
        """
        Get one key from the QGIS settings using the stored composed key
        """
        kwargs = {
           'section': QgsSettings.Plugins
        }
        if data_type:
            kwargs.update({
               'type': data_type,
            })
        composed_key = cls.PREFIX + '/' + key
        conf_value = QgsSettings().value(composed_key, default, **kwargs)
        if key == 'custom_layers':
            conf_value = json.loads(conf_value)
        return conf_value

    @staticmethod
    def get_current_plugin_version():
        """Read the plugin version from metadata"""

        parser = ConfigParser()
        try:
            parser.read(
                os.path.join(
                    os.path.dirname(os.path.abspath(__file__)),
                    os.pardir, 'metadata.txt'
                )
            )
            return parser['general']['version']
        except:
            return 0

    @classmethod
    def get_stored_plugin_version(cls):
        """Read the plugin version from the settings"""

        return cls.get('qgisce_current_version', '')


    @classmethod
    def update_stored_plugin_version(cls):
        """Update the plugin version in the settings"""

        cls.set_value(
            'qgisce', 'current_version', cls.get_current_plugin_version()
        )

    @classmethod
    def set_value(cls, section_key, config_key, value):
        """Store a single value in the settings"""
        QgsSettings().setValue(
            cls.PREFIX + '/' + "{section_key}_{config_key}".format(
                section_key=section_key,
                config_key=config_key
            ), value, section=QgsSettings.Plugins
        )

    @classmethod
    def set_custom_layers(cls, group, layers):
            QgsSettings().setValue(
                cls.PREFIX + '/' + group, json.dumps(layers),
                section=QgsSettings.Plugins
            )

    @classmethod
    def values(cls):
        """
        Property that return a fresh dict with all the configured settings or
        the default ones.

        It does not cache the values, those are fetched live for each request
        """
        settings = copy.deepcopy(default_settings)
        for group, configs in settings.items():
            if group == 'custom_layers':
                settings[group] = cls.get(group, default=configs)
            else:
                for key, val in settings[group].items():
                    settings[group][key] = cls.get(
                        "{}_{}".format(group, key), default=val
                    )

        return settings

    @classmethod
    def save(cls, values):
        """
        Stores the QGISCE configuration changes to the QGIS settings,
        always adds/updates the current plugin version to the stored values

        :param values: Contains the configuration values
        :type values: dict[str,str]
        :return: None
        """
        for group, configs in values.items():
            if group == 'custom_layers':
                cls.set_custom_layers(group, configs)
            else:
                for key, value in configs.items():
                    cls.set_value(group, key, value)
        cls.update_stored_plugin_version()

    @classmethod
    def clear(cls):
        """Remove all QGISCE values from the settings"""
        QgsSettings().remove(cls.PREFIX, section=QgsSettings.Plugins)


def get_max_forms_open():
    """Return the configured max_forms_open, normalized to a valid positive int.

    Uses default_settings as the single source of truth for the fallback value.
    Falls back when the stored value is None (key missing) or non-positive.
    """
    _default = default_settings['qgisce']['max_forms_open']
    value = QgisceConfig.get('qgisce_max_forms_open', default=None, data_type=int)
    if value is None or value <= 0:
        return _default
    return value
