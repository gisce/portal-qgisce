# coding=utf-8
"""Font installation utilities for QGISCE plugin.

Registers bundled fonts (Ubuntu and Noto Sans) with Qt's font database so
that QGIS does not try to download them from the network when opening the
QGISCE project, which would produce spurious warning messages on systems
where those fonts are not installed at the OS level.
"""

__author__ = 'GISCE-TI S.L.'
__date__ = '2026-04-16'
__copyright__ = 'Copyright 2026, GISCE-TI S.L.'

import logging
import os

from qgis.PyQt.QtGui import QFontDatabase

LOGGER = logging.getLogger('QGISCE')


def install_bundled_fonts():
    """Register all TTF/OTF font files bundled in the plugin's ``fonts/``
    directory with Qt's application font database.

    This prevents QGIS from attempting to download the fonts from the
    network (via ``QgsFontManager``) when a project that references them is
    loaded, which would produce warning messages on systems where the fonts
    are not installed at the OS level.

    :return: list of font family names that were successfully registered
    :rtype: list[str]
    """
    fonts_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'fonts')
    if not os.path.isdir(fonts_dir):
        LOGGER.debug("No bundled fonts directory found at %s", fonts_dir)
        return []

    db = QFontDatabase()
    registered = []
    for font_file in sorted(os.listdir(fonts_dir)):
        if not font_file.lower().endswith(('.ttf', '.otf')):
            continue
        font_path = os.path.join(fonts_dir, font_file)
        font_id = db.addApplicationFont(font_path)
        if font_id == -1:
            LOGGER.warning("Could not register bundled font: %s", font_file)
        else:
            families = db.applicationFontFamilies(font_id)
            registered.extend(families)
            LOGGER.debug("Registered bundled font %s -> %s", font_file, families)

    return registered
