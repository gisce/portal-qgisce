import warnings
with warnings.catch_warnings():
    # Suppress RequestsDependencyWarning emitted by requests.__init__ when
    # urllib3 or chardet version doesn't match the bundled requirements.
    # The category cannot be narrowed to RequestsDependencyWarning here
    # because requests hasn't been imported yet at this point.
    warnings.filterwarnings(
        "ignore",
        message=r"urllib3 .* or chardet .* doesn't match a supported version",
        category=Warning,
        module=r"requests(\.__init__)?",
    )
    from Koo.Rpc import Rpc, RpcException
from qgis.core import Qgis
from qgiscegui.notifications import message_bar, message_log
from qgisceutils.i18n import tr
from qgisceutils.erp_client import ERPClient, ERPClientException
from qgis.utils import iface
from qgiscegui.status_config_button import QGISCEButtonConfig


class ERPConnection(object):
    """
    Object devised to handle all ERP related methods
    """

    def __init__(
        self, user, password, host, port, database, protocol="http",
        indicator=None
    ):
        """
        Initialize an ERP instance
        """
        self.user = user
        self.password = password
        self.host = host
        self.port = port
        self.database = database

        assert protocol.split('+')[0] in ["http", "https"], "Protocol = %s" % protocol
        self.protocol = protocol

        # The UI indicator
        self.indicator = indicator
        if self.indicator is None:
            for widget in iface.mainWindow().statusBar().children():
                if isinstance(widget, QGISCEButtonConfig):
                    self.indicator = widget

    @property
    def connection_string(self):
        """
        Return the RPC based connection string
        """
        return "{self.protocol}://{self.user}:{self.password}@{self.host}:{self.port}".format(self=self)

    @property
    def status(self):
        """
        Return the ERP connected status

        True if connected, false if not
        """
        return Rpc.session.logged()

    @property
    def status_message(self):
        """
        Return the ERP connected status message
        """
        return "Connected" if self.status else "Disconnected"

    def refresh_indicator(f):
        """
        Refresh indicator decorator

        Execute the decorated function and force an update of the indicator
        """
        def wrapper(self, *args, **kw):
            result = f(self, **kw)
            self.update_indicator()
            return result
        return wrapper

    def update_indicator(self):
        """
        Update the status indicator if exists

        Set "Connected" / "Disconnected" label and apply some formatting
        """
        if self.indicator:
            if self.status:
                status = "Connected"
                style = ""
            else:
                status = "Disconnected"
                style = "color: red;"

            style += "border: none;"
            self.indicator.setStyleSheet(
                "QPushButton {{{style} padding: 4px; margin-left: 4px; "
                "margin-right 4px}}".format(style=style)
            )
            self.indicator.setText(status)
            self.indicator.setToolTip(
                "ERP is {status}!".format(status=status.lower())
            )
            self.indicator.update()

    @refresh_indicator
    def connect(self):
        """
        Try to login via using passed credentials

        Return connection status
        """
        print(self.connection_string, self.database)
        try:
            login_result = Rpc.session.login(
                self.connection_string,
                self.database
            )

            Rpc.session.cache = None
            Rpc.session.qgisce_client = None

            if str(login_result) == "3":
                raise Exception(tr("Bad credentials!"))
            elif str(login_result) == "2":
                raise Exception(tr("Socket error!"))
            # ToDo: Afegit algun tipus de handle especific per el connection refused?
        except Exception as e:
            message_bar(
                tr("Connection error"),
                tr("An error occourred while connecting to ERP backend, please check your connection settings and see message logs for further details."),
                Qgis.Critical
            )
            message_log(tr("An error occourred while connecting to ERP backend: %s") % e, Qgis.Critical)
            # Setup the session status properly
            Rpc.session.open = False
            return False

        return self.status

    @refresh_indicator
    def disconnect(self):
        result = Rpc.session.logout()
        return result

    @staticmethod
    def get_databases(url):
        return Rpc.database.list(url)


def get_sentry_dsn_from_erp():
    """Fetch the Sentry DSN from ERP's res.config if connected.

    Reads the parameter with key ``qgisce.sentry_dsn`` from the ERP.

    Returns ``None`` when not connected, when the parameter is not available
    (False/None), or on known ERP/RPC exceptions (``ERPClientException``,
    ``RpcException``) silently. Unexpected exceptions are logged as a warning
    and also return ``None``. If the parameter exists but is intentionally
    empty, returns an empty string so callers can distinguish "explicitly
    cleared" from "not available".

    :return: Sentry DSN string, empty string if explicitly cleared, or None if
        not available
    :rtype: str or None
    """
    try:
        model = ERPClient.model('res.config')
        dsn = model.get('qgisce.sentry_dsn', '')
        if dsn is None or dsn is False:
            return None
        return dsn
    except (ERPClientException, RpcException):
        return None
    except Exception as e:
        message_log(tr("Unexpected error fetching Sentry DSN from ERP: %s") % e, Qgis.Warning)
        return None
