# coding=utf-8
"""Topology related functions


.. note:: This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

"""

__author__ = 'elpaso@itopen.it'
__date__ = '2018-10-22'
__copyright__ = 'Copyright 2018, GISCE-TI S.L.'

import json
from qgisceutils.i18n import tr
from qgisceutils.literals import (
    QGISCE_EDGES_LAYER_NAME,
    QGISCE_NODES_LAYER_NAME,
    QGISCE_NODES_NODE_ID_FIELD_NAME,
    QGISCE_EDGES_EDGE_ID_FIELD_NAME,
    QGISCE_GEOMETRY_MAX_DECIMAL_PLACES,
)

from qgiscegui.notifications import message_log
from qgisceutils.session import Session
from qgisceutils.layer_specs import LayerSpecs
from qgisceutils.erp_client import ERPClient
from qgis.core import (
    QgsProject,
    Qgis,
    QgsSnappingConfig,
    QgsWkbTypes,
    QgsFeature,
    QgsGeometry,
    QgsFeatureRequest,
    QgsExpression,
    QgsExpression,
    QgsRectangle,
)
from qgisceutils.project import managed_layers
from qgisceutils.literals import *


class TopologyException(Exception):
    """Base exception for topology errors"""
    pass


class EdgesLayerNotFound(TopologyException):
    """Could not find edges layer"""
    pass

class NodesLayerNotFound(TopologyException):
    """Could not find nodes layer"""
    pass


def get_nodes_layer():
    """Return the nodes layer

    :raises TopologyException: node layer not found
    :return: the nodes layer
    :rtype: QgsVectorLayer instance
    """

    try:
        return QgsProject.instance().mapLayersByName(QGISCE_NODES_LAYER_NAME)[0]
    except Exception as e:
        raise NodesLayerNotFound(
            tr("Error retrieving %s layer: %s") % (QGISCE_NODES_LAYER_NAME, e))


def get_edges_layer():
    """Return the edges layer

    :raises TopologyException: node layer not found
    :return: the edges layer
    :rtype: QgsVectorLayer instance
    """

    try:
        return QgsProject.instance().mapLayersByName(QGISCE_EDGES_LAYER_NAME)[0]
    except Exception as e:
        raise EdgesLayerNotFound(
            tr("Error retrieving %s layer: %s") % (QGISCE_EDGES_LAYER_NAME, e))


def get_topology_field_for_layer(layer):
    """Returns "node_id" for points and "edge_id" for linestrings"""

    if layer.wkbType() == QgsWkbTypes.LineString:
        return QGISCE_EDGES_EDGE_ID_FIELD_NAME
    else:
        return QGISCE_NODES_NODE_ID_FIELD_NAME


def clear_snapping_setup(*args):
    """Reset snapping setup"""

    prj = QgsProject.instance()
    cfg = prj.snappingConfig()
    cfg.setEnabled(False)
    prj.setSnappingConfig(cfg)


def snapping_setup(layer, snap_to):
    """Setup topology snapping configuration for a QGISCE topology layers

    :param layer: the layer
    :type layer: QgsVectorLayer
    :param snap_to: list of layer names to snap to
    :type snap_to: list
    """

    # Avoid circular import
    from qgisceutils.project import layer_for_catalog_id

    snapping_layers = []
    for catalog_id in snap_to:
        l = layer_for_catalog_id(catalog_id)
        if l is None:
            message_log(tr("Error retrieving snapping layer catalog id %s required by layer %s") % (
                catalog_id, layer.name()), Qgis.Critical)
        else:
            snapping_layers.append(l)

    if snapping_layers:
        prj = QgsProject.instance()
        cfg = prj.snappingConfig()
        cfg.setEnabled(True)
        cfg.setIntersectionSnapping(False)
        cfg.setMode(QgsSnappingConfig.AdvancedConfiguration)

        individual_settings = cfg.individualLayerSettings()
        for lyr, ils in individual_settings.items():
            ils.setEnabled(lyr in snapping_layers)
            cfg.setIndividualLayerSettings(lyr, ils)
        prj.setSnappingConfig(cfg)
        message_log(tr("Topology snapping enabled for layer %s" %
                       layer.name()))
    else:
        message_log(tr("Topology snapping disabled for layer %s" %
                       layer.name()))


def _parse_edge_record_name(record_data, record_id):
    """Extract the edge name from the ERP read() response, with a safe fallback.

    OpenERP's read() return shape is inconsistent: it can return False, None,
    a list of dicts, or a plain dict. A missing 'name' key or empty list falls
    back to str(record_id).
    """
    if record_data is None or record_data is False:
        message_log(tr("Failed to read edge record %s") % record_id, level=Qgis.Critical)
        return str(record_id)
    elif isinstance(record_data, list):
        if record_data and isinstance(record_data[0], dict):
            return record_data[0].get('name', str(record_id))
        else:
            message_log(tr("Unexpected edge record data for %s") % record_id, level=Qgis.Critical)
            return str(record_id)
    elif isinstance(record_data, dict):
        return record_data.get('name', str(record_id))
    else:
        message_log(tr("Unexpected edge record data for %s") % record_id, level=Qgis.Critical)
        return str(record_id)


# ToDo: Deprecated and not used. To be removed. Replace new function name with
#  this one and replace on the code
def get_edgeid(start_node_id, end_node_id, start_node_geom, end_node_geom):
    """Search and return an edge id node id for the given nodes, creates the edge if it does not exist,
    the edge is immediately committed to ERP session. The reason is that even if we could defer topology
    nodes and edges synchronization when a layer is committed we would still not be able to tell which
    edge belongs to which layer (and a
    edge could actually belong to more than one layer).

    :param start_node_id: first node id
    :type start_node_id: int
    :param end_node_id: first node id
    :type end_node_id: int
    :param start_node_geom: first node geometry
    :type start_node_id: QgsGeometry
    :param end_node_geom: second node geometry
    :type end_node_id: QgsGeometry
    :return: edge id
    :rtype: int
    """

    assert Session.is_active()

    edges_layer = get_edges_layer()

    request = QgsFeatureRequest(QgsExpression('("end_node" = {start_node_id} AND "start_node" = {end_node_id}) OR ( "end_node" =  {end_node_id} AND "start_node" = {start_node_id})'.format(
        start_node_id=start_node_id, end_node_id=end_node_id)))
    try:
        edge = next(edges_layer.getFeatures(request))
        message_log(tr("Edge id %s found") % edge['id'])
    except StopIteration:
        # Make a new edge
        edge_wkt = 'LINESTRING(%s %s, %s %s)' % (start_node_geom.vertexAt(0).x(), start_node_geom.vertexAt(
            0).y(), end_node_geom.vertexAt(0).x(), end_node_geom.vertexAt(0).y())
        layer_specs = LayerSpecs.from_layer(edges_layer)
        model = ERPClient.model(layer_specs.model)
        context = {
            'session': Session.active_id(),
            'cataleg': layer_specs.catalog_id,
            'geom': edge_wkt,
        }
        erp_data = {
            'geom': edge_wkt,
            'start_node': start_node_id,
            'end_node': end_node_id,
        }
        record_id = model.create(erp_data, context=context)
        record_data = model.read(record_id, ['name'])
        record_name = _parse_edge_record_name(record_data, record_id)

        edges_layer.setReadOnly(False)
        edges_layer.startEditing()
        edge = QgsFeature(edges_layer.fields())
        edge['start_node'] = start_node_id
        edge['end_node'] = end_node_id
        edge_wkt_geom = QgsGeometry.fromWkt(edge_wkt)
        edge.setGeometry(edge_wkt_geom)
        edge['id'] = record_id
        edge['name'] = record_name
        edges_layer.addFeatures([edge])
        edges_layer.commitChanges()
        edges_layer.rollBack()
        edges_layer.triggerRepaint()
        edges_layer.setReadOnly(True)
        edge = next(edges_layer.getFeatures(request))
        assert edge['id'], "Edge id is None!"
        assert edge['id'] == record_id
        message_log(tr("Edge id %s created" % edge['id']))
    return edge['id']


def get_edgeid_improved(start_node_geom, end_node_geom):
    """Search and return an edge id node id for the given nodes, creates the edge if it does not exist,
    the edge is immediately committed to ERP session. The reason is that even if we could defer topology
    nodes and edges synchronization when a layer is committed we would still not be able to tell which
    edge belongs to which layer (and a
    edge could actually belong to more than one layer).

    :param start_node_id: first node id
    :type start_node_id: int
    :param end_node_id: first node id
    :type end_node_id: int
    :param start_node_geom: first node geometry
    :type start_node_id: QgsGeometry
    :param end_node_geom: second node geometry
    :type end_node_id: QgsGeometry
    :return: edge id
    :rtype: int
    """

    assert Session.is_active()
    assert not start_node_geom.isNull()
    assert not end_node_geom.isNull()

    edges_layer = get_edges_layer()
    nodes_layer = get_nodes_layer()
    layer_specs = LayerSpecs.from_layer(edges_layer)
    model = ERPClient.model(layer_specs.model)
    try:
        start_node = next(nodes_layer.getFeatures(start_node_geom.boundingBox().buffered(pow(10, - QGISCE_GEOMETRY_MAX_DECIMAL_PLACES))))
    except StopIteration:
        start_node = False
    try:
        end_node = next(nodes_layer.getFeatures(end_node_geom.boundingBox().buffered(pow(10, - QGISCE_GEOMETRY_MAX_DECIMAL_PLACES))))
    except StopIteration:
        end_node = False

    # Si algun dels dos nodes no existeix, l'edge tampoc per tant, no cal que fem request.
    if not end_node or not start_node:
        # Crear edge i nodes restants
        edge_wkt = 'LINESTRING(%s %s, %s %s)' % (start_node_geom.vertexAt(0).x(), start_node_geom.vertexAt(0).y(), end_node_geom.vertexAt(0).x(), end_node_geom.vertexAt(0).y())
        edge_values = {}
        edge_values['geom'] = edge_wkt
        if start_node:
            edge_values['start_node'] = start_node['id']
        else:
            edge_values['start_node'] = [[0, 0, {'geom': start_node_geom.asWkt()}]]
        if end_node:
            edge_values['end_node'] = end_node['id']
        else:
            edge_values['end_node'] = [[0, 0, {'geom': end_node_geom.asWkt()}]]
        context = {
            'session': Session.active_id(),
            'cataleg': layer_specs.catalog_id,
            'geom': edge_wkt,
        }
        edge_data = model.create_qread(
            edge_values, ['start_node', 'end_node', 'id', 'name'],
            context, '_classic_read'
        )
        edges_layer.setReadOnly(False)
        edges_layer.startEditing()
        edge = QgsFeature(edges_layer.fields())
        edge['start_node'] = edge_data['start_node'][0]
        edge['end_node'] = edge_data['end_node'][0]
        edge_wkt_geom = QgsGeometry.fromWkt(edge_wkt)
        edge.setGeometry(edge_wkt_geom)
        edge['id'] = edge_data['id']
        edge['name'] = edge_data['name']
        edges_layer.addFeatures([edge])
        edges_layer.commitChanges()
        edges_layer.rollBack()
        edges_layer.triggerRepaint()
        edges_layer.setReadOnly(True)
        if not end_node:
            # crear end node
            nodes_layer.setReadOnly(False)
            nodes_layer.startEditing()
            node = QgsFeature(nodes_layer.fields())
            node['id'] = edge_data['end_node'][0]
            node['name'] = edge_data['end_node'][1]
            node.setGeometry(end_node_geom)
            nodes_layer.addFeatures([node])
            nodes_layer.commitChanges()
            nodes_layer.triggerRepaint()
            nodes_layer.setReadOnly(True)
        if not start_node:
            # crear start node
            nodes_layer.setReadOnly(False)
            nodes_layer.startEditing()
            node = QgsFeature(nodes_layer.fields())
            node['id'] = edge_data['start_node'][0]
            node['name'] = edge_data['start_node'][1]
            node.setGeometry(start_node_geom)
            nodes_layer.addFeatures([node])
            nodes_layer.commitChanges()
            nodes_layer.triggerRepaint()
            nodes_layer.setReadOnly(True)
    else:
        # Si existeixen els 2 nodes, pot ser que l'edge tambe, tot i que com ho estem estructurant ara seria extrany. Hauriem de fer la request per mirar de trobar-lo
        request = QgsFeatureRequest(QgsExpression('("end_node" = {start_node_id} AND "start_node" = {end_node_id}) OR ( "end_node" =  {end_node_id} AND "start_node" = {start_node_id})'.format(start_node_id=start_node['id'], end_node_id=end_node['id'])))
        try:
            edge = next(edges_layer.getFeatures(request))
            message_log(tr("Edge id %s found") % edge['id'])
        except StopIteration:
            # Creem l'edge a partir de 2 nodes que ja existeixen.
            edge_wkt = 'LINESTRING(%s %s, %s %s)' % (start_node_geom.vertexAt(0).x(), start_node_geom.vertexAt(0).y(), end_node_geom.vertexAt(0).x(), end_node_geom.vertexAt(0).y())
            edge_values = {
                'geom': edge_wkt,
                'start_node': start_node['id'],
                'end_node': end_node['id'],
            }
            context = {
                'session': Session.active_id(),
                'cataleg': layer_specs.catalog_id,
                'geom': edge_wkt,
            }
            edge_data = model.create_qread(
                edge_values, ['id', 'name'], context, '_classic_read'
            )
            edges_layer.setReadOnly(False)
            edges_layer.startEditing()
            edge = QgsFeature(edges_layer.fields())
            edge['start_node'] = start_node['id']
            edge['end_node'] = end_node['id']
            edge_wkt_geom = QgsGeometry.fromWkt(edge_wkt)
            edge.setGeometry(edge_wkt_geom)
            edge['id'] = edge_data['id']
            edge['name'] = edge_data['name']
            edges_layer.addFeatures([edge])
            edges_layer.commitChanges()
            edges_layer.rollBack()
            edges_layer.triggerRepaint()
            edges_layer.setReadOnly(True)
    return edge['id']


def get_nodeid(point_geom):
    """Search and return a node id for a given point geometry, creates the node if it does not exist,
    the node is immediately committed to ERP session. The reason is that even if we could defer topology
    nodes and edges synchronization when a layer is committed we would still not be able to tell
    which node belongs to which layer (and a node could actually belong to more than one layer).

    :param point_geom: point geometry
    :type point_geom: QgsGeometry
    :return: node id
    :rtype: int
    """

    assert Session.is_active()
    assert not point_geom.isNull()

    nodes_layer = get_nodes_layer()
    try:
        node = next(nodes_layer.getFeatures(point_geom.boundingBox().buffered(
            pow(10, - QGISCE_GEOMETRY_MAX_DECIMAL_PLACES))))
        message_log(tr("Node id %s found") % node['id'])
    except StopIteration:
        # Make a new node
        layer_specs = LayerSpecs.from_layer(nodes_layer)
        model = ERPClient.model(layer_specs.model)
        context = {
            'session': Session.active_id(),
            'cataleg': layer_specs.catalog_id,
            'geom': point_geom.asWkt(),
        }
        node_values = {
            'geom': point_geom.asWkt(),
        }
        node_data = model.create_qread(
            node_values, ['id', 'name'], context, '_classic_read'
        )
        nodes_layer.setReadOnly(False)
        nodes_layer.startEditing()
        node = QgsFeature(nodes_layer.fields())
        node['id'] = node_data['id']
        node['name'] = node_data['name']
        node.setGeometry(point_geom)
        nodes_layer.addFeatures([node])
        nodes_layer.commitChanges()
        nodes_layer.triggerRepaint()
        nodes_layer.setReadOnly(True)
        node = next(nodes_layer.getFeatures(point_geom.boundingBox()))
        message_log(tr("Node id %s created" % node['id']))
    return node['id']


def topology_checker(layer, layer_specs, change_type, fid, *args):
    """Slot to create edges and nodes and fill feature and erp_data fields

    Note that this needs happening right before the changes for the feature have been sent to ERP
    because we need the edge_id or the node_id to be defined before we can set the value in the
    topology layers.

    :param layer: input layr
    :type layer: QgsVectorLayer
    :param layer_specs: layer specs
    :type layer_specs: LayerSpecs
    :param change_type: type of change
    :type change_type: Session.ChangeType
    :param fid: QGIS internal feature id
    :type fid: int
    :raises TopologyException:
    :return: id of the created node or edge
    :rtype: int
    """


    nodes_layer = get_nodes_layer()

    if nodes_layer is None:
        message_log(tr("Error retrieving layer: %s") %
                    QGISCE_NODES_LAYER_NAME, Qgis.Critical)
        return

    # Get feature information
    feature = layer.getFeature(fid)
    assert feature.isValid()
    geometry = feature.geometry()
    assert not geometry.isNull()

    # Find a node/edge to snap
    if layer.wkbType() == QgsWkbTypes.LineString:
        vertices = [v for v in geometry.vertices()]
        # Remove consecutive duplicate vertices to avoid degenerate geometries
        cleaned = [vertices[0]] if vertices else []
        for pt in vertices[1:]:
            if pt.x() != cleaned[-1].x() or pt.y() != cleaned[-1].y():
                cleaned.append(pt)
        vertices = cleaned
        if len(vertices) < 2:
            raise TopologyException(
                tr("A line must have at least two vertices in layer: %s") % layer.name())
        if vertices[0].x() == vertices[-1].x() and vertices[0].y() == vertices[-1].y():
            raise TopologyException(
                tr("Line start and end vertices are at the same position in layer: %s") % layer.name())
        node1_geom = QgsGeometry.fromWkt(vertices[0].asWkt())
        node2_geom = QgsGeometry.fromWkt(vertices[-1].asWkt())
        edge_id = get_edgeid_improved(node1_geom, node2_geom)
        message_log(tr("Edge id is %s for feature id %s") %
                    (edge_id, feature.id()))
        return edge_id
    elif layer.wkbType() == QgsWkbTypes.Point:
        node_id = get_nodeid(geometry)
        message_log(tr("Node id set to %s for feature id %s") %
                    (node_id, feature.id()))
        return node_id
    else:
        raise TopologyException("Only linestring and points are supported.")

    raise TopologyException("Error creating node or edge.")

def get_elements_for_node(node_id, bbox=None, get_edges=True):
    """Search all QGISCE vector layers and the edges layers for elements linked to a given node

    :param node_id: node id
    :type node_id: int
    :return: the features grouped by layer name
    :rtype: a dictionary with layer name as key and QgsFeature list as value
    """

    results = {}
    req = QgsFeatureRequest(QgsExpression('"node_id" = %s' % node_id))
    edge_req = QgsFeatureRequest(QgsExpression('"end_node" = {node_id} OR "start_node" = {node_id}'.format(node_id=node_id)))

    for catalog_id, layer in managed_layers().items():
        if QGISCE_NODES_NODE_ID_FIELD_NAME in layer.fields().names():
            features = [f for f in layer.getFeatures(req)]
            if features:
                results[layer.name()] = features
    # When testing, edges layer might not be available
    try:
        edges_layer = get_edges_layer()
        if edges_layer:
            edges = [f for f in edges_layer.getFeatures(edge_req)]
            if edges:
                if get_edges:
                    results[edges_layer.name()] = edges
                else:
                    for edge in edges:
                        edge_id_req = QgsFeatureRequest(
                            QgsExpression('"edge_id" = %s' % edge['id'])
                        )
                        for catalog_id, layer in managed_layers().items():
                            if QGISCE_EDGES_EDGE_ID_FIELD_NAME in layer.fields().names():
                                features = [f for f in layer.getFeatures(edge_id_req)]
                                if features:
                                    if layer.name() in results:
                                        results[layer.name()] = results[layer.name()] + features
                                    else:
                                        results[layer.name()] = features
    except EdgesLayerNotFound as e:
        message_log("Edges layer is not availabe, if this happens in a test case it may be acceptable, otherwise check your code for errors!", Qgis.Critical)
    return results


def get_elements_for_edge(edge_id, bbox=None):
    """Search all QGISCE vector layers for elements linked to a given edge

    :param edge_id: edge id
    :type edge_id: int
    :return: the features grouped by layer name
    :rtype: a dictionary with layer name as key and QgsFeature list as value
    """

    results = {}
    req = QgsFeatureRequest(QgsExpression('"edge_id" = %s' % edge_id))
    for catalog_id, layer in managed_layers().items():
        if QGISCE_EDGES_EDGE_ID_FIELD_NAME in layer.fields().names():
            features = [f for f in layer.getFeatures(req)]
            if features:
                results[layer.name()] = features
    return results


def get_dangling_nodes(bbox=None):
    """Return a list of node features that are not connected to any element

    :return: list of unconnected nodes QgsFeatures
    :rtype: list
    """
    req = QgsFeatureRequest().setSubsetOfAttributes([0])
    if bbox is not None:
        assert isinstance(bbox, QgsRectangle)
        req.setFilterRect(bbox).setFlags(QgsFeatureRequest.ExactIntersect)
    dangling_nodes = []
    for node in get_nodes_layer().getFeatures(req):
        if not get_elements_for_node(node['id'], node.geometry().boundingBox()):
            dangling_nodes.append(node)
    return dangling_nodes


def get_dangling_edges(bbox=None):
    """Return a list of edge features that are not connected to any element

    :return: list of unconnected edges QgsFeatures
    :rtype: list
    """

    req = QgsFeatureRequest().setSubsetOfAttributes([0])
    if bbox is not None:
        assert isinstance(bbox, QgsRectangle)
        req.setFilterRect(bbox).setFlags(QgsFeatureRequest.ExactIntersect)
    dangling_edges = []
    for edge in get_edges_layer().getFeatures(req):
        if not get_elements_for_edge(edge['id']):
            dangling_edges.append(edge)
    return dangling_edges


def topology_garbage_collect(bbox=None, layer_specs=None):
    """Delete all nodes and edges that are not connected to any element if
    there's no changes to be commited on any Qgisce managed layers.

    Note: topology layers are manually synchronized and direct calls to
          ERP are performed in this function.
    """
    # Check if is possible to run the garbage collector
    layers = managed_layers()
    electrical_topology_layers = []
    for catalog_id in layers:
        layer = layers[catalog_id]
        layer_specs_tmp = LayerSpecs.from_layer(layer)
        if layer_specs_tmp.model in QGISCE_TOPOLOGY_MODEL_NAMES:
            electrical_topology_layers.append(layer_specs_tmp.model)
        if layer_specs_tmp.model not in QGISCE_TOPOLOGY_MODEL_NAMES and layer.isEditable():
            buf = layer.editBuffer()
            has_pending = (
                len(buf.changedGeometries()) != 0
                or len(buf.changedAttributeValues()) != 0
                or len(buf.addedFeatures()) != 0
                or len(buf.deletedFeatureIds()) != 0
            )
            if has_pending and layer_specs.model!=layer_specs_tmp.model:
                # Still buffered changes to be saved
                return
    if sorted(electrical_topology_layers) != sorted(QGISCE_TOPOLOGY_MODEL_NAMES):
        return

    # Start topology garbage collector
    dangling_edges = get_dangling_edges(bbox)
    if dangling_edges:
        layer = get_edges_layer()
        was_editable = layer.isEditable()
        if not was_editable:
            layer.setReadOnly(False)
            layer.startEditing()
        erp_ids = [f['id'] for f in dangling_edges]
        if erp_ids:
            layer_specs = LayerSpecs.from_layer(layer)
            model = ERPClient.model(layer_specs.model)
            context = {
                'cataleg': layer_specs.catalog_id,
            }
            if Session.active_id():
                context['session'] = Session.active_id()
            if erp_ids:
                model.unlink(erp_ids, context=context)
            layer.deleteFeatures([f.id() for f in dangling_edges])
            layer.commitChanges()
            if not was_editable:
                layer.rollBack()
                layer.setReadOnly(True)
            message_log('Dangling Edges deleted: %s' % erp_ids)

    dangling_nodes = get_dangling_nodes(bbox)
    if dangling_nodes:
        layer = get_nodes_layer()
        was_editable = layer.isEditable()
        if not was_editable:
            layer.setReadOnly(False)
            layer.startEditing()
        erp_ids = [f['id'] for f in dangling_nodes]
        if erp_ids:
            layer_specs = LayerSpecs.from_layer(layer)
            model = ERPClient.model(layer_specs.model)
            context = {
                'cataleg': layer_specs.catalog_id,
            }
            if Session.active_id():
                context['session'] = Session.active_id()
            if erp_ids:
                model.unlink(erp_ids, context=context)
            layer.deleteFeatures([f.id() for f in dangling_nodes])
            layer.commitChanges()
            if not was_editable:
                layer.rollBack()
                layer.setReadOnly(True)
            message_log('Dangling Nodes deleted: %s' % erp_ids)
