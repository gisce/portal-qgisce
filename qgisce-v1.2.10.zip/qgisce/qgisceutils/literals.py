# coding=utf-8
"""Literals

.. note:: This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

"""

__author__ = 'elpaso@itopen.it'
__date__ = '2018-05-25'
__copyright__ = 'Copyright 2018, GISCE-TI S.L.'

QGISCE_LAYER_CUSTOM_PROPERTY_MODEL_DESCRIPTIVE_NAME = \
    "qgisce_model_descriptive_name"
QGISCE_LAYER_CUSTOM_PROPERTY_MODEL_ID = "qgisce_model_id"
QGISCE_LAYER_CUSTOM_PROPERTY_Z_INDEX = "qgisce_z_index"
QGISCE_LAYER_CUSTOM_PROPERTY_MODEL_INTERNAL_NAME = "qgisce_model_internal_name"
QGISCE_LAYER_CUSTOM_PROPERTY_LOADING_COMPLETED = "qgisce_loading_status"
QGISCE_LAYER_CUSTOM_PROPERTY_BBOX = "qgisce_bbox"
QGISCE_LAYER_CUSTOM_PROPERTY_FIELDS = "qgisce_fields"
QGISCE_LAYER_CUSTOM_PROPERTY_DOMAIN = "qgisce_domain"
QGISCE_LAYER_CUSTOM_PROPERTY_SYMBOL_NAME = "qgisce_symbol_name"
QGISCE_LAYER_CUSTOM_PROPERTY_STYLE_NAME = "qgisce_style_name"
QGISCE_LAYER_CUSTOM_PROPERTY_FIELD_MAPPING = "qgisce_field_mapping"
QGISCE_LAYER_CUSTOM_PROPERTY_CATALOG_ID = "qgisce_catalog_id"
QGISCE_LAYER_CUSTOM_PROPERTY_NOT_TOPOLOGY = "qgisce_not_topology"
QGISCE_LAYER_CUSTOM_PROPERTY_READ_ONLY = "qgisce_read_only"
QGISCE_LAYER_CUSTOM_PROPERTY_SNAP_TO = "qgisce_snap_to"
QGISCE_CATALOG_MODEL_NAME = "giscegis.cataleg.cataleg"
QGISCE_GETSRID_METHOD_NAME = "giscegis.base.geom"
QGISCE_SESSION_MODEL_NAME = "giscegis.session"
QGISCE_SESSION_CHANGES_MODEL_NAME = "giscegis.session.changes"
QGISCE_ERP_DATA_FIELD_NAME = "erp_data"
QGISCE_GEOM_FIELD_NAME = 'geom'
QGISCE_PROJECT_VARIABLE_CATALOG_AUTOLOAD = 'qgisce_catalog_autoload'
QGISCE_PROJECT_VARIABLE_TEMPLATE_VERSION = 'qgisce_template_version'
QGISCE_NODES_LAYER_NAME = 'Node'
QGISCE_NODES_MODEL_NAME = 'giscegis.nodes'
QGISCE_EDGES_LAYER_NAME = 'Edge'
QGISCE_EDGES_MODEL_NAME = 'giscegis.edge'
QGISCE_NETWORK_MODEL_NAME = 'giscegis.network'
QGISCE_NODES_NODE_ID_FIELD_NAME = 'node_id'
QGISCE_EDGES_EDGE_ID_FIELD_NAME = 'edge_id'
QGISCE_TOPOLOGY_MODEL_NAMES = [
    QGISCE_NODES_MODEL_NAME,
    QGISCE_EDGES_MODEL_NAME
]
QGISCE_SESSION_HIDDEN_LAYERS = [
    QGISCE_NODES_LAYER_NAME,
    QGISCE_EDGES_LAYER_NAME
]
QGISCE_TOPOLOGY_LAYER_NAMES = [
    QGISCE_NODES_LAYER_NAME,
    QGISCE_EDGES_LAYER_NAME
]
QGISCE_ERP_DATA_SYNC_FIELDS = [
    'rotation',
    QGISCE_NODES_NODE_ID_FIELD_NAME,
    QGISCE_EDGES_EDGE_ID_FIELD_NAME
]
QGISCE_GEOMETRY_MAX_DECIMAL_PLACES = 3

QGIS_MOVE_FEATURE_ACTIONS_NAMES = ['mActionMoveFeature', 'mActionMoveFeatureCopy']

# Used for newly added features
QGISCE_DEFERRED_CREATION_FIELD_NAME = 'erp_deferred_creation'


# If this is set in erp_data changes values, it will trigger
# a real ERP update, if not set, the changes will not be sent to ERP
QGISCE_ERP_DATA_UPDATE_TRIGGER_PROPERTY = '__update__trigger__'

# ACOTACIONS MODELS
QGISCE_ACOTACIONS_MODEL_NAMES = [
    'giscegis.rases.acotacio.linia.auxiliar',
    'giscegis.rases.acotacio.text.auxiliar',
    'giscegis.rases.acotacio'
]
