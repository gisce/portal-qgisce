# coding=utf-8
"""ERP client singleton implementation


.. note:: This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

"""

__author__ = 'elpaso@itopen.it'
__date__ = '2018-05-24'
__copyright__ = 'Copyright 2018, GISCE-TI S.L.'

from functools import partial

from Koo.Rpc import Rpc, RpcException, Client
import socket

class ERPClientException(Exception):
    """Base ERPClient exception"""
    pass


class ERPClientNotConnectedException(ERPClientException):
    """Client is not connected"""
    pass


class ClientQgisce(Client):
    def execute(self, obj, method, *params, **kwargs):
        socket.setdefaulttimeout(None)
        ret = super(ClientQgisce, self).execute(obj, method, *params, **kwargs)
        return ret


class ModelWrapper(object):

    __slots__ = ('object', )

    def __init__(self, object):
        self.object = object

    def call(self, method, *args):
        return Rpc.session.call(
            '/object', 'execute', self.object, method, *args
        )

    def __getattr__(self, item):
        def wrapper(*args, **kwargs):
            context = kwargs.pop('context', None)
            if context:
                args = args + (context, )
            socket.setdefaulttimeout(None)
            return self.call(item, *args)
        return wrapper


class ERPClient(object):
    """Static ERP client

    Usage:

    model = ERPClient.model(QGISCE_CATALOG_MODEL_NAME)
    model.fields()
    """

    def __init__(self):
        raise Exception("Do not instanciate this class directly! Call model('model_name') instead.")

    @classmethod
    def model_erppek(cls, model_name):
        """Instanciate and ERPPeek model

        :param model_name: the model internal name
        (for example: 'giscedata.cups.escomesa')
        :type model_name: str
        :raises ERPClientNotConnectedException: connection error
        :raises ERPClientException: generic protocol error
        :return: ERPPeek model client instance
        :rtype: Client instance
        """

        if not Rpc.session.logged():
            raise ERPClientNotConnectedException()

        try:
            qgisce_client = getattr(Rpc.session, 'qgisce_client', None)
            if not qgisce_client:
                Rpc.session.qgisce_client = ClientQgisce(Rpc.session)
            return Rpc.session.qgisce_client.model(model_name)
        except RpcException as e:
            raise ERPClientException(str(e))

    @classmethod
    def call(cls, obj, *args):
        return Rpc.session.call(obj, *args)

    @classmethod
    def model_rpc(cls, model_name):
        if not Rpc.session.logged():
            raise ERPClientNotConnectedException()
        try:
            return ModelWrapper(model_name)
        except RpcException as e:
            raise ERPClientException(str(e))

    model = model_rpc
