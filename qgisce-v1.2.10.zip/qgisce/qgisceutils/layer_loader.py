# coding=utf-8
"""QGIS Task to load layer data from ERP in background


.. note:: This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

"""

__author__ = 'elpaso@itopen.it'
__date__ = '2018-05-24'
__copyright__ = 'Copyright 2018, GISCE-TI S.L.'

import copy
import json
import os
import traceback
from collections import OrderedDict

from qgis.core import (Qgis, QgsApplication, QgsCoordinateReferenceSystem,
                       QgsEditFormConfig, QgsFeatureRequest, QgsGeometry,
                       QgsMessageLog, QgsProject, QgsProperty, QgsRectangle,
                       QgsTask, QgsWkbTypes)
from qgis.PyQt import QtCore
from qgis.utils import iface

# Import Message logger
from qgiscegui.notifications import message_bar, message_log
from qgisceutils.catalog import Catalog
from qgisceutils.config import QgisceConfig
from qgisceutils.erp_client import ERPClient, ERPClientException
# Import translation function
from qgisceutils.i18n import tr
from qgisceutils.json_layer import ERP_FIELDS, JSONLayer
from qgisceutils.literals import (QGISCE_CATALOG_MODEL_NAME,
                                  QGISCE_GEOM_FIELD_NAME,
                                  QGISCE_GETSRID_METHOD_NAME,
                                  QGISCE_TOPOLOGY_MODEL_NAMES,
                                  QGISCE_SESSION_MODEL_NAME,
                                  QGISCE_ACOTACIONS_MODEL_NAMES)
from qgisceutils.project import (layer_for_catalog_id,
                                 layer_set_loading_completed,
                                 z_index_for_layer)
from qgisceutils.taskwrapper import TaskWrapper

# Chache these: they are not going to change!
__srid = None
__crs = None

CACHED_ELEMENTS_IDS = {}

def get_srid():
    """Query ERP for the SRID and returns its value

    :return: the ERP project SRID
    :rtype: integer
    """
    global __srid
    # Skip cache on CI
    if __srid is None or os.environ.get('CI', None):
        __srid = ERPClient.model(QGISCE_GETSRID_METHOD_NAME).get_srid()
        message_log("SRID received: %s" % __srid, Qgis.Info)
    return __srid


def get_crs():
    """Query ERP for the SRID and returns its value as
    QgsCoordinateReferenceSystem instance

    :return: the ERP project SRID
    :rtype: integer
    """
    global __crs
    # Skip cache on CI
    if __crs is None or os.environ.get('CI', None):
        __crs = QgsCoordinateReferenceSystem('EPSG:%s' % get_srid())
    return __crs


class WorkerSignal(QtCore.QObject):
    """QObject signal container for the worker task
    (which is not based on QObject)"""

    features_ready = QtCore.pyqtSignal(object, object)
    progressChanged = QtCore.pyqtSignal(float)
    taskCompleted = QtCore.pyqtSignal()


class LayerLoaderWorker(QtCore.QRunnable):
    """Main worker task for loading layers"""

    def __init__(self, description, on_finished, raise_exceptions, layer_specs, bbox, session_id, json_layer, visible_only, *args, **kwargs):
        """Main worker task for loading layers

        :param description: description
        :type description: str
        :param on_finished: callback when task is finished (FIXME: unused)
        :type on_finished: callable
        :param raise_exceptions: flag to raise exceptions
        :type raise_exceptions: bool
        :param layer_specs: layer specs
        :type layer_specs: LayerSpecs instance
        :param bbox: bounding box
        :type bbox: QgsRectangle instance
        :param session_id: session id
        :type session_id: int
        :param json_layer: JSON layer object
        :type json_layer: JSONLayer instance
        :param visible_only: if only visible layers at current canvas scale must be downloaded
        :type visible_only: bool
        """

        super(LayerLoaderWorker, self).__init__()
        self.setAutoDelete(False)
        self.description = description
        self.args = args
        self.layer_specs = layer_specs
        self.bbox = bbox
        self.session_id = session_id
        self.json_layer = json_layer
        self.target_layer = json_layer.target_layer  # Legacy
        self.visible_only = visible_only
        self.kwargs = kwargs
        self.raise_exceptions = raise_exceptions
        self.on_finished = on_finished
        self.returned_values = None
        self.exception = None
        self.is_canceled = False
        self.is_finished = False
        self.signals = WorkerSignal()
        self.signals.features_ready.connect(
            self.json_layer.load_features, QtCore.Qt.QueuedConnection)
        self.progress = 0
        self.features_count = 0

    def setProgress(self, progress):
        self.progress = progress
        self.signals.progressChanged.emit(progress)

    def cancel(self):
        self.is_canceled = True

    def isCanceled(self):
        return self.is_canceled

    def loader_function(self, layer_specs, bbox, session_id, json_layer, visible_only):
        """The loader task downloads the features from ERP in chunks and emits
        features_ready passing feature data to the listener in the main thread.

        :param task: the QgsTask
        :type task: QgsTask
        :param layer_specs: layer information
        :type layer_specs: LayerSpecs instance
        :param bbox: bounding box in ERP's CRS
        :type bbox: QgsRectangle
        :param session_id: session id
        :type session_id: int
        :param json_layer: destination JSON layer
        :type json_layer: JSONLayer
        :param visible_only: only download visible in-scale layers
        :type visible_only: bool
        :return: tuple of (LayerSpecs, features_data, session_id, target_layer)
        :rtype: tuple
        """
        global CACHED_ELEMENTS_IDS
        if self.isCanceled():
            return layer_specs, None, session_id, json_layer.target_layer
        message_log(
            "Loader function started for %s, catalog id %s, session id: %s" %
            (layer_specs.model_name, layer_specs.catalog_id, session_id),
            Qgis.Info
        )
        self.setProgress(1)
        model = ERPClient.model(layer_specs.model)

        # Ensure CACHED_ELEMENTS_IDS is populated for this catalog_id
        catalog_id_str = str(layer_specs.catalog_id)
        if catalog_id_str not in CACHED_ELEMENTS_IDS:
            # Fallback: fetch IDs for this single layer
            catalog_model = ERPClient.model(QGISCE_CATALOG_MODEL_NAME)
            try:
                result = catalog_model.fetch_res_ids(
                    [layer_specs.catalog_id], session_id, bbox.asWktPolygon()
                )
                CACHED_ELEMENTS_IDS.update(result)
            except Exception as e:
                message_log(
                    f"Warning: fetch_res_ids failed for catalog {layer_specs.catalog_id}: {e}",
                    Qgis.Warning
                )
                # Ultimate fallback: use empty list
                CACHED_ELEMENTS_IDS[catalog_id_str] = []
        
        fids = CACHED_ELEMENTS_IDS.get(catalog_id_str, [])

        context = {}
        if session_id is not None:
            context['session'] = session_id
        context['cataleg'] = layer_specs.catalog_id

        if self.isCanceled():
            return layer_specs, None, session_id, json_layer.target_layer

        self.features_count = len(fids)

        if fids and not self.isCanceled():
            message_log("Downloading %s %s features started ..." % (len(fids), layer_specs.model_name), Qgis.Info)

            # Check that all required fields are actually in the layer
            fields_to_fetch = ERP_FIELDS + layer_specs.fields
            fields_to_fetch.append(QGISCE_GEOM_FIELD_NAME)
            for fld in fields_to_fetch:
                if '.' in fld:
                    fld = fld.split('.')[0]
                if fld not in layer_specs.field_mapping:
                    fields_to_fetch.remove(fld)

            # Chunk
            i = 0
            feature_counter = 0
            chunk_size = 1000

            def chunks(l, n):
                """Yield successive n-sized chunks from l."""
                for x in range(0, len(l), n):
                    yield l[x:x + n]

            for chuncked_fids in chunks(fids, chunk_size):
                chuncked_f_data = model.qread(
                    chuncked_fids, fields_to_fetch, context, '_classic_write'
                )
                if self.isCanceled():
                    return (
                        layer_specs, None, session_id,
                        json_layer.target_layer
                    )
                progress = int(i * chunk_size / len(fids) * 100)
                self.setProgress(progress)
                if self.isCanceled():
                    return (
                        layer_specs, None, session_id,
                        json_layer.target_layer
                    )
                self.signals.features_ready.emit(chuncked_f_data, self)
                i += 1
                feature_counter += len(chuncked_f_data)

            message_log("Session: %s - %s features for %s id %s downloaded successfully" % (
                session_id,
                feature_counter,
                layer_specs.model_name,
                layer_specs.catalog_id
            ), Qgis.Success)
        else:
            message_log("Session: %s - there are 0 features for %s id %s: skipping download" % (
                session_id,
                layer_specs.model_name,
                layer_specs.catalog_id
            ), Qgis.Success)

        self.setProgress(100)
        self.signals.taskCompleted.emit()
        return layer_specs, None, session_id, json_layer.target_layer

    def run(self):
        try:
            # Download
            self.returned_values = self.loader_function(
                self.layer_specs, self.bbox, self.session_id, self.json_layer, self.visible_only)
        except Exception as ex:
            if self.raise_exceptions:
                raise ex
            # report error
            self.exception = ex
            self.is_finished = True
        self.is_finished = True
        self.finished(self.returned_values)

    def finished(self, result):
        if not self.on_finished:
            return

        if not result and self.exception is None:
            self.exception = Exception('Task canceled')

        try:
            if self.returned_values:
                self.on_finished(self.exception, self.returned_values)
            else:
                self.on_finished(self.exception)
        except Exception as ex:
            if self.raise_exceptions:
                raise ex
            self.exception = ex


class MainLoaderTask(QgsTask):
    """Async loader for a set of layers"""

    threads_started = QtCore.pyqtSignal()

    def __init__(self, sub_tasks):
        super(MainLoaderTask, self).__init__(
            tr("Load layers from remote ERP server"))
        self.sub_tasks = sub_tasks
        for st in self.sub_tasks:
            st.signals.progressChanged.connect(self._main_task_set_progress)
        self.is_canceled = False
        self.exception = None

    def _main_task_set_progress(self, progress):
        progress = 0
        for st in self.sub_tasks:
            progress += st.progress
        self.setProgress(progress / len(self.sub_tasks))

    def __del__(self):
        self.cancel()

    def subtasks_canceled(self):
        if not self.sub_tasks:
            return True
        for st in self.sub_tasks:
            if not st.isCanceled():
                return False
        return True

    def subtasks_running(self):
        if not self.sub_tasks:
            return False
        for st in self.sub_tasks:
            if not (st.is_finished or st.is_canceled):
                return True
        return False

    def cancel(self):
        self.is_canceled = True
        for st in self.sub_tasks:
            st.cancel()
        while not self.subtasks_canceled():
            message_log(tr("Waiting for main loader to stop subtasks ..."))

    def run(self):
        try:
            for st in self.sub_tasks:
                if self.is_canceled:
                    return False
                if self.download_mode_multithread():
                    # THIS IS ACTUALLY BROKEN BY SOME REASON, ANYWAY, WITH THE
                    # ACTUAL IMPLEMENTATION OF THE LAYERS DOWNLOAD, IT'S FAST
                    # ENOUGHT IN SEQUENTIAL MODE
                    QtCore.QThreadPool.globalInstance().setMaxThreadCount(
                        self.threads()
                    )
                    QtCore.QThreadPool.globalInstance().start(st)
                else:
                    st.run()  # Serialized version
            self.threads_started.emit()
            # Block
            while self.subtasks_running():
                pass
        except Exception as ex:
            self.exception = ex
            return False
        return True

    def download_mode_multithread(self):
        """Check whether download mode is
                0 - Sequential
                1 - Multithread

        :return: download mode
        :rtype: bool
        """

        # if QgisceConfig.get('qgisce_download', 1, data_type=int):
        #     return True
        # else:
        #     return False
        # ALWAYS RETURN FALSE BY NOW
        return False

    def threads(self):
        """Check number of threads defined in configuration

        :return: threads
        :rtype: integer
        """

        return int(QgisceConfig.get('qgisce_threads'))


def on_loader_finished(e, results=None):
    """This is the callback for finished tasks

    :param e: exception, can be None
    :type e: Exception
    :param results: task results (layer_specs, target_layer)
    :type results: tuple
    """

    if e is not None:
        if str(e) != 'Task canceled':
            message_bar(tr("Error"), tr("Error downloading layer: %s<br/>%s") %
                        (e, '<br/>'.join(traceback.format_tb(e.__traceback__))), Qgis.Critical)
        else:
            message_log(tr('Layer loader has been canceled by the user.'))
    else:
        if not results:
            message_bar(tr("Error"), tr(
                "Error downloading layer: no returned values!"), Qgis.Critical)
        else:
            try:
                layer_specs = results[0]
                target_layer = results[3]
                # Repaint the layer
                target_layer.triggerRepaint()
                layer_set_loading_completed(target_layer, True)
            except (ValueError, KeyError) as e:
                message_bar(
                    tr("Error"),
                    tr("Error downloading layer: returned values are incomplete! %s") % e,
                    Qgis.Critical
                )


def __layer_loader(layer_specs, bbox, session_id=None, visible_only=True, raise_exceptions=False):
    """Loads a layer form ERP remote server and add it to the QGIS canvas

    :param layer_specs: layer information
    :type layer_specs: LayerSpecs instance
    :param bbox: bounding box in ERP's CRS
    :type bbox: QgsRectangle
    :param session_id: session id
    :type session_id: int
    :param visible_only: if only visible in-scale layers have to be downloaded
    :type visible_only: bool
    :return: the dowloader task
    :rtype: QgsTask
    """
    assert session_id is None or isinstance(session_id, int)
    # Prepare the target layer, create if not exists
    json_layer = JSONLayer(
        layer_specs, [])

    # Only add the layer if it's not already in the project
    if json_layer.target_layer.id() not in QgsProject.instance().mapLayers().keys():
        message_log(tr("Adding layer %s") % layer_specs.layer_name)
        QgsProject.instance().addMapLayer(json_layer.target_layer, False)
        # Ensure group
        root = QgsProject.instance().layerTreeRoot()

        # Tune group name if it's a topological model (nodes, edges)
        group_name = layer_specs.model_name
        if layer_specs.model in QGISCE_TOPOLOGY_MODEL_NAMES:
            group_name = tr("Topology")
        elif layer_specs.model in QGISCE_ACOTACIONS_MODEL_NAMES:
            group_name = tr("Acotació")

        group = root.findGroup(group_name)
        if not group:
            group_position = 0

            class _GroupFoundException(Exception):
                pass
            try:
                if layer_specs.z_index != 0:
                    i = 0
                    for existing_group in root.findGroups():
                        for l in existing_group.findLayers():
                            if z_index_for_layer(l.layer()) and z_index_for_layer(l.layer()) > layer_specs.z_index:
                                group_position = i
                                raise _GroupFoundException()
                        i += 1
            except _GroupFoundException:
                pass
            finally:
                if layer_specs.model == QGISCE_SESSION_MODEL_NAME:
                    root.insertLayer(group_position, json_layer.target_layer)
                    group = None
                else:
                    group = root.insertGroup(group_position, group_name)
        if group is not None:
            layer_position = 0
            i = 0
            for l in group.findLayers():
                if z_index_for_layer(l.layer()) and z_index_for_layer(l.layer()) > layer_specs.z_index:
                    layer_position = i
                    break
                i += 1
            group.insertLayer(layer_position, json_layer.target_layer)

    task = LayerLoaderWorker(
        "Loading %s ..." % layer_specs.layer_name,
        on_loader_finished,
        raise_exceptions,
        layer_specs,
        bbox,
        session_id,
        json_layer,
        visible_only
    )
    message_log('Worker created for %s' % layer_specs.layer_name)
    # task.setDependentLayers([json_layer.target_layer])
    return task


def layer_loader(layer_specs, bbox=QgsRectangle(), session_id=None, visible_only=True):
    """Create a Task which loads a layer form ERP remote server and add it to the QGIS canvas

    :param layer_specs: layer information
    :type layer_specs: LayerSpecs instance
    :param bbox: bounding box in ERP's CRS
    :type bbox: QgsRectangle
    :param session_id: session id
    :type session_id: int
    :param visible_only: if only visible in-scale layers have to be downloaded
    :type visible_only: bool
    :return: the dowloader task
    :rtype: QgsTask
    """

    task = __layer_loader(layer_specs, bbox, session_id, visible_only)
    message_log(
        "Download Task queued: catalog id %s - %s - session id: %s, bbox: %s, domain: %s" %
        (layer_specs.catalog_id, layer_specs.model,
         session_id, bbox, layer_specs.domain),
        Qgis.Info
    )
    return task


def catalog_loader(layer_specs_list, bbox=QgsRectangle(), session_id=None, visible_only=True, raise_exceptions=False):
    """Multiple loader task for the catalog (whole or session), the task is created but not started.

    :param layer_specs: layer information
    :type layer_specs: LayerSpecs instance
    :param bbox: bounding box in ERP's CRS
    :type bbox: QgsRectangle
    :param session_id: session id
    :type session_id: int
    :param target_layer: destination layer, default to None to create a new one
    :type target_layer: QgsVectorLayer or None
    :param visible_only: if only visible in-scale layers have to be downloaded
    :type visible_only: bool
    :return: the dowloader task
    :rtype: QgsTask
    """

    message_log("Catalog loader started")

    def _main_task_on_finished(*args):
        message_log("Catalog loader task completed for session: %s" %
                    (session_id if session_id is not None else "no session"))

    # Aqui hauriem de preparar el cache de les ids de les capes
    catalog_ids = []
    for layer_specs in layer_specs_list:
        catalog_ids.append(layer_specs.catalog_id)
    catalog_model = ERPClient.model(QGISCE_CATALOG_MODEL_NAME)
    global CACHED_ELEMENTS_IDS
    CACHED_ELEMENTS_IDS = catalog_model.fetch_res_ids(
        catalog_ids, session_id, bbox.asWktPolygon()
    )
    sub_tasks = []
    for layer_specs in layer_specs_list:
        sub_task = __layer_loader(
            layer_specs,
            bbox,
            session_id,
            visible_only,
            raise_exceptions=raise_exceptions
        )
        sub_tasks.append(sub_task)

    main_task = MainLoaderTask(sub_tasks)

    return main_task


def specs_loader_function(task, crs, bbox, session_id, visible_only):
    layer_specs = Catalog().fetch_specs(crs, bbox, task=task)
    return layer_specs, bbox, session_id, visible_only


def catalog_specs_loader(crs, bbox, session_id, on_finished, visible_only, raise_exceptions=False):
    message_log("Loading catalog information started")
    specs_task = TaskWrapper.fromFunction("Load catalog information from remote ERP server",
                                          specs_loader_function,
                                          crs=crs,
                                          bbox=bbox,
                                          session_id=session_id,
                                          on_finished=on_finished,
                                          visible_only=visible_only,
                                          raise_exceptions=raise_exceptions
                                          )
    Catalog().progressChanged.connect(specs_task.progressChanged)
    return specs_task
