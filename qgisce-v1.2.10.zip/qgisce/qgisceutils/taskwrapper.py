# coding=utf-8
"""QGIS TaskWrapper that raise exceptions instead of swallowing them


.. note:: This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

"""

__author__ = 'elpaso@itopen.it'
__date__ = '2018-09-14'
__copyright__ = 'Copyright 2018, GISCE-TI S.L.'

from qgis.core import QgsTaskWrapper
from qgis._core import QgsTask

class TaskWrapper(QgsTaskWrapper):
    """A subclass of QGIS original QgsTaskWrapper, that raise exceptions
    instead of silently dropping them.

    All QGIS downloader tasks inherit from TaskWrapper

    """

    def __init__(self, description, flags, function, on_finished, raise_exceptions, *args, **kwargs):
        QgsTask.__init__(self, description, flags)
        self.args = args
        self.kwargs = kwargs
        self.raise_exceptions = raise_exceptions
        self.function = function
        self.on_finished = on_finished
        self.returned_values = None
        self.exception = None

    def run(self):
        try:
            self.returned_values = self.function(self, *self.args, **self.kwargs)
        except Exception as ex:
            if self.raise_exceptions:
                raise ex
            # report error
            self.exception = ex
            return False

        return True

    def finished(self, result):
        if not self.on_finished:
            return

        if not result and self.exception is None:
            self.exception = Exception('Task canceled')

        try:
            if self.returned_values:
                self.on_finished(self.exception, self.returned_values)
            else:
                self.on_finished(self.exception)
        except Exception as ex:
            if self.raise_exceptions:
                raise ex
            self.exception = ex



    @staticmethod
    def fromFunction(description, function, *args, on_finished=None, raise_exceptions=False, flags=QgsTask.AllFlags, **kwargs):
        """
        Creates a new QgsTask task from a python function.

        Example:

        def calculate(task):
            # pretend this is some complex maths and stuff we want
            # to run in the background
            return 5*6

        def calculation_finished(exception, value=None):
            if not exception:
                iface.messageBar().pushMessage(
                    'the magic number is {}'.format(value))
            else:
                iface.messageBar().pushMessage(
                    str(exception))

        task = QgsTask.fromFunction('my task', calculate,
                on_finished=calculation_finished)
        QgsApplication.taskManager().addTask(task)

        """

        assert function
        return TaskWrapper(description, flags, function, on_finished, raise_exceptions, *args, **kwargs)
