# coding=utf-8
"""Layer manipulation: load json data into memory layers

TODO: implement a layer registry singleton class to manage layers status and
synchronisation

.. note:: This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

"""

__author__ = 'elpaso@itopen.it'
__date__ = '2018-05-18'
__copyright__ = 'Copyright 2018, GISCE-TI S.L.'

import json

from qgis.utils import iface

from qgis.core import (
    QgsApplication,
    QgsField,
    QgsFields,
    QgsMemoryProviderUtils,
    QgsProject,
    QgsWkbTypes,
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsGeometry,
    QgsEditorWidgetSetup,
    QgsRectangle,
    QgsFieldConstraints,
    QgsEditFormConfig,
    QgsSvgMarkerSymbolLayer,
    QgsProperty,
    Qgis,
    QgsFeatureRequest,
    QgsDefaultValue,
    QgsSnappingUtils,
)

# Import Message logger
from qgiscegui.notifications import message_log

from .project import layer_set_managed, layer_for_catalog_id
from .connections import setup_connections, clear_connections
from .i18n import tr
from .catalog import Catalog

from .literals import *

# List of fields we ALWAYS want to download from ERP
ERP_FIELDS = ['id', 'rotation']

from qgis.PyQt.QtCore import QVariant, QThread, QObject


class LayerCreationException(Exception):
    """Raised when the layer could not be created"""
    pass


class LayerFeatureGeometryException(Exception):
    """Raised when the geometry of the feature is not GEOS valid"""
    pass


class LayerFeatureValidationException(Exception):
    """Raised when the feature is not valid"""
    pass


class LayerFeatureAlreadyAddedException(Exception):
    """Raised when the feature is already in the layer"""
    pass


class JSONLayer(QObject):
    """JSONLayer is a wrapper class around a QgsVectorLayer memory layer instance.

    The QgsVectorLayer instance can be accessed with the property "target_layer"

    The class takes care of layer creation if the layer does not exist.

    The layer is configured with:

    - signal connections
    - QGISCE layer properties
    - styling
    - json parsing to insert features in the layer

    Notice that the layer is not added to the canvas.

    """

    def __init__(self, layer_specs, json_data=[],
                 import_all_fields=False, parent: QObject = None):
        """Create a memory layer from JSON data or import data into an
        existing layer after dropping all existing features.

        :param json_data: JSON string
        :type json_data: list of feature dicts
        :param layer_specs: layer specifications
        :type layer_specs: LayerSpecs
        :param import_all_fields: whether we want to import all fields even
        if not listed in ERP_FIELDS or in "catalog.fields" , defaults to False
        :param import_all_fields: bool, optional



        json_data format: a list of features from escomesa_obj.read(<id>)
        ----------------------------------------------
        [
            {
                "last_geom": "POINT (980911.759955 4663535.18978)",
                "ultima_x": false,
                "blockname": false,
                "geom": "POINT (980911.759955 4663535.18978)",
                "id": 19358,
                "cupsnotassigned": [
                    59838
                    60300,
                    60301
                ],
                "y": 4663535.18978,
                "x": 980911.759955,
                "polisses_actives": [],
                "active": true,
                "ncupsnotassigned": 1305,
                "id_municipi": false,
                "nescomeses": 21363,
                "cups": [],
                "ultima_y": false,
                "potencia_polisses": 0,
                "name": "19407",
                "ncups": 0
            }
        ]

        field_mapping format: from escomesa_obj.fields()
        -------------------------------------------------
        {
            "last_geom": {
                "type": "text",
                "string": "geometry"
            },
            "ultima_x": {
                "type": "float",
                "string": "Ultima X"
            },
            "blockname": {
                "relation": "giscedata.cups.blockname",
                "size": 64,
                "string": "Tipus",
                "domain": [],
                "context": "",
                "type": "many2one"
            },
            "geom": {
                "type": "text",
                "string": "geometry"
            },
            "active": {
                "type": "boolean",
                "string": "Activa",
                "select": true
            },
            "cupsnotassigned": {
                "domain": [],
                "string": "CUPS Sense Assignar",
                "relation": "giscedata.cups.ps",
                "digits": [
                    16,
                    2
                ],
                "context": "",
                "type": "one2many"
            }
        }

        """

        super().__init__(parent)

        self.layer_specs = layer_specs
        self.layer_name = layer_specs.layer_name
        self.model_name = layer_specs.model_name
        self.model = layer_specs.model
        self.domain = layer_specs.domain
        self.geometry_type = layer_specs.geometry_type
        self.field_mapping = layer_specs.field_mapping
        self.import_all_fields = import_all_fields
        self.fields = self.make_fields(
            layer_specs, import_all_fields
        )
        self.target_layer = None
        self.crs = layer_specs.crs
        self.bbox = layer_specs.bbox
        assert isinstance(self.bbox, QgsRectangle)
        # Create the layer
        self.__create()
        # Load data
        self.load_features(json_data)
        # Setup form fields
        self.__form_setup()

    @classmethod
    def make_fields(self, layer_specs, import_all_fields=False):
        """Converts the JSON fields description into QGIS fields

        Note: only fields listed in ERP_FIELDS and layers_specs.fields are actually
        imported, unless import_all_fields is passed

        :param field_mapping: A list of dictionaries describing the field types
        :type field_mapping: list of dicts
        :param import_all_fields: wether we want to import all fields even if
        not listed in ERP_FIELDS or layers_specs.fields, defaults to False
        :param import_all_fields: bool, optional
        :return: QgsFields object
        :rtype: QgsFields
        """

        fields = QgsFields()
        # Always add ID which is not listed in fields call result
        fields.append(QgsField('id', QVariant.Int))
        # Accepted fields. We prevent aliasing with copy()
        accepted_fields = ERP_FIELDS.copy()
        # Dot-notation fields
        dot_notation_fields = []
        for field in layer_specs.fields:
            if '.' in field:
                dot_notation_fields += [field]
            else:
                accepted_fields += [field]
        for field_name, field_definition in layer_specs.field_mapping.items():
            for dn_field in dot_notation_fields:
                if field_name in dn_field:
                    field_type = QVariant.String
                    fields.append(QgsField(dn_field, field_type))
                    continue
            # New logic white list
            if field_name not in accepted_fields and not import_all_fields:
                continue

            supported = True
            field_type = field_definition["type"]
            accepted_string_types = (
                "char", "text", "selection", "many2one", "datetime", "binary"
            )
            if field_type in accepted_string_types:
                field_type = QVariant.String
            elif field_type == "boolean":
                field_type = QVariant.Bool
            elif field_type == "float":
                field_type = QVariant.Double
            elif field_type == "integer":
                field_type = QVariant.Int
            else:
                supported = False
            if supported:
                fields.append(QgsField(field_name, field_type))
            else:
                message_log(
                    "Unsupported field type %s %s" % (field_type, field_name)
                )
        return fields

    def __attributes(self, feature_data):
        attributes = []
        for f in self.fields:
            # We check for a list instance to see if the field is the result
            # of reading a many2one field
            # At the moment the many2one are the only valid type of fields
            # accepted that returns a list.
            if isinstance(feature_data[f.name()], list):
                # By accessing the first element of the list we use the
                # id of the referenced element
                attributes.append(feature_data[f.name()][0])
            else:
                attributes.append(feature_data[f.name()])

        return attributes

    def __create(self):
        """Create and configure the JSON layer

        :raises LayerCreationException: Raised when the layer could not be
        created
        """
        layer = layer_for_catalog_id(self.layer_specs.catalog_id)
        layer_is_new = False

        if layer is not None:
            # Remove all features
            layer.dataProvider().truncate()
            # Clear any locator index
            iface.mapCanvas().snappingUtils().locatorForLayer(layer).destroyIndex()

        if layer is None:
            message_log("Creating layer %s" % self.layer_name)
            layer = QgsMemoryProviderUtils.createMemoryLayer(
                self.layer_name, self.fields, self.geometry_type, self.crs
            )
            layer_is_new = True

        self.target_layer = layer

        if not self.target_layer.isValid():
            raise LayerCreationException(
                "Could not create memory layer: layer is not valid"
            )

        # Configure the layer
        if layer_is_new:

            # Style
            if self.layer_specs.style_name:
                style_path = Catalog.resolve_path(self.layer_specs.style_name)
                if not style_path:
                    message_log(
                        tr("Invalid style for layer self.%s: file not found: %s") %
                        (self.layer_specs.layer_name, self.layer_specs.style_name),
                        Qgis.Warning
                    )
                else:
                    self.target_layer.loadNamedStyle(style_path)
            # Symbol
            if self.layer_specs.symbol_name:
                symbol_path = Catalog.resolve_path(
                    self.layer_specs.symbol_name)
                if not symbol_path:
                    message_log(
                        tr("Invalid symbol for layer %s: file not found: %s") %
                        (self.layer_specs.layer_name,
                         self.layer_specs.symbol_name),
                        Qgis.Warning
                    )
                else:
                    symbol = self.target_layer.renderer().symbol()
                    symbol_layer = symbol.symbolLayer(0)
                    if not isinstance(symbol_layer, QgsSvgMarkerSymbolLayer):
                        symbol.deleteSymbolLayer(0)
                        symbol.insertSymbolLayer(
                            0, QgsSvgMarkerSymbolLayer(symbol_path)
                        )
                        symbol_layer = symbol.symbolLayer(0)
                        if 'rotation' in self.target_layer.fields().names():
                            symbol.setDataDefinedAngle(
                                QgsProperty.fromField('rotation')
                            )
                    if symbol_layer:
                        symbol_layer.setPath(symbol_path)
                    else:
                        message_log(
                            tr("Error adding SVG symbol for layer %s: symbol layer not found") %
                            self.layer_specs.layer_name,
                            Qgis.Warning
                        )

            # Override named style suppress configuration (because loadNamedStyle might have misconfigured it)
            edit_config = self.target_layer.editFormConfig()
            edit_config.setSuppress(QgsEditFormConfig.SuppressOn)
            self.target_layer.setEditFormConfig(edit_config)

            # Set or re-set custom layer properties
            layer_set_managed(self.target_layer, self.layer_specs)

            # Connect signals
            setup_connections(self.target_layer, self.layer_specs)

    def load_features(self, json_data, task=None):
        """Add features to the layer: must be called as a slot in gui thread

        :param json_data: JSON string
        :type json_data: list of feature dicts
        :raises LayerFeatureGeometryException: Raised when the geometry of
        the feature is not GEOS valid
        :raises LayerFeatureValidationException: Raised when the feature
        is not valid
        """

        assert QThread.currentThread() == QgsApplication.instance().thread()

        if task is not None and task.isCanceled():
            return

        features = []

        # This is probably not necessary: raise
        existing_fids = [f['id'] for f in self.target_layer
                         .getFeatures(QgsFeatureRequest()
                                      .setSubsetOfAttributes(['id'],
                                                             self.target_layer.fields())
                                      .setFlags(QgsFeatureRequest.NoGeometry))]
        for feature_data in json_data:
            if task is not None and task.isCanceled():
                return
            f = QgsFeature(self.fields)
            f.setAttributes(self.__attributes(feature_data))
            # skip if feature is already there
            if f['id'] in existing_fids:
                # No need to raise here, progressive download might trigger multiple threaded
                # downloads
                #raise LayerFeatureAlreadyAddedException("Feature is already in the layer")
                pass
            # Handle geometry - can be WKT string, WKB bytes, False, None, or empty
            geom_data = feature_data.get('geom')
            if geom_data is None or geom_data is False or geom_data == '':
                # Feature without geometry (e.g. DSP fusibles) — QGIS allows this
                pass
            elif isinstance(geom_data, (bytes, bytearray)):
                geom = QgsGeometry()
                geom.fromWkb(geom_data)
                if not geom.isGeosValid():
                    raise LayerFeatureGeometryException(
                        "Error loading features in layer {}. Geometry is not "
                        "valid for feature with data: {}".format(
                            self.target_layer.name(), feature_data
                        )
                    )
                f.setGeometry(geom)
            elif isinstance(geom_data, str):
                try:
                    geom = QgsGeometry.fromWkt(geom_data)
                except TypeError:
                    raise LayerFeatureGeometryException(
                        "Error loading features in layer {}. Geometry is not valid"
                        " for feature with data: {}".format(
                            self.target_layer.name(), feature_data
                        )
                    )
                if not geom.isGeosValid():
                    message_log(
                        "Invalid geometry in layer '{}', feature id={}: {}".format(
                            self.target_layer.name(),
                            feature_data.get('id'),
                            repr(geom_data)[:200],
                        ),
                        level=Qgis.Warning,
                    )
                    raise LayerFeatureGeometryException(
                        "Error loading features in layer {}. Geometry is not "
                        "valid for feature with data: {}".format(
                            self.target_layer.name(), feature_data
                        )
                    )
                f.setGeometry(geom)
            else:
                message_log(
                    "Unsupported geometry type in layer '{}', feature id={}: {} ({})".format(
                        self.target_layer.name(),
                        feature_data.get('id'),
                        type(geom_data).__name__,
                        repr(geom_data)[:200],
                    ),
                    level=Qgis.Warning,
                )
                raise LayerFeatureGeometryException(
                    "Error loading features in layer {}. Unsupported geometry type "
                    "for feature with data: {}".format(
                        self.target_layer.name(), feature_data
                    )
                )
            if not f.isValid():
                raise LayerFeatureValidationException(
                    "Feature is not valid: %s" % feature_data
                )
            features.append(f)

        if task is not None and task.isCanceled():
            return
        try:
            self.target_layer.dataProvider().addFeatures(features)
        except RuntimeError as e:
            message_log("Runtime error adding features from task: %s" %
                        task, Qgis.Warning)

    def __form_setup(self):
        """Configure the form and the widgets

        - add alias
        - add NOT NULL constraint
        - set suppress form opening in new features

        """
        for f in self.target_layer.fields():
            if f.name() in self.field_mapping:
                if 'string' in self.field_mapping[f.name()]:
                    target_fields = self.target_layer.fields()
                    field_idx = target_fields.lookupField(f.name())
                    self.target_layer.setFieldAlias(
                        field_idx,
                        self.field_mapping[f.name()]['string']
                    )

                # If we wanted to do more widget config, this would be the
                # (untested) code:
                # widget_setup = self.target_layer.editorWidgetSetup(
                #    field_idx)
                # widget_config = widget_setup.config()
                # new_widget_setup = QgsEditorWidgetSetup(
                # widget_setup.type(), widget_config)
                # self.target_layer.setEditorWidgetSetup(
                #    field_idx, new_widget_setup)

                # Set required constraint
                if self.field_mapping[f.name()].get('required', False):
                    self.target_layer.setFieldConstraint(
                        field_idx, QgsFieldConstraints.ConstraintNotNull
                    )
