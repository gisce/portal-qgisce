##############################################################################
#
# Copyright (c) 2004-2006 TINY SPRL. (http://tiny.be) All Rights Reserved.
# Copyright (c) 2007-2008 Albert Cervera i Areny <albert@nan-tic.com>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

from Koo.Common import Common
from PyQt5.QtWidgets import *
from Koo.Common import Shortcuts

from Koo.Common.Calendar import *
from Koo.Search.AbstractSearchWidget import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from Koo.Common.Ui import *

(DateSearchWidgetUi, DateSearchWidgetBase) = loadUiType(
    Common.uiPath('search_date.ui'))


class DateSearchWidget(AbstractSearchWidget, DateSearchWidgetUi):
    def __init__(self, name, parent, attrs={}):
        AbstractSearchWidget.__init__(self, name, parent, attrs)
        DateSearchWidgetUi.__init__(self)
        self.setupUi(self)

        # Catch keyDownPressed
        self.uiStart.installEventFilter(self)
        self.uiEnd.installEventFilter(self)

        # Add shortcuts
        self.scStartSearch = QShortcut(self.uiStart)
        self.scStartSearch.setKey(Shortcuts.SearchInField)
        self.scStartSearch.setContext(Qt.WidgetShortcut)
        self.scStartSearch.activated.connect(self.showStartCalendar)

        self.scEndSearch = QShortcut(self.uiEnd)
        self.scEndSearch.setKey(Shortcuts.SearchInField)
        self.scEndSearch.setContext(Qt.WidgetShortcut)
        self.scEndSearch.activated.connect(self.showEndCalendar)

        self.widget = self
        self.focusWidget = self.uiStart
        self.pushStart.clicked.connect(self.showStartCalendar)
        self.pushEnd.clicked.connect(self.showEndCalendar)

    def showStartCalendar(self):
        PopupCalendarWidget(self.uiStart)

    def showEndCalendar(self):
        PopupCalendarWidget(self.uiEnd)

    def value(self):
        res = []
        date = textToDate(self.uiStart.text())
        val = dateToStorage(date)
        if val:
            self.uiStart.setText(dateToText(date))
            res.append((self.name, '>=', val))
        else:
            self.uiStart.clear()
        date = textToDate(self.uiEnd.text())
        val = dateToStorage(date)
        if val:
            self.uiEnd.setText(dateToText(date))
            res.append((self.name, '<=', val))
        else:
            self.uiEnd.clear()
        return res

    def clear(self):
        self.uiStart.clear()
        self.uiEnd.clear()

    def setValue(self, value):
        if value:
            self.uiStart.setText(str(value))
            self.uiEnd.setText(str(value))
        else:
            self.uiStart.clear()
            self.uiEnd.clear()
