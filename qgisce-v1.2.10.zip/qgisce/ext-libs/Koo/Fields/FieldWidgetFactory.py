##############################################################################
#
# Copyright (c) 2008 Albert Cervera i Areny <albert@nan-tic.com>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

from Koo.Common import Plugins
import logging
import os

logger = logging.getLogger(__name__)

# @brief The FieldWidgetFactory class specializes in creating the appropiate
# widget for a given type.


class FieldWidgetFactory:
    widgets = {}

    # @brief Scans for all available widgets.
    @staticmethod
    def scan():
        # Scan only once
        if FieldWidgetFactory.widgets:
            return
        # Search for all available views
        Plugins.scan('Koo.Fields', os.path.abspath(os.path.dirname(__file__)))

    # @brief Creates a new widget given type, parent and attributes.
    # @param fallback_type: field type to use if widgetType is not registered.
    @staticmethod
    def create(widgetType, parent, view, attributes, fallback_type=None):
        FieldWidgetFactory.scan()

        # We do not support relational fields treated as selection ones
        if widgetType == 'selection' and 'relation' in attributes:
            widgetType = 'many2one'

        if widgetType not in FieldWidgetFactory.widgets:
            if fallback_type and fallback_type in FieldWidgetFactory.widgets:
                logger.warning(
                    "Widget '%s' not available, falling back to field type '%s'",
                    widgetType, fallback_type
                )
                # Fix the type in attributes so the fallback widget initialises correctly
                attributes['type'] = fallback_type
                # indicator-like widgets are display-only — force readonly
                attributes['readonly'] = True
                widgetType = fallback_type
            else:
                logger.warning("Widget '%s' not available", widgetType)
                return None

        widgetClass = FieldWidgetFactory.widgets[widgetType]
        return widgetClass(parent, view, attributes)

    # @brief Registers a new widget, given it's name (or type) and reference
    # to the class.
    @staticmethod
    def register(name, widget):
        FieldWidgetFactory.widgets[name] = widget
