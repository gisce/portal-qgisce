<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>@default</name>
    <message>
        <location filename="../qgisceutils/session.py" line="194"/>
        <source>{} deleted</source>
        <translation>{} deleted</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="196"/>
        <source>{} geometry changed</source>
        <translation>{} geometry changed</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="200"/>
        <source>{} multiple attribute changed</source>
        <translation>{} multiple attribute changed</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="198"/>
        <source>{} single attribute changed</source>
        <translation>{} single attribute changed</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="683"/>
        <source>&amp;QGISCE</source>
        <translation>&amp;QGISCE</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1543"/>
        <source>&lt;b&gt;%s&lt;/b&gt; %s successfully</source>
        <translation>&lt;b&gt;%s&lt;/b&gt; %s successfully</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="435"/>
        <source>A line must have at least two vertices in layer: %s</source>
        <translation>A line must have at least two vertices in layer: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="892"/>
        <source>A session with this name (%s) already exists, please choose a different name.</source>
        <translation>A session with this name (%s) already exists, please choose a different name.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="510"/>
        <source>About</source>
        <translation>About</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="150"/>
        <source>Add</source>
        <translation>Add</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="430"/>
        <source>Adding layer %s</source>
        <translation>Adding layer %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1342"/>
        <source>All layers have been downloaded correctly.</source>
        <translation>All layers have been downloaded correctly.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp.py" line="114"/>
        <source>An error occourred while connecting to ERP backend, please check your connection settings and see message logs for further details.</source>
        <translation>An error occourred while connecting to ERP backend, please check your connection settings and see message logs for further details.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp.py" line="119"/>
        <source>An error occourred while connecting to ERP backend: %s</source>
        <translation>An error occourred while connecting to ERP backend: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1209"/>
        <source>An error occourred while loading data from the server during catalog loading, see the message logs for details.</source>
        <translation>An error occourred while loading data from the server during catalog loading, see the message logs for details.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1871"/>
        <source>An error occourred while loading data from the server during session loading, see the message logs for details.</source>
        <translation>An error occourred while loading data from the server during session loading, see the message logs for details.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1211"/>
        <source>An error occourred while loading data from the server: %s</source>
        <translation>An error occourred while loading data from the server: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1873"/>
        <source>An error occourred while loading session data from the server: %s</source>
        <translation>An error occourred while loading session data from the server: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="156"/>
        <source>Attribute change</source>
        <translation>Attribute change</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp.py" line="109"/>
        <source>Bad credentials!</source>
        <translation>Bad credentials!</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="2036"/>
        <source>Catalog loading error</source>
        <translation>Catalog loading error</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp.py" line="114"/>
        <source>Connection error</source>
        <translation>Connection error</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1244"/>
        <source>Connection status: ERROR! %s</source>
        <translation>Connection status: ERROR! %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1214"/>
        <source>Connection to ERP failed, error loading QGISCE catalog.</source>
        <translation>Connection to ERP failed, error loading QGISCE catalog.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1879"/>
        <source>Connection to ERP failed, error loading QGISCE session.</source>
        <translation>Connection to ERP failed, error loading QGISCE session.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1701"/>
        <source>Connection to ERP failed, error loading QGISCE sessions.</source>
        <translation>Connection to ERP failed, error loading QGISCE sessions.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="672"/>
        <source>Connection to ERP failed, error logging into QGISCE.</source>
        <translation>Connection to ERP failed, error logging into QGISCE.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1134"/>
        <source>Could not parse the CRS descriptor: %s</source>
        <translation>Could not parse the CRS descriptor: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="152"/>
        <source>Delete</source>
        <translation>Delete</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="211"/>
        <source>Edge id %s created</source>
        <translation>Edge id %s created</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="315"/>
        <source>Edge id %s found</source>
        <translation>Edge id %s found</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1128"/>
        <source>Empty BBOX from the CRS descriptor: %s</source>
        <translation>Empty BBOX from the CRS descriptor: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="211"/>
        <source>ERPSync geometry_changes on layer %s fid %s: %s</source>
        <translation>ERPSync geometry_changes on layer %s fid %s: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="402"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1546"/>
        <source>Error %s &lt;b&gt;%s&lt;/b&gt; %s: %s</source>
        <translation>Error %s &lt;b&gt;%s&lt;/b&gt; %s: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/json_layer.py" line="362"/>
        <source>Error adding SVG symbol for layer %s: symbol layer not found</source>
        <translation>Error adding SVG symbol for layer %s: symbol layer not found</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1010"/>
        <source>Error converting element ID to integer: %s</source>
        <translation>Error converting element ID to integer: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1790"/>
        <source>Error creating QGISCE session: %s.</source>
        <translation>Error creating QGISCE session: %s.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="386"/>
        <source>Error downloading layer: %s&lt;br/&gt;%s</source>
        <translation>Error downloading layer: %s&lt;br/&gt;%s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="392"/>
        <source>Error downloading layer: no returned values!</source>
        <translation>Error downloading layer: no returned values!</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="402"/>
        <source>Error downloading layer: returned values are incomplete! %s</source>
        <translation>Error downloading layer: returned values are incomplete! %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="2036"/>
        <source>Error loading QGISCE catalog: %s</source>
        <translation>Error loading QGISCE catalog: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1922"/>
        <source>Error loading QGISCE session: %s</source>
        <translation>Error loading QGISCE session: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1698"/>
        <source>Error loading sessions: %s</source>
        <translation>Error loading sessions: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1131"/>
        <source>Error parsing BBOX from the CRS descriptor: %s</source>
        <translation>Error parsing BBOX from the CRS descriptor: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1005"/>
        <source>Error parsing model name: %s</source>
        <translation>Error parsing model name: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="86"/>
        <source>Error retrieving %s layer: %s</source>
        <translation>Error retrieving %s layer: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="421"/>
        <source>Error retrieving layer: %s</source>
        <translation>Error retrieving layer: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="124"/>
        <source>Error retrieving snapping layer catalog id %s required by layer %s</source>
        <translation>Error retrieving snapping layer catalog id %s required by layer %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1827"/>
        <source>Error saving QGISCE session: %s</source>
        <translation>Error saving QGISCE session: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="745"/>
        <source>featureIdentified event feature id: %s, attrs: %s</source>
        <translation>featureIdentified event feature id: %s, attrs: %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="84"/>
        <source>Fix manually</source>
        <translation>Fix manually</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="154"/>
        <source>Geometry change</source>
        <translation>Geometry change</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="517"/>
        <source>Identify</source>
        <translation>Identify</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="70"/>
        <source>Install</source>
        <translation>Install</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1543"/>
        <source>installed</source>
        <translation>installed</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1546"/>
        <source>installing</source>
        <translation>installing</translation>
    </message>
    <message>
        <location filename="../qgisceutils/json_layer.py" line="328"/>
        <source>Invalid style for layer self.%s: file not found: %s</source>
        <translation>Invalid style for layer self.%s: file not found: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/json_layer.py" line="340"/>
        <source>Invalid symbol for layer %s: file not found: %s</source>
        <translation>Invalid symbol for layer %s: file not found: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/catalog.py" line="182"/>
        <source>Layer information for %s (catalog id: %s) successfully fetched from catalog</source>
        <translation>Layer information for %s (catalog id: %s) successfully fetched from catalog</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="389"/>
        <source>Layer loader has been canceled by the user.</source>
        <translation>Layer loader has been canceled by the user.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1342"/>
        <source>Loading completed</source>
        <translation>Loading completed</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1644"/>
        <source>Loading layers information ...</source>
        <translation>Loading layers information ...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1012"/>
        <source>Model name error</source>
        <translation>Model name error</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1012"/>
        <source>Model name is not valid! %s</source>
        <translation>Model name is not valid! %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="192"/>
        <source>New {}</source>
        <translation>New {}</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1502"/>
        <source>New print templates installed</source>
        <translation>New print templates installed</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1306"/>
        <source>No active session</source>
        <translation>No active session</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="393"/>
        <source>Node id %s created</source>
        <translation>Node id %s created</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="366"/>
        <source>Node id %s found</source>
        <translation>Node id %s found</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="445"/>
        <source>Node id set to %s for feature id %s</source>
        <translation>Node id set to %s for feature id %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1543"/>
        <source>Plugin dependency</source>
        <translation>Plugin dependency</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1546"/>
        <source>Plugin dependency error</source>
        <translation>Plugin dependency error</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.py" line="83"/>
        <source>Project setup completed</source>
        <translation>Project setup completed</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1995"/>
        <source>Project template update</source>
        <translation>Project template update</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1304"/>
        <source>QGISCE Session: %s</source>
        <translation>QGISCE Session: %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/manual_download_dialog.py" line="29"/>
        <source>Select extent</source>
        <translation>Select extent</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1876"/>
        <source>Selected session &lt;b&gt;%s&lt;/b&gt; is already active</source>
        <translation>Selected session &lt;b&gt;%s&lt;/b&gt; is already active</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1461"/>
        <source>Sentry enabled!</source>
        <translation>Sentry enabled!</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1876"/>
        <source>Session</source>
        <translation>Session</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1732"/>
        <source>Session &lt;b&gt;%s&lt;/b&gt; could not be deleted.</source>
        <translation>Session &lt;b&gt;%s&lt;/b&gt; could not be deleted.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1719"/>
        <source>Session &lt;b&gt;%s&lt;/b&gt; has been successfully deleted.</source>
        <translation>Session &lt;b&gt;%s&lt;/b&gt; has been successfully deleted.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="640"/>
        <source>Session active error</source>
        <translation>Session active error</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1790"/>
        <source>Session creation error</source>
        <translation>Session creation error</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1719"/>
        <source>Session delete</source>
        <translation>Session delete</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1732"/>
        <source>Session delete error</source>
        <translation>Session delete error</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1922"/>
        <source>Session loading error</source>
        <translation>Session loading error</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="495"/>
        <source>Session manager</source>
        <translation>Session manager</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1758"/>
        <source>Session merge error</source>
        <translation>Session merge error</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1749"/>
        <source>Session merged</source>
        <translation>Session merged</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1827"/>
        <source>Session save error</source>
        <translation>Session save error</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="503"/>
        <source>Settings</source>
        <translation>Settings</translation>
    </message>
    <message>
        <location filename="../qgisceutils/connections.py" line="185"/>
        <source>Synchronization signals connected to layer %s</source>
        <translation>Synchronization signals connected to layer %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="771"/>
        <source>The active layer (%s) is not managed by the QGISCE plugin</source>
        <translation>The active layer (%s) is not managed by the QGISCE plugin</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1470"/>
        <source>The new project will be loaded automatically at the next QGIS start. Do you want to load the default project now?</source>
        <translation>The new project will be loaded automatically at the next QGIS start. Do you want to load the default project now?</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="144"/>
        <source>Topology snapping disabled for layer %s</source>
        <translation>Topology snapping disabled for layer %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="77"/>
        <source>Upgrade</source>
        <translation>Upgrade</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1543"/>
        <source>upgraded</source>
        <translation>upgraded</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1546"/>
        <source>upgrading</source>
        <translation>upgrading</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="640"/>
        <source>You need an active session in order to create a report for it!</source>
        <translation>You need an active session in order to create a report for it!</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="438"/>
        <source>Topology</source>
        <translation>Topology</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="270"/>
        <source>Download full catalog</source>
        <translation>Download full catalog</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="485"/>
        <source>Search indexed elements</source>
        <translation>Search indexed elements</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="542"/>
        <source>Reload current catalog</source>
        <translation>Reload current catalog</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="578"/>
        <source>Validate network</source>
        <translation>Validate network</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="810"/>
        <source>Error opening the ERP form</source>
        <translation>Error opening the ERP form</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="813"/>
        <source>Impossible to open the form while identifing the element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>Impossible to open the form while identifing the element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="818"/>
        <source>Impossible to open the form while identifing the element {} on layer {}</source>
        <translation>Impossible to open the form while identifing the element {} on layer {}</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="825"/>
        <source>Impossible to open the form while creating a new element on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>Impossible to open the form while creating a new element on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="830"/>
        <source>Impossible to open the form while creating a new element on layer {}</source>
        <translation>Impossible to open the form while creating a new element on layer {}</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="940"/>
        <source>%s: %s</source>
        <translation>%s: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1050"/>
        <source>Validator not implemented</source>
        <translation>Validator not implemented</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1050"/>
        <source>The validator only works for the electrical network.</source>
        <translation>The validator only works for the electrical network.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1058"/>
        <source>Impossible to validate the network</source>
        <translation>Impossible to validate the network</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1058"/>
        <source>There are some changes that must be saved before validating the network on the following layers: {}</source>
        <translation>There are some changes that must be saved before validating the network on the following layers: {}</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1097"/>
        <source>Validator error</source>
        <translation>Validator error</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1097"/>
        <source>The validator raised an exception %s</source>
        <translation>The validator raised an exception %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1570"/>
        <source>Layer loading error</source>
        <translation>Layer loading error</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1570"/>
        <source>Error loading layers: %s</source>
        <translation>Error loading layers: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1592"/>
        <source>Loading visible layers only for session %s ...</source>
        <translation>Loading visible layers only for session %s ...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1592"/>
        <source>Loading full catalog for session %s ...</source>
        <translation>Loading full catalog for session %s ...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1596"/>
        <source>Loading visible layers only ...</source>
        <translation>Loading visible layers only ...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1596"/>
        <source>Loading full catalog ...</source>
        <translation>Loading full catalog ...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1604"/>
        <source>Error downloading catalog elements from the ERP</source>
        <translation>Error downloading catalog elements from the ERP</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1605"/>
        <source>Impossible to download the catalog elements from the ERP. Check the logs for more information.</source>
        <translation>Impossible to download the catalog elements from the ERP. Check the logs for more information.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1609"/>
        <source>Error downloading catalog elements from the ERP:
</source>
        <translation>Error downloading catalog elements from the ERP:
</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1750"/>
        <source>Session &lt;b&gt;{}&lt;/b&gt; has been successfully merged.</source>
        <translation>Session &lt;b&gt;{}&lt;/b&gt; has been successfully merged.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1759"/>
        <source>Session &lt;b&gt;{}&lt;/b&gt; could not be merged. Check the logs for more information.</source>
        <translation>Session &lt;b&gt;{}&lt;/b&gt; could not be merged. Check the logs for more information.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1763"/>
        <source>Session {} could not be merged</source>
        <translation>Session {} could not be merged</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1846"/>
        <source>Activating session &lt;b&gt;{}: {}&lt;/b&gt;</source>
        <translation>Activating session &lt;b&gt;{}: {}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1964"/>
        <source>Downloading visible layers from current canvas extent...</source>
        <translation>Downloading visible layers from current canvas extent...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1976"/>
        <source>Downloading full catalog from current canvas extent...</source>
        <translation>Downloading full catalog from current canvas extent...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1995"/>
        <source>An update for the QGIS project is available.&lt;br&gt;The new project template will be installed as the default project.&lt;br&gt;The new project will use a different name and you will be able to reload your current (old) project in case you wanted to copy over some of your changes.&lt;br&gt;PROJECT PATH: (&lt;pre&gt;%s&lt;/pre&gt;)</source>
        <translation>An update for the QGIS project is available.&lt;br&gt;The new project template will be installed as the default project.&lt;br&gt;The new project will use a different name and you will be able to reload your current (old) project in case you wanted to copy over some of your changes.&lt;br&gt;PROJECT PATH: (&lt;pre&gt;%s&lt;/pre&gt;)</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.py" line="83"/>
        <source>The new project will be loaded automatically at the next QGIS start.&lt;br&gt;Do you want to load the default project now?</source>
        <translation>The new project will be loaded automatically at the next QGIS start.&lt;br&gt;Do you want to load the default project now?</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="2106"/>
        <source>1 item found for layer &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>1 item found for layer &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="2110"/>
        <source>{} items found for layer &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>{} items found for layer &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="2122"/>
        <source>Search result</source>
        <translation>Search result</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="2122"/>
        <source>No items found for layer &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>No items found for layer &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="141"/>
        <source>Topology snapping enabled for layer %s</source>
        <translation>Topology snapping enabled for layer %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="440"/>
        <source>Edge id is %s for feature id %s</source>
        <translation>Edge id is %s for feature id %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="130"/>
        <source>Dirty</source>
        <translation>Dirty</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="130"/>
        <source>Clean</source>
        <translation>Clean</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="287"/>
        <source>Load layers from remote ERP server</source>
        <translation>Load layers from remote ERP server</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="325"/>
        <source>Waiting for main loader to stop subtasks ...</source>
        <translation>Waiting for main loader to stop subtasks ...</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="440"/>
        <source>AcotaciÃ³</source>
        <translation>Acotació</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="238"/>
        <source>Geometry change error</source>
        <translation>Geometry change error</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="239"/>
        <source>Impossible to change geometry for element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>Impossible to change geometry for element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="244"/>
        <source>Impossible to change geometry for element {} on layer {}</source>
        <translation>Impossible to change geometry for element {} on layer {}</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="309"/>
        <source>ERPSync value changed for layer %s on erp_id %s: %s</source>
        <translation>ERPSync value changed for layer %s on erp_id %s: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="311"/>
        <source>Value change error</source>
        <translation>Value change error</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="312"/>
        <source>Impossible to change values for element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>Impossible to change values for element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="317"/>
        <source>Impossible to change values for element {} on layer {}</source>
        <translation>Impossible to change values for element {} on layer {}</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="354"/>
        <source>ERPSync DEFERRED feature_deleted %s erp_id is None, SKIPPING: fid %s</source>
        <translation>ERPSync DEFERRED feature_deleted %s erp_id is None, SKIPPING: fid %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="367"/>
        <source>ERPSync feature_deleted on layer %s fid: %s erp_id %s</source>
        <translation>ERPSync feature_deleted on layer %s fid: %s erp_id %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="373"/>
        <source>Delete element error</source>
        <translation>Delete element error</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="374"/>
        <source>Impossible to delete element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>Impossible to delete element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="379"/>
        <source>Impossible to delete element {} on layer {}</source>
        <translation>Impossible to delete element {} on layer {}</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="630"/>
        <source>ERPSync feature_added %s: erp_id: %s - %s</source>
        <translation>ERPSync feature_added %s: erp_id: %s - %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="637"/>
        <source>Error adding element</source>
        <translation>Error adding element</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="638"/>
        <source>Impossible to add element on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>Impossible to add element on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="643"/>
        <source>Impossible to add element on layer {}</source>
        <translation>Impossible to add element on layer {}</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="701"/>
        <source>Error synchronizing the element</source>
        <translation>Error synchronizing the element</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="702"/>
        <source>Impossible to synchronize the element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>Impossible to synchronize the element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="707"/>
        <source>Impossible to synchronize element {} on layer {}</source>
        <translation>Impossible to synchronize element {} on layer {}</translation>
    </message>
    <message>
        <location filename="../qgiscegui/utils.py" line="104"/>
        <source>Could not zoom to feature with erp_id %s on layer %s</source>
        <translation>Could not zoom to feature with erp_id %s on layer %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/validation_results_widget.py" line="108"/>
        <source>Feature with id {} was not found on layer {}!</source>
        <translation>Feature with id {} was not found on layer {}!</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="214"/>
        <source>Error creating the element to the ERP</source>
        <translation>Error creating the element to the ERP</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="218"/>
        <source>Impossible to create a new element on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>Impossible to create a new element on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="223"/>
        <source>Impossible to create a new element on layer {}</source>
        <translation>Impossible to create a new element on layer {}</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="227"/>
        <source>Error modifying the element to the ERP</source>
        <translation>Error modifying the element to the ERP</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="228"/>
        <source>Impossible to modify the element on layer &lt;b&gt;{}&lt;/b&gt;. Changes had no effect. Check the logs for more information.</source>
        <translation>Impossible to modify the element on layer &lt;b&gt;{}&lt;/b&gt;. Changes had no effect. Check the logs for more information.</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="233"/>
        <source>Impossible to modify the element on layer &lt;b&gt;{}&lt;/b&gt;.</source>
        <translation>Impossible to modify the element on layer &lt;b&gt;{}&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="182"/>
        <source>Validation errors</source>
        <translation>Validation errors</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="182"/>
        <source>There were errors in the network validation, please check the validation results widget for details</source>
        <translation>There were errors in the network validation, please check the validation results widget for details</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="189"/>
        <source>Validation warning</source>
        <translation>Validation warning</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="196"/>
        <source>The network validation was successfull, please check the validation results widget for details</source>
        <translation>The network validation was successfull, please check the validation results widget for details</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="196"/>
        <source>Validation ok</source>
        <translation>Validation ok</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/about_dialog.ui" line="27"/>
        <source>1.1.1</source>
        <translation>1.1.1</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.ui" line="51"/>
        <source>Available sessions</source>
        <translation>Available sessions</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/about_dialog.ui" line="34"/>
        <source>Changelog</source>
        <translation>Changelog</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/about_dialog.ui" line="78"/>
        <source>Do not show me again</source>
        <translation>Do not show me again</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/about_dialog.ui" line="51"/>
        <source>QGISCE Plugin</source>
        <translation>QGISCE Plugin</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.ui" line="22"/>
        <source>Session name</source>
        <translation>Session name</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/about_dialog.ui" line="20"/>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/setup_dialog.ui" line="20"/>
        <source>Welcome to QGISCE plugin, please enter the connection configuration to the ERP backend in the form below and click &quot;Connect&quot; to check your connection.</source>
        <translation>Welcome to QGISCE plugin, please enter the connection configuration to the ERP backend in the form below and click &quot;Connect&quot; to check your connection.</translation>
    </message>
</context>
<context>
    <name>DockWidget</name>
    <message>
        <location filename="../qgiscegui/dialogs/validation_results_widget.ui" line="14"/>
        <source>DockWidget</source>
        <translation>DockWidget</translation>
    </message>
</context>
<context>
    <name>Form</name>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="145"/>
        <source>Connect</source>
        <translation>Connect</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="125"/>
        <source>Database</source>
        <translation>Database</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="138"/>
        <source>Database name</source>
        <translation>Database name</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="152"/>
        <source>Disconnect</source>
        <translation>Disconnect</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="32"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="98"/>
        <source>Host</source>
        <translation>Host</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="68"/>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="118"/>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="75"/>
        <source>Protocol</source>
        <translation>Protocol</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="35"/>
        <source>User</source>
        <translation>User</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="48"/>
        <source>Username</source>
        <translation>Username</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="160"/>
        <source>http</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="165"/>
        <source>https</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="113"/>
        <source>&lt;h3&gt;Session Name&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;Session Name&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="248"/>
        <source>Created</source>
        <translation>Created</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="292"/>
        <source>&lt;formated_creation_date&gt;, &lt;username&gt;</source>
        <translation>&lt;formated_creation_date&gt;, &lt;username&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="272"/>
        <source>(X time ago)</source>
        <translation>(X time ago)</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="285"/>
        <source>Last change</source>
        <translation>Last change</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="309"/>
        <source>(Y time ago)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="400"/>
        <source>Actions</source>
        <translation>Actions</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="432"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Activate Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Sets this session as active Session (for security reasons, you are not able open two or more sessions simultaneously).&lt;/p&gt;

&lt;p&gt;When you activate the session, next actions occurs:&lt;/p&gt;
&lt;ul&gt;
	&lt;li&gt;Current open session will close.&lt;/li&gt;
	&lt;li&gt;Load the session data&lt;/li&gt;
	&lt;li&gt;Locate the viwer at last working zone&lt;/li&gt;
&lt;/ul&gt;
&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Activate Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Sets this session as active Session (for security reasons, you are not able to open two or more sessions simultaneously).&lt;/p&gt;

&lt;p&gt;When you activate the session, next actions occurs:&lt;/p&gt;
&lt;ul&gt;
	&lt;li&gt;The actual open session will be closed.&lt;/li&gt;
	&lt;li&gt;The new session data will be load.&lt;/li&gt;
	&lt;li&gt;The map canvas will be placed on the session workspace.&lt;/li&gt;
&lt;/ul&gt;
&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="465"/>
        <source>Activate</source>
        <translation>Activate</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="484"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Deactivate Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Turns this session inactive.&lt;/p&gt;

&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Deactivate Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Turns this session inactive.&lt;/p&gt;

&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="514"/>
        <source>Deactivate</source>
        <translation>Deactivate</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="524"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Edit Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;You can edit name and session extesion.&lt;/p&gt;

&lt;ul&gt;
	&lt;li style=&quot;color: #844&quot;&gt;NOTE: this option is only available for &lt;b&gt;Closed&lt;/b&gt; sessions.&lt;/li&gt;
&lt;/ul&gt;
&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Edit Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;You can edit name and session extension.&lt;/p&gt;

&lt;ul&gt;
	&lt;li style=&quot;color: #844&quot;&gt;NOTE: this option is only available for &lt;b&gt;Closed&lt;/b&gt; sessions.&lt;/li&gt;
&lt;/ul&gt;
&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="554"/>
        <source>Edit</source>
        <translation>Edit</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="564"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Commit Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Merges and consolidates this session with information base.&lt;/p&gt;

&lt;ul&gt;
	&lt;li style=&quot;color: #844&quot;&gt;NOTE: &lt;b&gt;This action is not revesible.&lt;/b&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Commit Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Merges and consolidates this session changes with the production data.&lt;/p&gt;

&lt;ul&gt;
	&lt;li style=&quot;color: #844&quot;&gt;NOTE: &lt;b&gt;This action is not reversible.&lt;/b&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="594"/>
        <source>Commit</source>
        <translation>Commit</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="610"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}

&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Discard Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;This session will be removed from sessions list&lt;/p&gt;

&lt;ul&gt;
	&lt;li style=&quot;color: #844&quot;&gt;Be aware: &lt;b&gt;All session changes will be lost. This action is not revesible.&lt;/b&gt;&lt;/li&gt;
&lt;/ul&gt;

&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}

&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Discard Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;This session will be removed from sessions list&lt;/p&gt;

&lt;ul&gt;
	&lt;li style=&quot;color: #844&quot;&gt;Be aware: &lt;b&gt;All session changes will be lost. This action is not revesible.&lt;/b&gt;&lt;/li&gt;
&lt;/ul&gt;

&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="649"/>
        <source>Discard</source>
        <translation>Discard</translation>
    </message>
</context>
<context>
    <name>FormFeatureDialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="66"/>
        <source>QGISCE Form Dialog </source>
        <translation>QGISCE Form Dialog </translation>
    </message>
</context>
<context>
    <name>MessageBarProgressItem</name>
    <message>
        <location filename="../qgiscegui/message_bar_progress.py" line="48"/>
        <source>Abort</source>
        <translation>Abort</translation>
    </message>
</context>
<context>
    <name>PluginDependenciesDialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="42"/>
        <source>Action</source>
        <translation>Action</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="42"/>
        <source>Available</source>
        <translation>Available</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="42"/>
        <source>Installed</source>
        <translation>Installed</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="42"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="38"/>
        <source>QGISCE Plugin Dependencies Manager</source>
        <translation>QGISCE Plugin Dependencies Manager</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="42"/>
        <source>Required</source>
        <translation>Required</translation>
    </message>
</context>
<context>
    <name>QGISCEDialogBase</name>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="105"/>
        <source>Activate debug mode</source>
        <translation>Activate debug mode</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="67"/>
        <source>Advanced</source>
        <translation>Advanced</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="99"/>
        <source>Debug</source>
        <translation>Debug</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="79"/>
        <source>DSN</source>
        <translation>DSN</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="89"/>
        <source>Enable</source>
        <translation>Enable</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="24"/>
        <source>ERP connection configuration</source>
        <translation>ERP connection configuration</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/qgisce_dialog_base.ui" line="35"/>
        <source>ERP Model</source>
        <translation>ERP Model</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/qgisce_dialog_base.ui" line="22"/>
        <source>ERP MODEL LOADER</source>
        <translation>ERP MODEL LOADER</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="115"/>
        <source>Identify</source>
        <translation>Identify</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/qgisce_dialog_base.ui" line="59"/>
        <source>Load Catalog</source>
        <translation>Load Catalog</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/qgisce_dialog_base.ui" line="52"/>
        <source>Open Model Form</source>
        <translation>Open Model Form</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="37"/>
        <source>Project settings</source>
        <translation>Project settings</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="14"/>
        <source>QGISCE</source>
        <translation>QGISCE</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="131"/>
        <source>Search radius in pixels</source>
        <translation>Search radius in pixels</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="73"/>
        <source>Sentry</source>
        <translation>Sentry</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="59"/>
        <source>Set QGISCE project as default</source>
        <translation>Set QGISCE project as default</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/qgisce_dialog_base.ui" line="45"/>
        <source>Type the model to show</source>
        <translation>Type the model to show</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="46"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This function makes a copy of the plugin&apos;s provided project template and setup QGIS to always start with that project. &lt;/p&gt;&lt;p&gt;The project is also configured to automatically load the full catalog at start.&lt;/p&gt;&lt;p&gt;To disable this function, you can set a different option in QGIS global options dialog under &lt;span style=&quot; font-weight:600;&quot;&gt;General → Project files&lt;/span&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This function makes a copy of the plugin&apos;s provided project template and setup QGIS to always start with that project. &lt;/p&gt;&lt;p&gt;The project is also configured to automatically load the full catalog at start.&lt;/p&gt;&lt;p&gt;To disable this function, you can set a different option in QGIS global options dialog under &lt;span style=&quot; font-weight:600;&quot;&gt;General → Project files&lt;/span&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/manual_download_dialog.ui" line="25"/>
        <source>Download all catalog data for the selected extent (default to current canvas extent)</source>
        <translation>Download all catalog data for the selected extent (default to current canvas extent)</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="141"/>
        <source>Multiform</source>
        <translation>Multiform</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="147"/>
        <source>This parameter defines the maximum number of forms that will be opened simultaneously</source>
        <translation>This parameter defines the maximum number of forms that will be opened simultaneously</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="164"/>
        <source>Download</source>
        <translation>Download</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="170"/>
        <source>Select a download mode</source>
        <translation>Select a download mode</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="178"/>
        <source>Sequential</source>
        <translation>Sequential</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="183"/>
        <source>Multithread</source>
        <translation>Multithread</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="198"/>
        <source>Threads</source>
        <translation>Threads</translation>
    </message>
</context>
<context>
    <name>SessionChangesModel</name>
    <message>
        <location filename="../qgiscegui/session_changes_model.py" line="38"/>
        <source>Unsaved changes</source>
        <translation>Unsaved changes</translation>
    </message>
    <message>
        <location filename="../qgiscegui/session_changes_model.py" line="40"/>
        <source>Saved changes</source>
        <translation>Saved changes</translation>
    </message>
</context>
<context>
    <name>SessionChangesReportDialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/session_changes_report_dialog.py" line="41"/>
        <source>QGISCE session </source>
        <translation>QGISCE session </translation>
    </message>
</context>
<context>
    <name>SessionChangesWidget</name>
    <message>
        <location filename="../qgiscegui/dialogs/session_changes_widget.py" line="43"/>
        <source>QGISCE session changes</source>
        <translation>QGISCE session changes</translation>
    </message>
</context>
<context>
    <name>SessionCreateDialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="182"/>
        <source>A session must have a name</source>
        <translation>A session must have a name</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="185"/>
        <source>A session with this name already exists</source>
        <translation>A session with this name already exists</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="174"/>
        <source>Could not parse the CRS descriptor: %s</source>
        <translation>Could not parse the CRS descriptor: %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="170"/>
        <source>Empty BBOX from the CRS descriptor: %s</source>
        <translation>Empty BBOX from the CRS descriptor: %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="172"/>
        <source>Error parsing BBOX from the CRS descriptor: %s</source>
        <translation>Error parsing BBOX from the CRS descriptor: %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="65"/>
        <source>QGISCE session creation</source>
        <translation>QGISCE session creation</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="70"/>
        <source>Select extent</source>
        <translation>Select extent</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="177"/>
        <source>You must select the extent for this session</source>
        <translation>You must select the extent for this session</translation>
    </message>
</context>
<context>
    <name>SessionItem</name>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="89"/>
        <source>Today</source>
        <translation>Today</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="91"/>
        <source>Yesterday</source>
        <translation>Yesterday</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="93"/>
        <source>{days} days ago.</source>
        <translation>{days} days ago.</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="128"/>
        <source>Non active session</source>
        <translation>Non active session</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="128"/>
        <source>You want to edit session &lt;b&gt;{session_name}&lt;/b&gt; which is a 
                non active session. &lt;br/&gt;&lt;br/&gt; In order to edit this session You 
                need to activate it previously, and then you can edit it.</source>
        <translation>You want to edit session &lt;b&gt;{session_name}&lt;/b&gt; which is a 
                non active session. &lt;br/&gt;&lt;br/&gt; In order to edit this session You 
                need to activate it previously, and then you can edit it.</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="176"/>
        <source>Active Session</source>
        <translation>Active Session</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="212"/>
        <source> by user </source>
        <translation> by user </translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="218"/>
        <source>Not modified yet.</source>
        <translation>Not modified yet.</translation>
    </message>
</context>
<context>
    <name>SessionManagerDialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="169"/>
        <source>Discard session</source>
        <translation>Discard session</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="169"/>
        <source>Do you really want to discard session &lt;b&gt;%s&lt;/b&gt;?</source>
        <translation>Do you really want to discard session &lt;b&gt;%s&lt;/b&gt;?</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="59"/>
        <source>New session</source>
        <translation>New session</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="51"/>
        <source>QGISCE sessions manager</source>
        <translation>QGISCE sessions manager</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="85"/>
        <source>Save modifications</source>
        <translation>Save modifications</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="85"/>
        <source>There are unsaved modifications to the following layers:&lt;ul&gt;&lt;li&gt;%s&lt;/li&gt;&lt;/ul&gt;all session changes will be lost.&lt;br&gt;Do you want to save them now?</source>
        <translation>There are unsaved modifications to the following layers:&lt;ul&gt;&lt;li&gt;%s&lt;/li&gt;&lt;/ul&gt;all session changes will be lost.&lt;br&gt;Do you want to save them now?</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="191"/>
        <source>Merge session</source>
        <translation>Merge session</translation>
    </message>
</context>
<context>
    <name>SetupDialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/setup_dialog.py" line="35"/>
        <source>QGISCE setup</source>
        <translation>QGISCE setup</translation>
    </message>
</context>
<context>
    <name>ValidationResultsModel</name>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="174"/>
        <source>Validated</source>
        <translation>Validated</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="163"/>
        <source>Is supplied</source>
        <translation>Is supplied</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="139"/>
        <source>Is connected</source>
        <translation>Is connected</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="174"/>
        <source>True</source>
        <translation>Yes</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="60"/>
        <source>False</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="66"/>
        <source>Errors</source>
        <translation>Errors</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="111"/>
        <source>Name: {}</source>
        <translation>Name: {}</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="115"/>
        <source>ID: {}</source>
        <translation>ID: {}</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="119"/>
        <source>Right-click for zoom to element</source>
        <translation>Right-click for zoom to element</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="127"/>
        <source>Critical</source>
        <translation>Critical</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="151"/>
        <source>Warning</source>
        <translation>Warning</translation>
    </message>
</context>
<context>
    <name>ValidationResultsWidget</name>
    <message>
        <location filename="../qgiscegui/dialogs/validation_results_widget.py" line="45"/>
        <source>QGISCE validation results</source>
        <translation>QGISCE validation results</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/validation_results_widget.py" line="69"/>
        <source>Zoom to element</source>
        <translation>Zoom to element</translation>
    </message>
</context>
<context>
    <name>session_changes_widget</name>
    <message>
        <location filename="../qgiscegui/dialogs/session_changes_widget.ui" line="14"/>
        <source>DockWidget</source>
        <translation>DockWidget</translation>
    </message>
</context>
</TS>
