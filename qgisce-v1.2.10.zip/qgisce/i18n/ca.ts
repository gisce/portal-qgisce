<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ca">
<context>
    <name>@default</name>
    <message>
        <location filename="../qgisceutils/session.py" line="194"/>
        <source>{} deleted</source>
        <translation>{} esborrat</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="196"/>
        <source>{} geometry changed</source>
        <translation>{} geometria canviada</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="200"/>
        <source>{} multiple attribute changed</source>
        <translation>{} atributs canviats</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="198"/>
        <source>{} single attribute changed</source>
        <translation>{} únic atribut canviat</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="438"/>
        <source>Topology</source>
        <translation>Topologia</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="683"/>
        <source>&amp;QGISCE</source>
        <translation>&amp;QGISCE</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1543"/>
        <source>&lt;b&gt;%s&lt;/b&gt; %s successfully</source>
        <translation>&lt;b&gt;%s&lt;/b&gt; %s correctament</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="435"/>
        <source>A line must have at least two vertices in layer: %s</source>
        <translation>Una linia ha de tenir com a mínim dos nodes a la capa: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="892"/>
        <source>A session with this name (%s) already exists, please choose a different name.</source>
        <translation>Ja existeix una sessió amb el nom &apos;%s&apos;, s.u.p. esculli un nom diferent.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="510"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="150"/>
        <source>Add</source>
        <translation>Afegir</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="430"/>
        <source>Adding layer %s</source>
        <translation>Afegint capa %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1342"/>
        <source>All layers have been downloaded correctly.</source>
        <translation>Totes les capes s&apos;han descarregat correctament.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp.py" line="114"/>
        <source>An error occourred while connecting to ERP backend, please check your connection settings and see message logs for further details.</source>
        <translation>Ha aparegut un error al intentar connectar amb l&apos;ERP, s.u.p. revisi la configuració de la connexió. Per més informació revisi els logs.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp.py" line="119"/>
        <source>An error occourred while connecting to ERP backend: %s</source>
        <translation>Ha aparegut un error al intentar connectar amb l&apos;ERP: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1209"/>
        <source>An error occourred while loading data from the server during catalog loading, see the message logs for details.</source>
        <translation>Ha aparegut un error al descarregar dades en el procés de càrrega del catàleg, revisi el log per més informació.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1871"/>
        <source>An error occourred while loading data from the server during session loading, see the message logs for details.</source>
        <translation>Ha aparegut un error al recuperar del servidor les dades de la sessió, revisi els logs per més informació.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1211"/>
        <source>An error occourred while loading data from the server: %s</source>
        <translation>Ha aparegut un error al descarregar dades: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1873"/>
        <source>An error occourred while loading session data from the server: %s</source>
        <translation>Ha aparegut un error al recuperar del servidor les dades de la sessió: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="156"/>
        <source>Attribute change</source>
        <translation>Canvi als atributs</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp.py" line="109"/>
        <source>Bad credentials!</source>
        <translation>Credencials d&apos;accés incorrectes!</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="2036"/>
        <source>Catalog loading error</source>
        <translation>Error de càrrega del catàleg</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp.py" line="114"/>
        <source>Connection error</source>
        <translation>Error de connexió</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1244"/>
        <source>Connection status: ERROR! %s</source>
        <translation>Estat de connexió: ERROR! %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1214"/>
        <source>Connection to ERP failed, error loading QGISCE catalog.</source>
        <translation>No s&apos;ha pogut connectar amb l&apos;ERP, problemes carregant el catàleg de QGISCE.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1879"/>
        <source>Connection to ERP failed, error loading QGISCE session.</source>
        <translation>Connexió amb l&apos;ERP fallida, error carregant la sessió de QGISCE.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1701"/>
        <source>Connection to ERP failed, error loading QGISCE sessions.</source>
        <translation>No s&apos;ha pogut connectar amb l&apos;ERP, problemes al carregar les sessions de QGISCE.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="672"/>
        <source>Connection to ERP failed, error logging into QGISCE.</source>
        <translation>No s&apos;ha pogut connectar amb l&apos;ERP, problemes en el procés d&apos;autenticació.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1134"/>
        <source>Could not parse the CRS descriptor: %s</source>
        <translation>No es pot processar el descriptor CRS: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="152"/>
        <source>Delete</source>
        <translation>Esborrar</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="211"/>
        <source>Edge id %s created</source>
        <translation>Edge id %s creat</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="315"/>
        <source>Edge id %s found</source>
        <translation>Edge id %s trobat</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1128"/>
        <source>Empty BBOX from the CRS descriptor: %s</source>
        <translation>BBOX buida pel descriptor CRS: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="211"/>
        <source>ERPSync geometry_changes on layer %s fid %s: %s</source>
        <translation>ERPSync canvis de geometria a la capa %s fid %s: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="402"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1546"/>
        <source>Error %s &lt;b&gt;%s&lt;/b&gt; %s: %s</source>
        <translation>Error %s &lt;b&gt;%s&lt;/b&gt; %s: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/json_layer.py" line="362"/>
        <source>Error adding SVG symbol for layer %s: symbol layer not found</source>
        <translation>Error al afegir el símbol SVG per la capa %s: símbol de capa no trobat</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1010"/>
        <source>Error converting element ID to integer: %s</source>
        <translation>Error converting ID d&apos;element a un enter: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1790"/>
        <source>Error creating QGISCE session: %s.</source>
        <translation>Error creant la sessió de QGISCE: %s.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="386"/>
        <source>Error downloading layer: %s&lt;br/&gt;%s</source>
        <translation>Error descarregant la capa: %s&lt;br/&gt;%s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="392"/>
        <source>Error downloading layer: no returned values!</source>
        <translation>Error al descarregar la capa: no s&apos;ha pogut recuperar cap valor!</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="402"/>
        <source>Error downloading layer: returned values are incomplete! %s</source>
        <translation>Error descarregant la capa: els valors recuperats estan incomplerts! %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="2036"/>
        <source>Error loading QGISCE catalog: %s</source>
        <translation>Error carregant el catàleg del QGISCE: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1922"/>
        <source>Error loading QGISCE session: %s</source>
        <translation>Error carregant la sessió de QGISCE: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1698"/>
        <source>Error loading sessions: %s</source>
        <translation>Error carregant les sessions: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1131"/>
        <source>Error parsing BBOX from the CRS descriptor: %s</source>
        <translation>Error al processar BBOX emprant el descriptor CRS: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1005"/>
        <source>Error parsing model name: %s</source>
        <translation>Error processant el nom de model: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="86"/>
        <source>Error retrieving %s layer: %s</source>
        <translation>Error descarregant la capa %s: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="421"/>
        <source>Error retrieving layer: %s</source>
        <translation>Error recuperant la capa: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="124"/>
        <source>Error retrieving snapping layer catalog id %s required by layer %s</source>
        <translation>Error recuperant la capa d&apos;snapping amb ID %s requerit per la capa %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1827"/>
        <source>Error saving QGISCE session: %s</source>
        <translation>Error desant la sessió de QGISCE: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="745"/>
        <source>featureIdentified event feature id: %s, attrs: %s</source>
        <translation>featureIdentified event feature id: %s, attrs: %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="84"/>
        <source>Fix manually</source>
        <translation>Corregir manualment</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="154"/>
        <source>Geometry change</source>
        <translation>Canvi geomètric</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="517"/>
        <source>Identify</source>
        <translation>Identificar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="70"/>
        <source>Install</source>
        <translation>Instal·lar</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1543"/>
        <source>installed</source>
        <translation>instal·lat</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1546"/>
        <source>installing</source>
        <translation>instal·lant</translation>
    </message>
    <message>
        <location filename="../qgisceutils/json_layer.py" line="328"/>
        <source>Invalid style for layer self.%s: file not found: %s</source>
        <translation>Estil invàlid per la capa self.%s: fitxer no trobat: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/json_layer.py" line="340"/>
        <source>Invalid symbol for layer %s: file not found: %s</source>
        <translation>Símbol invàlid per la capa %s: fitxer no trobat: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/catalog.py" line="182"/>
        <source>Layer information for %s (catalog id: %s) successfully fetched from catalog</source>
        <translation>Informació de la capa %s (catalog_id: %s) correctament descarregada del catàleg</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="389"/>
        <source>Layer loader has been canceled by the user.</source>
        <translation>Descàrrega de la capa cancel·lada per l&apos;usuari.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1342"/>
        <source>Loading completed</source>
        <translation>Càrrega finalitzada</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1644"/>
        <source>Loading layers information ...</source>
        <translation>Carregant informació de les capes...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1012"/>
        <source>Model name error</source>
        <translation>Error al nom de model</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1012"/>
        <source>Model name is not valid! %s</source>
        <translation>El nom de model no és vàlid! %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="192"/>
        <source>New {}</source>
        <translation>Nou {}</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1502"/>
        <source>New print templates installed</source>
        <translation>Noves plantilles d&apos;impressió instal·lades</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1306"/>
        <source>No active session</source>
        <translation>No hi ha cap sessió activa</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="393"/>
        <source>Node id %s created</source>
        <translation>Node id %s creat</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="366"/>
        <source>Node id %s found</source>
        <translation>Node id %s trobat</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="445"/>
        <source>Node id set to %s for feature id %s</source>
        <translation>ID de node definit com %s per l&apos;element amb id %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1543"/>
        <source>Plugin dependency</source>
        <translation>Dependència del complement</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1546"/>
        <source>Plugin dependency error</source>
        <translation>Error en la dependència del complement</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.py" line="83"/>
        <source>Project setup completed</source>
        <translation>Configuració del projecte finalitzada</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1995"/>
        <source>Project template update</source>
        <translation>Actualització de la plantilla de projecte</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1304"/>
        <source>QGISCE Session: %s</source>
        <translation>Sessió del QGISCE: %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/manual_download_dialog.py" line="29"/>
        <source>Select extent</source>
        <translation>Seleccionar extensió</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1876"/>
        <source>Selected session &lt;b&gt;%s&lt;/b&gt; is already active</source>
        <translation>La sessió &lt;b&gt;%s&lt;/b&gt; ja es troba actualment activa</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1461"/>
        <source>Sentry enabled!</source>
        <translation>Sentry activat!</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1876"/>
        <source>Session</source>
        <translation>Sessió</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1732"/>
        <source>Session &lt;b&gt;%s&lt;/b&gt; could not be deleted.</source>
        <translation>La sessió &lt;b&gt;%s&lt;/b&gt; no s&apos;ha pogut esborrar.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1719"/>
        <source>Session &lt;b&gt;%s&lt;/b&gt; has been successfully deleted.</source>
        <translation>La sessió &lt;b&gt;%s&lt;/b&gt; ha estat esborrada correctament.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="640"/>
        <source>Session active error</source>
        <translation>Error de sessió activa</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1790"/>
        <source>Session creation error</source>
        <translation>Error al crear la sessió</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1719"/>
        <source>Session delete</source>
        <translation>Esborrar sessió</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1732"/>
        <source>Session delete error</source>
        <translation>Error esborrant la sessió</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1922"/>
        <source>Session loading error</source>
        <translation>Error carregant la sessió</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="495"/>
        <source>Session manager</source>
        <translation>Gestor de sessions</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1758"/>
        <source>Session merge error</source>
        <translation>Error aplicant la sessió</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1749"/>
        <source>Session merged</source>
        <translation>Sessió aplicada</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1827"/>
        <source>Session save error</source>
        <translation>Error al desar la sessió</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="503"/>
        <source>Settings</source>
        <translation>Configuració</translation>
    </message>
    <message>
        <location filename="../qgisceutils/connections.py" line="185"/>
        <source>Synchronization signals connected to layer %s</source>
        <translation>Senyals de sincronització connectades a la capa %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="771"/>
        <source>The active layer (%s) is not managed by the QGISCE plugin</source>
        <translation>La capa activa (%s) no està gestionada pel complement QGISCE</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1470"/>
        <source>The new project will be loaded automatically at the next QGIS start. Do you want to load the default project now?</source>
        <translation>El nou projecte serà carregat de forma automàtica al proper inici de QGIS. Vol carregar el projecte per defecte ara mateix?</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="144"/>
        <source>Topology snapping disabled for layer %s</source>
        <translation>Snapping per topològia deshabilitat per la capa %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="77"/>
        <source>Upgrade</source>
        <translation>Actualitzar</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1543"/>
        <source>upgraded</source>
        <translation>actualitzat</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1546"/>
        <source>upgrading</source>
        <translation>actualitzant</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="640"/>
        <source>You need an active session in order to create a report for it!</source>
        <translation>Es necessita tenir una sessió activa per poder crear l&apos;informe de canvis!</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="270"/>
        <source>Download full catalog</source>
        <translation>Descarregar el catàleg complet</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="485"/>
        <source>Search indexed elements</source>
        <translation>Buscar elements indexats</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="542"/>
        <source>Reload current catalog</source>
        <translation>Recarregar catàleg actual</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="578"/>
        <source>Validate network</source>
        <translation>Validar xarxa</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="810"/>
        <source>Error opening the ERP form</source>
        <translation>Error obrint el formulari de l&apos;ERP</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="813"/>
        <source>Impossible to open the form while identifing the element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>No ha estat possible obrir el formulari mentre s&apos;identifica l&apos;element &lt;b&gt;{}&lt;/b&gt; de la capa &lt;b&gt;{}&lt;/b&gt;. Retrocedint als últims canvis no guardats de la capa. Consulti els registres per més informació.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="818"/>
        <source>Impossible to open the form while identifing the element {} on layer {}</source>
        <translation>No ha estat possible obrir el formulari mentre s&apos;identifica l&apos;element {} de la capa {}</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="825"/>
        <source>Impossible to open the form while creating a new element on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>No ha estat possible obrir el formulari mentre es crea un element nou a la capa &lt;b&gt;{}&lt;/b&gt;. Retrocedint als últims canvis no guardats de la capa. Consulti els registres per més informació.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="830"/>
        <source>Impossible to open the form while creating a new element on layer {}</source>
        <translation>No ha estat possible obrir el formulari mentre es crea un element nou a la capa {}</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="940"/>
        <source>%s: %s</source>
        <translation>%s: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1050"/>
        <source>Validator not implemented</source>
        <translation>El validador no s&apos;ha implementat</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1050"/>
        <source>The validator only works for the electrical network.</source>
        <translation>El validador només funciona per la xarxa elèctrica.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1058"/>
        <source>Impossible to validate the network</source>
        <translation>No és possible validar la xarxa</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1058"/>
        <source>There are some changes that must be saved before validating the network on the following layers: {}</source>
        <translation>Hi ha alguns canvis que s&apos;han de guardar abans de validar la xarxa a les següents capes: {}</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1097"/>
        <source>Validator error</source>
        <translation>Error del validador</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1097"/>
        <source>The validator raised an exception %s</source>
        <translation>El validador ha generat una excepció %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1570"/>
        <source>Layer loading error</source>
        <translation>Error de càrrega de la capa</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1570"/>
        <source>Error loading layers: %s</source>
        <translation>Error en carregar les capes: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1592"/>
        <source>Loading visible layers only for session %s ...</source>
        <translation>Carregant només les capes visibles per la sessió %s ...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1592"/>
        <source>Loading full catalog for session %s ...</source>
        <translation>Carregant el catàleg complet per la sessió %s ...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1596"/>
        <source>Loading visible layers only ...</source>
        <translation>Carregant només les capes visibles ...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1596"/>
        <source>Loading full catalog ...</source>
        <translation>Carregant el catàleg complet...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1604"/>
        <source>Error downloading catalog elements from the ERP</source>
        <translation>S&apos;ha produït un error en baixar els elements del catàleg de l&apos;ERP</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1605"/>
        <source>Impossible to download the catalog elements from the ERP. Check the logs for more information.</source>
        <translation>No ha estat possible descarregar els elements del catàleg de la ERP. Consulti els registres per més informació.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1609"/>
        <source>Error downloading catalog elements from the ERP:
</source>
        <translation>S&apos;ha produït un error en descarregar els elements del catàleg de l&apos;ERP:
</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1750"/>
        <source>Session &lt;b&gt;{}&lt;/b&gt; has been successfully merged.</source>
        <translation>La sessió &lt;b&gt;{}&lt;/b&gt; s&apos;ha aplicat correctament.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1759"/>
        <source>Session &lt;b&gt;{}&lt;/b&gt; could not be merged. Check the logs for more information.</source>
        <translation>La sessió &lt;b&gt;{}&lt;/b&gt; no s&apos;ha pogut aplicar. Consulti els registres per més informació.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1763"/>
        <source>Session {} could not be merged</source>
        <translation>La sessió {} no s&apos;ha pogut aplicar</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1846"/>
        <source>Activating session &lt;b&gt;{}: {}&lt;/b&gt;</source>
        <translation>Activant la sessió &lt;b&gt;{}: {}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1964"/>
        <source>Downloading visible layers from current canvas extent...</source>
        <translation>S&apos;estan baixant les capes visibles de l&apos;extensió actual del llenç...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1976"/>
        <source>Downloading full catalog from current canvas extent...</source>
        <translation>S&apos;està baixant el catàleg complet de l&apos;extensió actual del llenç...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1995"/>
        <source>An update for the QGIS project is available.&lt;br&gt;The new project template will be installed as the default project.&lt;br&gt;The new project will use a different name and you will be able to reload your current (old) project in case you wanted to copy over some of your changes.&lt;br&gt;PROJECT PATH: (&lt;pre&gt;%s&lt;/pre&gt;)</source>
        <translation>Hi ha disponible una actualització del projecte QGIS.&lt;br&gt;La nova plantilla del projecte serà instal·lada com a projecte per defecte.&lt;br&gt;El nou projecte utilitzarà un nom diferent i es podrà tornar a carregar el projecte actual (antic) per si es vol copiar alguns dels canvis realitzats.&lt;br&gt;RUTA DEL PROJECTE: (&lt;pre&gt;%s&lt;/pre&gt;)</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.py" line="83"/>
        <source>The new project will be loaded automatically at the next QGIS start.&lt;br&gt;Do you want to load the default project now?</source>
        <translation>El nou projecte serà carregat automàticament una vegada es torni a encendre el QGIS.&lt;br&gt;Voldria carregar el projecte per defecte ara mateix?</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="2106"/>
        <source>1 item found for layer &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>S&apos;ha trobat 1 element per la capa &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="2110"/>
        <source>{} items found for layer &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>S&apos;han trobat {} elements per a la capa &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="2122"/>
        <source>Search result</source>
        <translation>Resultat de la cerca</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="2122"/>
        <source>No items found for layer &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>No s&apos;han trobat elements per a la capa &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="141"/>
        <source>Topology snapping enabled for layer %s</source>
        <translation>S&apos;ha activat l&apos;snapping per a la capa% s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="440"/>
        <source>Edge id is %s for feature id %s</source>
        <translation>L&apos;identificador de l&apos;Edge és %s per la característica id %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="130"/>
        <source>Dirty</source>
        <translation>Brut</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="130"/>
        <source>Clean</source>
        <translation>Net</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="287"/>
        <source>Load layers from remote ERP server</source>
        <translation>Carregar les capes des del servidor ERP remot</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="325"/>
        <source>Waiting for main loader to stop subtasks ...</source>
        <translation>S&apos;està esperant que el carregador principal aturi les subtasques ...</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="440"/>
        <source>AcotaciÃ³</source>
        <translation>Acotació</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="238"/>
        <source>Geometry change error</source>
        <translation>Error de canvi de geometria</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="239"/>
        <source>Impossible to change geometry for element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>No ha estat possible canviar la geometria per l&apos;element.&lt;b&gt;{}&lt;/b&gt;de la capa &lt;b&gt;{}&lt;/b&gt;. Retrocedint als últims canvis no guardats de la capa. Consulti els registres per més informació.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="244"/>
        <source>Impossible to change geometry for element {} on layer {}</source>
        <translation>No ha estat possible canviar la geometria per l&apos;element {} de la capa {}</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="309"/>
        <source>ERPSync value changed for layer %s on erp_id %s: %s</source>
        <translation>EPSync valor modificat en la capa %s amb erp_id %s: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="311"/>
        <source>Value change error</source>
        <translation>Error de canvi de valor</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="312"/>
        <source>Impossible to change values for element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>No ha estat possible canviar els valors per l&apos;element &lt;b&gt;{}&lt;/b&gt; de la capa &lt;b&gt;{}&lt;/b&gt;.Retrocedint als últims canvis no guardats de la capa. Consulti els registres per més informació.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="317"/>
        <source>Impossible to change values for element {} on layer {}</source>
        <translation>No ha estat possible canviar els valors per l&apos;element {} de la capa {}</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="354"/>
        <source>ERPSync DEFERRED feature_deleted %s erp_id is None, SKIPPING: fid %s</source>
        <translation>ERPSync DEFERRED feature_deleted %s erp_id és None, SKIPPING: fid %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="367"/>
        <source>ERPSync feature_deleted on layer %s fid: %s erp_id %s</source>
        <translation>ERPSync feature_deleted a la capa %s fid: %s erp_id %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="373"/>
        <source>Delete element error</source>
        <translation>Error al eliminar l&apos;element</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="374"/>
        <source>Impossible to delete element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>No ha estat possible eliminar l&apos;element &lt;b&gt;{}&lt;/b&gt; de la capa &lt;b&gt;{}&lt;/b&gt;. Retrocedint als últims canvis no guardats de la capa. Consulti els registres per més informació.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="379"/>
        <source>Impossible to delete element {} on layer {}</source>
        <translation>No ha estat possible eliminar l&apos;element {} de la capa {}</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="630"/>
        <source>ERPSync feature_added %s: erp_id: %s - %s</source>
        <translation>ERPSync feature_added %s: erp_id: %s - %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="637"/>
        <source>Error adding element</source>
        <translation>Error afegint l&apos;element</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="638"/>
        <source>Impossible to add element on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>No ha estat possible afegir l&apos;element a la capa &lt;b&gt;{}&lt;/b&gt;. Retrocedint als últims canvis no guardats de la capa. Consulti els registres per més informació.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="643"/>
        <source>Impossible to add element on layer {}</source>
        <translation>No ha estat possible afegir l&apos;element a la capa {}</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="701"/>
        <source>Error synchronizing the element</source>
        <translation>Error al sincronitzar l&apos;element</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="702"/>
        <source>Impossible to synchronize the element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>No ha estat possible sincronitzar l&apos;element &lt;b&gt;{}&lt;/b&gt; de la capa &lt;b&gt;{}&lt;/b&gt;.Retrocedint als últims canvis no guardats de la capa. Consulti els registres per més informació.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="707"/>
        <source>Impossible to synchronize element {} on layer {}</source>
        <translation>No ha estat possible sincronitzar l&apos;element {} de la capa {}</translation>
    </message>
    <message>
        <location filename="../qgiscegui/utils.py" line="104"/>
        <source>Could not zoom to feature with erp_id %s on layer %s</source>
        <translation>No s&apos;ha pogut fer zoom a l&apos;element amb erp_id% s a la capa% s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/validation_results_widget.py" line="108"/>
        <source>Feature with id {} was not found on layer {}!</source>
        <translation>L&apos;element amb id {} no s&apos;ha trobat a la capa {}!</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="214"/>
        <source>Error creating the element to the ERP</source>
        <translation>Error en crear l&apos;element a l&apos;ERP</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="218"/>
        <source>Impossible to create a new element on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>No ha estat possible crear un nou element a la capa &lt;b&gt;{}&lt;/b&gt;. Retrocedint als últims canvis no guardats de la capa. Consulti els registres per més informació.</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="223"/>
        <source>Impossible to create a new element on layer {}</source>
        <translation>No ha estat possible crear un nou element a la capa {}</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="227"/>
        <source>Error modifying the element to the ERP</source>
        <translation>Error en modificar l&apos;element a l&apos;ERP</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="228"/>
        <source>Impossible to modify the element on layer &lt;b&gt;{}&lt;/b&gt;. Changes had no effect. Check the logs for more information.</source>
        <translation>No ha estat possible modificar l&apos;elemement a la capa &lt;b&gt;{}&lt;/b&gt;. Els canvis no han tingut cap efecte. Consulti els registres per més informació.</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="233"/>
        <source>Impossible to modify the element on layer &lt;b&gt;{}&lt;/b&gt;.</source>
        <translation>No ha estat possible modificar l&apos;elemement a la capa &lt;b&gt;{}&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="182"/>
        <source>Validation errors</source>
        <translation>Errors de validació</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="182"/>
        <source>There were errors in the network validation, please check the validation results widget for details</source>
        <translation>Hi ha hagut errors a la validació de la xarxa, si us plau consulti el widget de resultats de validació per obtenir més informació</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="189"/>
        <source>Validation warning</source>
        <translation>Avís de validació</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="196"/>
        <source>The network validation was successfull, please check the validation results widget for details</source>
        <translation>La validació de la xarxa s&apos;ha realitzat correctament, si us plau consulteu el widget de resultats de validació per obtenir més detalls</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="196"/>
        <source>Validation ok</source>
        <translation>Validació ok</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/about_dialog.ui" line="27"/>
        <source>1.1.1</source>
        <translation>1.1.1</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.ui" line="51"/>
        <source>Available sessions</source>
        <translation>Sessions disponibles</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/about_dialog.ui" line="34"/>
        <source>Changelog</source>
        <translation>Historial de canvis</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Diàleg</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/about_dialog.ui" line="78"/>
        <source>Do not show me again</source>
        <translation>No ho tornis a mostrar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/about_dialog.ui" line="51"/>
        <source>QGISCE Plugin</source>
        <translation>Complement QGISCE</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.ui" line="22"/>
        <source>Session name</source>
        <translation>Nom de la sessió</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/about_dialog.ui" line="20"/>
        <source>Version</source>
        <translation>Versió</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/setup_dialog.ui" line="20"/>
        <source>Welcome to QGISCE plugin, please enter the connection configuration to the ERP backend in the form below and click &quot;Connect&quot; to check your connection.</source>
        <translation>Benvingut al complement QGISCE, s.u.p. configuri la connexió amb l&apos;ERP al següent formulari, i faci click a &quot;Connectar&quot; per verificar-ne la connectivitat.</translation>
    </message>
</context>
<context>
    <name>DockWidget</name>
    <message>
        <location filename="../qgiscegui/dialogs/validation_results_widget.ui" line="14"/>
        <source>DockWidget</source>
        <translation>DockWidget</translation>
    </message>
</context>
<context>
    <name>Form</name>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="145"/>
        <source>Connect</source>
        <translation>Connectar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="125"/>
        <source>Database</source>
        <translation>Base de dades</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="138"/>
        <source>Database name</source>
        <translation>Nom de la base de dades</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="152"/>
        <source>Disconnect</source>
        <translation>Desconnectar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="32"/>
        <source>Form</source>
        <translation>Formulari</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="98"/>
        <source>Host</source>
        <translation>Host</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="68"/>
        <source>Password</source>
        <translation>Contrasenya</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="118"/>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="75"/>
        <source>Protocol</source>
        <translation>Protocol</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="35"/>
        <source>User</source>
        <translation>Usuari</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="48"/>
        <source>Username</source>
        <translation>Nom d&apos;usuari</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="160"/>
        <source>http</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="165"/>
        <source>https</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="113"/>
        <source>&lt;h3&gt;Session Name&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;Nom Sessió&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="248"/>
        <source>Created</source>
        <translation>Creada</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="292"/>
        <source>&lt;formated_creation_date&gt;, &lt;username&gt;</source>
        <translation>&lt;formated_creation_date&gt;, &lt;username&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="272"/>
        <source>(X time ago)</source>
        <translation>(X time ago)</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="285"/>
        <source>Last change</source>
        <translation>Última modificació</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="309"/>
        <source>(Y time ago)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="400"/>
        <source>Actions</source>
        <translation>Accions</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="432"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Activate Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Sets this session as active Session (for security reasons, you are not able open two or more sessions simultaneously).&lt;/p&gt;

&lt;p&gt;When you activate the session, next actions occurs:&lt;/p&gt;
&lt;ul&gt;
	&lt;li&gt;Current open session will close.&lt;/li&gt;
	&lt;li&gt;Load the session data&lt;/li&gt;
	&lt;li&gt;Locate the viwer at last working zone&lt;/li&gt;
&lt;/ul&gt;
&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Activar la sessió&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Establir aquesta sessió com a sessió activa (per raons de seguretat, no és possible obrir dos o més sessions simultàniament).&lt;/p&gt;

&lt;p&gt;Quan s&apos;activa la sessió, es produeixen les següents accions:&lt;/p&gt;
&lt;ul&gt;
	&lt;li&gt;La sessió actual que es troba oberta es tancarà.&lt;/li&gt;
	&lt;li&gt;Les dades de la nova sessió es carregaran.&lt;/li&gt;
	&lt;li&gt;La localització del llenç serà la zona de treball de la nova sessió.&lt;/li&gt;
&lt;/ul&gt;
&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="465"/>
        <source>Activate</source>
        <translation>Activar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="484"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Deactivate Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Turns this session inactive.&lt;/p&gt;

&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Desactivar la sessió&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Aquesta sessió passarà a estar inactiva. &lt;/p&gt;

&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="514"/>
        <source>Deactivate</source>
        <translation>Desactivar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="524"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Edit Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;You can edit name and session extesion.&lt;/p&gt;

&lt;ul&gt;
	&lt;li style=&quot;color: #844&quot;&gt;NOTE: this option is only available for &lt;b&gt;Closed&lt;/b&gt; sessions.&lt;/li&gt;
&lt;/ul&gt;
&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Editar la sessió&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Es podrà editar el nom i l&apos;extensió de la sessió.&lt;/p&gt;

&lt;ul&gt;
	&lt;li style=&quot;color: #844&quot;&gt;NOTA: Aquesta opció només està disponible per les sessions que es troben &lt;b&gt;Tancades&lt;/b&gt;.&lt;/li&gt;
&lt;/ul&gt;
&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="554"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="564"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Commit Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Merges and consolidates this session with information base.&lt;/p&gt;

&lt;ul&gt;
	&lt;li style=&quot;color: #844&quot;&gt;NOTE: &lt;b&gt;This action is not revesible.&lt;/b&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Aplicar la sessió&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Aplica i consolida les modificacions de la sessió amb les dades de producció.&lt;/p&gt;

&lt;ul&gt;
	&lt;li style=&quot;color: #844&quot;&gt;NOTA: &lt;b&gt;Aquesta acció no és reversible.&lt;/b&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="594"/>
        <source>Commit</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="610"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}

&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Discard Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;This session will be removed from sessions list&lt;/p&gt;

&lt;ul&gt;
	&lt;li style=&quot;color: #844&quot;&gt;Be aware: &lt;b&gt;All session changes will be lost. This action is not revesible.&lt;/b&gt;&lt;/li&gt;
&lt;/ul&gt;

&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}

&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Descartar la sessió&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Aquesta sessió serà eliminada de la llista de sessions.&lt;/p&gt;

&lt;ul&gt;
	&lt;li style=&quot;color: #844&quot;&gt;Alerta: &lt;b&gt;Tots els canvis que s&apos;han realitzat en aquesta sessió es perdran. Aquesta acció no és reversible.&lt;/b&gt;&lt;/li&gt;
&lt;/ul&gt;

&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="649"/>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
</context>
<context>
    <name>FormFeatureDialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="66"/>
        <source>QGISCE Form Dialog </source>
        <translation>Diàleg de formulari de QGISCE </translation>
    </message>
</context>
<context>
    <name>MessageBarProgressItem</name>
    <message>
        <location filename="../qgiscegui/message_bar_progress.py" line="48"/>
        <source>Abort</source>
        <translation>Cancel·lar</translation>
    </message>
</context>
<context>
    <name>PluginDependenciesDialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="42"/>
        <source>Action</source>
        <translation>Acció</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="42"/>
        <source>Available</source>
        <translation>Disponible</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="42"/>
        <source>Installed</source>
        <translation>Instal·lat</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="42"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="38"/>
        <source>QGISCE Plugin Dependencies Manager</source>
        <translation>Administrador de les dependències del complement QGISCE</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="42"/>
        <source>Required</source>
        <translation>Necessari</translation>
    </message>
</context>
<context>
    <name>QGISCEDialogBase</name>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="105"/>
        <source>Activate debug mode</source>
        <translation>Activar mode de depuració</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="67"/>
        <source>Advanced</source>
        <translation>Avançat</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="99"/>
        <source>Debug</source>
        <translation>Debug</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="79"/>
        <source>DSN</source>
        <translation>DSN</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="89"/>
        <source>Enable</source>
        <translation>Activar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="24"/>
        <source>ERP connection configuration</source>
        <translation>Configuració de la connexió amb l&apos;ERP</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/qgisce_dialog_base.ui" line="35"/>
        <source>ERP Model</source>
        <translation>Model de l&apos;ERP</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/qgisce_dialog_base.ui" line="22"/>
        <source>ERP MODEL LOADER</source>
        <translation>MODELS DE L&apos;ERP</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="115"/>
        <source>Identify</source>
        <translation>Identificar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/qgisce_dialog_base.ui" line="59"/>
        <source>Load Catalog</source>
        <translation>Carregar catàleg</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/qgisce_dialog_base.ui" line="52"/>
        <source>Open Model Form</source>
        <translation>Obrir formulari</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="37"/>
        <source>Project settings</source>
        <translation>Configuració del projecte</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="14"/>
        <source>QGISCE</source>
        <translation>QGISCE</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="131"/>
        <source>Search radius in pixels</source>
        <translation>Radi de cerca (pixels)</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="73"/>
        <source>Sentry</source>
        <translation>Sentry</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="59"/>
        <source>Set QGISCE project as default</source>
        <translation>Establir el projecte de QGISCE per defecte</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/qgisce_dialog_base.ui" line="45"/>
        <source>Type the model to show</source>
        <translation>Introdueixi el model a mostrar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="46"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This function makes a copy of the plugin&apos;s provided project template and setup QGIS to always start with that project. &lt;/p&gt;&lt;p&gt;The project is also configured to automatically load the full catalog at start.&lt;/p&gt;&lt;p&gt;To disable this function, you can set a different option in QGIS global options dialog under &lt;span style=&quot; font-weight:600;&quot;&gt;General → Project files&lt;/span&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Aquesta funció crea una còpia de la plantilla del projecte proporcionada pel complement, i configura el QGIS perquè comenci sempre amb aquest projecte.&lt;/p&gt;&lt;p&gt;A més a més, també es configurarà el projecte per així, automàticament carregar el catàleg complet.&lt;/p&gt;&lt;p&gt;Per desactivar aquesta funció, pot seleccionar una altre opció en el diàleg d&apos;opcions globals del QGIS a sota de &lt;span style=&quot; font-weight:600;&quot;&gt;General → Fitxers del projecte&lt;/span&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/manual_download_dialog.ui" line="25"/>
        <source>Download all catalog data for the selected extent (default to current canvas extent)</source>
        <translation>Descarregueu totes les dades del catàleg de l’extensió seleccionada (per defecte a l’extensió actual del llenç)</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="141"/>
        <source>Multiform</source>
        <translation>Multiformularis</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="147"/>
        <source>This parameter defines the maximum number of forms that will be opened simultaneously</source>
        <translation>Aquest paràmetre defineix el nombre màxim de formularis que s’obriran simultàniament</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="164"/>
        <source>Download</source>
        <translation>Descarrega</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="170"/>
        <source>Select a download mode</source>
        <translation>Selecciona un mode de descàrrega</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="178"/>
        <source>Sequential</source>
        <translation>Seqüencial</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="183"/>
        <source>Multithread</source>
        <translation>Multifil</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="198"/>
        <source>Threads</source>
        <translation>Fils</translation>
    </message>
</context>
<context>
    <name>SessionChangesModel</name>
    <message>
        <location filename="../qgiscegui/session_changes_model.py" line="38"/>
        <source>Unsaved changes</source>
        <translation>Canvis no desats</translation>
    </message>
    <message>
        <location filename="../qgiscegui/session_changes_model.py" line="40"/>
        <source>Saved changes</source>
        <translation>Canvis guardats</translation>
    </message>
</context>
<context>
    <name>SessionChangesReportDialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/session_changes_report_dialog.py" line="41"/>
        <source>QGISCE session </source>
        <translation>Sessió del QGISCE </translation>
    </message>
</context>
<context>
    <name>SessionChangesWidget</name>
    <message>
        <location filename="../qgiscegui/dialogs/session_changes_widget.py" line="43"/>
        <source>QGISCE session changes</source>
        <translation>Canvis de la sessió del QGISCE</translation>
    </message>
</context>
<context>
    <name>SessionCreateDialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="182"/>
        <source>A session must have a name</source>
        <translation>Cal definir un nom per la sessió</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="185"/>
        <source>A session with this name already exists</source>
        <translation>Ja existeix una sessió amb aquest nom</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="174"/>
        <source>Could not parse the CRS descriptor: %s</source>
        <translation>No s&apos;ha pogut identificar el descriptor CRS: %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="170"/>
        <source>Empty BBOX from the CRS descriptor: %s</source>
        <translation>BBOX buïda important el descriptor CRS: %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="172"/>
        <source>Error parsing BBOX from the CRS descriptor: %s</source>
        <translation>Error identificant el BBOX emprant el descriptor CRS: %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="65"/>
        <source>QGISCE session creation</source>
        <translation>Creació de sessió del QGISCE</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="70"/>
        <source>Select extent</source>
        <translation>Seleccionar zona del mapa</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="177"/>
        <source>You must select the extent for this session</source>
        <translation>Cal seleccionar la zona del mapa per la sessió</translation>
    </message>
</context>
<context>
    <name>SessionItem</name>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="89"/>
        <source>Today</source>
        <translation>Avui</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="91"/>
        <source>Yesterday</source>
        <translation>Ahir</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="93"/>
        <source>{days} days ago.</source>
        <translation>Fa {days} dies.</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="128"/>
        <source>Non active session</source>
        <translation>Sessió no activa</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="128"/>
        <source>You want to edit session &lt;b&gt;{session_name}&lt;/b&gt; which is a 
                non active session. &lt;br/&gt;&lt;br/&gt; In order to edit this session You 
                need to activate it previously, and then you can edit it.</source>
        <translation>Es vol editar la sessió &lt;b&gt;{session_name}&lt;/b&gt; que és una 
                sessió no activa. &lt;br/&gt;&lt;br/&gt; per tal que sigui possible editar aquesta sessió 
                cal activar-la prèviament, per així poder-la editar.</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="176"/>
        <source>Active Session</source>
        <translation>Sessió activa</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="212"/>
        <source> by user </source>
        <translation> per l&apos; usuari </translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="218"/>
        <source>Not modified yet.</source>
        <translation>Encara no s&apos;ha modificat.</translation>
    </message>
</context>
<context>
    <name>SessionManagerDialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="169"/>
        <source>Discard session</source>
        <translation>Descartar sessió</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="169"/>
        <source>Do you really want to discard session &lt;b&gt;%s&lt;/b&gt;?</source>
        <translation>Realment vol descartar la sessió &lt;b&gt;%s&lt;/b&gt;?</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="59"/>
        <source>New session</source>
        <translation>Nova sessió</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="51"/>
        <source>QGISCE sessions manager</source>
        <translation>Gestor de sessions del QGISCE</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="85"/>
        <source>Save modifications</source>
        <translation>Desar modificacions</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="85"/>
        <source>There are unsaved modifications to the following layers:&lt;ul&gt;&lt;li&gt;%s&lt;/li&gt;&lt;/ul&gt;all session changes will be lost.&lt;br&gt;Do you want to save them now?</source>
        <translation>Hi ha modificacions pendents de desar en les següents capes:&lt;ul&gt;&lt;li&gt;%s&lt;/li&gt;&lt;/ul&gt; tots els canvis de la sessió es perdran.&lt;br&gt;Vol desar els canvis pendents?</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="191"/>
        <source>Merge session</source>
        <translation>Aplicar la sessió</translation>
    </message>
</context>
<context>
    <name>SetupDialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/setup_dialog.py" line="35"/>
        <source>QGISCE setup</source>
        <translation>Configuració del QGISCE</translation>
    </message>
</context>
<context>
    <name>ValidationResultsModel</name>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="174"/>
        <source>Validated</source>
        <translation>Validat</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="163"/>
        <source>Is supplied</source>
        <translation>Està subministrada</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="139"/>
        <source>Is connected</source>
        <translation>Està connectada</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="174"/>
        <source>True</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="60"/>
        <source>False</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="66"/>
        <source>Errors</source>
        <translation>Errors</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="111"/>
        <source>Name: {}</source>
        <translation>Nom: {}</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="115"/>
        <source>ID: {}</source>
        <translation>ID: {}</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="119"/>
        <source>Right-click for zoom to element</source>
        <translation>Clic-dret per fer zoom a l&apos;element</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="127"/>
        <source>Critical</source>
        <translation>Crítics</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="151"/>
        <source>Warning</source>
        <translation>Avisos</translation>
    </message>
</context>
<context>
    <name>ValidationResultsWidget</name>
    <message>
        <location filename="../qgiscegui/dialogs/validation_results_widget.py" line="45"/>
        <source>QGISCE validation results</source>
        <translation>Resultats de validació del QGISCE</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/validation_results_widget.py" line="69"/>
        <source>Zoom to element</source>
        <translation>Zoom a l&apos;element</translation>
    </message>
</context>
<context>
    <name>session_changes_widget</name>
    <message>
        <location filename="../qgiscegui/dialogs/session_changes_widget.ui" line="14"/>
        <source>DockWidget</source>
        <translation>DockWidget</translation>
    </message>
</context>
</TS>
