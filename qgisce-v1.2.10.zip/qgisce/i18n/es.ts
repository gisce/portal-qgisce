<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es">
<context>
    <name>@default</name>
    <message>
        <location filename="../qgisceutils/session.py" line="194"/>
        <source>{} deleted</source>
        <translation>{} eliminado</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="196"/>
        <source>{} geometry changed</source>
        <translation>{} geometría cambiada</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="200"/>
        <source>{} multiple attribute changed</source>
        <translation>{} atributos cambiados</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="198"/>
        <source>{} single attribute changed</source>
        <translation>{} único atributo cambiado</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="438"/>
        <source>Topology</source>
        <translation>Topología</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="683"/>
        <source>&amp;QGISCE</source>
        <translation>&amp;QGISCE</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1543"/>
        <source>&lt;b&gt;%s&lt;/b&gt; %s successfully</source>
        <translation>&lt;b&gt;%s&lt;/b&gt; %s correctamente</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="435"/>
        <source>A line must have at least two vertices in layer: %s</source>
        <translation>Una línea debe tener al menos dos nodos en la capa: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="892"/>
        <source>A session with this name (%s) already exists, please choose a different name.</source>
        <translation>Ya existe una sesión con el nombre &apos;%s &apos;, p.f.v. escoja un nombre diferente.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="510"/>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="150"/>
        <source>Add</source>
        <translation>Añadir</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="430"/>
        <source>Adding layer %s</source>
        <translation>Añadiendo capa %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1342"/>
        <source>All layers have been downloaded correctly.</source>
        <translation>Todas las capas se han descargado correctamente.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp.py" line="114"/>
        <source>An error occourred while connecting to ERP backend, please check your connection settings and see message logs for further details.</source>
        <translation>Ha aparecido un error al intentar conectar con el ERP, p.f.v. compruebe los ajustes de conexión. Para más información revise los registros.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp.py" line="119"/>
        <source>An error occourred while connecting to ERP backend: %s</source>
        <translation>Ha aparecido un error al intentar conectar con el ERP: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1209"/>
        <source>An error occourred while loading data from the server during catalog loading, see the message logs for details.</source>
        <translation>Ha aparecido un error en la descarga de datos en el proceso de carga de catálogo, compruebe el registro para obtener más información.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1871"/>
        <source>An error occourred while loading data from the server during session loading, see the message logs for details.</source>
        <translation>Ha aparecido un error al recuperar desde el servidor de datos de la sesión, compruebe los registros para obtener más información.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1211"/>
        <source>An error occourred while loading data from the server: %s</source>
        <translation>Ha aparecido un error en la descarga de datos: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1873"/>
        <source>An error occourred while loading session data from the server: %s</source>
        <translation>Ha aparecido un error al recuperar desde el servidor los datos de la sesión: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="156"/>
        <source>Attribute change</source>
        <translation>Cambio en los atributos</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp.py" line="109"/>
        <source>Bad credentials!</source>
        <translation>¡Credenciales de acceso incorrectas!</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="2036"/>
        <source>Catalog loading error</source>
        <translation>Error al cargar el catálogo</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp.py" line="114"/>
        <source>Connection error</source>
        <translation>Error de conexión</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1244"/>
        <source>Connection status: ERROR! %s</source>
        <translation>Estado de conexión: ERROR! %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1214"/>
        <source>Connection to ERP failed, error loading QGISCE catalog.</source>
        <translation>No se pudo conectar con el ERP, problemas en la carga del catálogo de QGISCE.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1879"/>
        <source>Connection to ERP failed, error loading QGISCE session.</source>
        <translation>Conexión con el ERP fallida, error al cargar la sesión QGISCE.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1701"/>
        <source>Connection to ERP failed, error loading QGISCE sessions.</source>
        <translation>No se pudo conectar con el ERP, problemas en la carga de las sesiones de QGISCE.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="672"/>
        <source>Connection to ERP failed, error logging into QGISCE.</source>
        <translation>No se pudo conectar con el ERP, problemas en el proceso de autenticación.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1134"/>
        <source>Could not parse the CRS descriptor: %s</source>
        <translation>No se puede procesar el descriptor CRS: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="152"/>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="211"/>
        <source>Edge id %s created</source>
        <translation>Edge id %s creado</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="315"/>
        <source>Edge id %s found</source>
        <translation>Edge id %s encontrado</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1128"/>
        <source>Empty BBOX from the CRS descriptor: %s</source>
        <translation>BBOX vacía para el descriptor CRS: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="211"/>
        <source>ERPSync geometry_changes on layer %s fid %s: %s</source>
        <translation>ERPSync cambios de geometría en la capa %s fid %s : %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="402"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1546"/>
        <source>Error %s &lt;b&gt;%s&lt;/b&gt; %s: %s</source>
        <translation>Error %s &lt;b&gt;%s&lt;/b&gt; %s: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/json_layer.py" line="362"/>
        <source>Error adding SVG symbol for layer %s: symbol layer not found</source>
        <translation>Error al añadir el símbolo SVG para la capa %s: símbolo de capa no encontrado</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1010"/>
        <source>Error converting element ID to integer: %s</source>
        <translation>Error al convertir el elemento ID a un entero: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1790"/>
        <source>Error creating QGISCE session: %s.</source>
        <translation>Error al crear la sesión de QGISCE: %s.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="386"/>
        <source>Error downloading layer: %s&lt;br/&gt;%s</source>
        <translation>Error descarregant la capa: %s&lt;br/&gt;%s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="392"/>
        <source>Error downloading layer: no returned values!</source>
        <translation>No se pudo descargar la capa: no se ha podido recuperar ningún valor!</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="402"/>
        <source>Error downloading layer: returned values are incomplete! %s</source>
        <translation>Error al descargar la capa: los valores recuperados están incompletos! %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="2036"/>
        <source>Error loading QGISCE catalog: %s</source>
        <translation>Error al cargar el catálogo del QGISCE: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1922"/>
        <source>Error loading QGISCE session: %s</source>
        <translation>Error al cargar la sesión QGISCE: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1698"/>
        <source>Error loading sessions: %s</source>
        <translation>Error al cargar las sesiones: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1131"/>
        <source>Error parsing BBOX from the CRS descriptor: %s</source>
        <translation>Error al procesar BBOX utilizando el descriptor de CRS: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1005"/>
        <source>Error parsing model name: %s</source>
        <translation>Error procesando el nombre de modelo: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="86"/>
        <source>Error retrieving %s layer: %s</source>
        <translation>Error descargando la capa %s : %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="421"/>
        <source>Error retrieving layer: %s</source>
        <translation>Error recuperando la capa: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="124"/>
        <source>Error retrieving snapping layer catalog id %s required by layer %s</source>
        <translation>Error recuperando la capa de snapping con ID %s requerido para la capa %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1827"/>
        <source>Error saving QGISCE session: %s</source>
        <translation>Error al guardar la sesión de QGISCE: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="745"/>
        <source>featureIdentified event feature id: %s, attrs: %s</source>
        <translation>featureIdentified event feature id: %s, attrs: %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="84"/>
        <source>Fix manually</source>
        <translation>Corregir manualmente</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="154"/>
        <source>Geometry change</source>
        <translation>Cambio geométrico</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="517"/>
        <source>Identify</source>
        <translation>Identificar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="70"/>
        <source>Install</source>
        <translation>Instalar</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1543"/>
        <source>installed</source>
        <translation>instalado</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1546"/>
        <source>installing</source>
        <translation>instalando</translation>
    </message>
    <message>
        <location filename="../qgisceutils/json_layer.py" line="328"/>
        <source>Invalid style for layer self.%s: file not found: %s</source>
        <translation>Estilo de la capa inválido %s: no se encuentra el archivo: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/json_layer.py" line="340"/>
        <source>Invalid symbol for layer %s: file not found: %s</source>
        <translation>Símbolo de la capa inválido %s: no se encuentra el archivo: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/catalog.py" line="182"/>
        <source>Layer information for %s (catalog id: %s) successfully fetched from catalog</source>
        <translation>Información de la capa de %s (catalog_id: %s) descargada con éxito del catálogo</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="389"/>
        <source>Layer loader has been canceled by the user.</source>
        <translation>Descarga de la capa cancelada por el usuario.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1342"/>
        <source>Loading completed</source>
        <translation>Carga finalizada</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1644"/>
        <source>Loading layers information ...</source>
        <translation>Cargando información de las capas...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1012"/>
        <source>Model name error</source>
        <translation>Error en el nombre del modelo</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1012"/>
        <source>Model name is not valid! %s</source>
        <translation>¡El nombre del modelo no es válido! %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="192"/>
        <source>New {}</source>
        <translation>Nuevo {}</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1502"/>
        <source>New print templates installed</source>
        <translation>Nuevas plantillas de impresión instaladas</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1306"/>
        <source>No active session</source>
        <translation>No hay ninguna sesión activa</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="393"/>
        <source>Node id %s created</source>
        <translation>Node id %s creado</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="366"/>
        <source>Node id %s found</source>
        <translation>Node id %s encontrado</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="445"/>
        <source>Node id set to %s for feature id %s</source>
        <translation>ID del nodo definido como: %s para el elemento con id %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1543"/>
        <source>Plugin dependency</source>
        <translation>Dependencia del complemento</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1546"/>
        <source>Plugin dependency error</source>
        <translation>Error en la dependencia del complemento</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.py" line="83"/>
        <source>Project setup completed</source>
        <translation>Configuración del proyecto finalizada</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1995"/>
        <source>Project template update</source>
        <translation>Actualización de la plantilla de proyecto</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1304"/>
        <source>QGISCE Session: %s</source>
        <translation>Sessión del QGISCE: %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/manual_download_dialog.py" line="29"/>
        <source>Select extent</source>
        <translation>Seleccionar extensión</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1876"/>
        <source>Selected session &lt;b&gt;%s&lt;/b&gt; is already active</source>
        <translation>La sesión &lt;b&gt;%s&lt;/b&gt; ya se encuentra actualmente activa</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1461"/>
        <source>Sentry enabled!</source>
        <translation>¡Sentry activado!</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1876"/>
        <source>Session</source>
        <translation>Sesión</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1732"/>
        <source>Session &lt;b&gt;%s&lt;/b&gt; could not be deleted.</source>
        <translation>La sesión &lt;b&gt;%s&lt;/b&gt; no se ha podido borrar.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1719"/>
        <source>Session &lt;b&gt;%s&lt;/b&gt; has been successfully deleted.</source>
        <translation>La sesión &lt;b&gt;%s&lt;/b&gt; ha sido borrada correctamente.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="640"/>
        <source>Session active error</source>
        <translation>Error de sesión activa</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1790"/>
        <source>Session creation error</source>
        <translation>Error al crear la sesión</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1719"/>
        <source>Session delete</source>
        <translation>Eliminar sesión</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1732"/>
        <source>Session delete error</source>
        <translation>Error al eliminar la sesión</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1922"/>
        <source>Session loading error</source>
        <translation>Error cargando la sesión</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="495"/>
        <source>Session manager</source>
        <translation>Gestor de sesiones</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1758"/>
        <source>Session merge error</source>
        <translation>Error aplicando la sesión</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1749"/>
        <source>Session merged</source>
        <translation>Sesión aplicada</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1827"/>
        <source>Session save error</source>
        <translation>Error al guardar la sesión</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="503"/>
        <source>Settings</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <location filename="../qgisceutils/connections.py" line="185"/>
        <source>Synchronization signals connected to layer %s</source>
        <translation>Señales de sincronización conectadas a la capa %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="771"/>
        <source>The active layer (%s) is not managed by the QGISCE plugin</source>
        <translation>La capa activa (%s) no está siendo gestionada por el complemento QGISCE</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1470"/>
        <source>The new project will be loaded automatically at the next QGIS start. Do you want to load the default project now?</source>
        <translation>El nuevo proyecto se cargará automáticamente en el próximo inicio de QGIS. ¿Desea cargar ahora el proyecto por defecto?</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="144"/>
        <source>Topology snapping disabled for layer %s</source>
        <translation>Snapping por topología deshabilitado para la capa %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="77"/>
        <source>Upgrade</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1543"/>
        <source>upgraded</source>
        <translation>actualizado</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1546"/>
        <source>upgrading</source>
        <translation>actualizando</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="640"/>
        <source>You need an active session in order to create a report for it!</source>
        <translation>Es necesario tener una sesión activa para poder crear el informe de cambios!</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="270"/>
        <source>Download full catalog</source>
        <translation>Descargar el catálogo completo</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="485"/>
        <source>Search indexed elements</source>
        <translation>Buscar elementos indexados</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="542"/>
        <source>Reload current catalog</source>
        <translation>Recargar catálogo actual</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="578"/>
        <source>Validate network</source>
        <translation>Validar red</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="810"/>
        <source>Error opening the ERP form</source>
        <translation>Error abriendo el formulario del ERP</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="813"/>
        <source>Impossible to open the form while identifing the element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>No ha sido posible abrir el formulario mientras se identifica el elemento &lt;b&gt;{}&lt;/b&gt; de la capa &lt;b&gt;{}&lt;/b&gt;. Retrocediendo a los últimos cambios no guardados de la capa. Consulte los registros para más información.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="818"/>
        <source>Impossible to open the form while identifing the element {} on layer {}</source>
        <translation>No ha sido posible abrir el formulario mientras se identifica el elemento {} de la capa {}</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="825"/>
        <source>Impossible to open the form while creating a new element on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>No ha sido posible abrir el formulario mientras se crea un elemento nuevo en la capa &lt;b&gt;{}&lt;/b&gt;. Retrocediendo a los últimos cambios no guardados de la capa. Consulte los registros para más información.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="830"/>
        <source>Impossible to open the form while creating a new element on layer {}</source>
        <translation>No ha sido posible abrir el formulario mientras se crea un elemento nuevo en la capa {}</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="940"/>
        <source>%s: %s</source>
        <translation>%s: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1050"/>
        <source>Validator not implemented</source>
        <translation>El validador no se ha implementado</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1050"/>
        <source>The validator only works for the electrical network.</source>
        <translation>El validador solo funciona para la red eléctrica.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1058"/>
        <source>Impossible to validate the network</source>
        <translation>No es posible validar la red</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1058"/>
        <source>There are some changes that must be saved before validating the network on the following layers: {}</source>
        <translation>Hay algunos cambios que deben guardarse antes de validar la red en las siguientes capas: {}</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1097"/>
        <source>Validator error</source>
        <translation>Error del validador</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1097"/>
        <source>The validator raised an exception %s</source>
        <translation>El validador ha generado una excepción %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1570"/>
        <source>Layer loading error</source>
        <translation>Error de carga de la capa</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1570"/>
        <source>Error loading layers: %s</source>
        <translation>Error en cargar las capas: %s</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1592"/>
        <source>Loading visible layers only for session %s ...</source>
        <translation>Cargando solo las capas visibles para la sesión %s ...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1592"/>
        <source>Loading full catalog for session %s ...</source>
        <translation>Cargando el catálogo completo para la sesión %s ...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1596"/>
        <source>Loading visible layers only ...</source>
        <translation>Cargando solo las capas visibles ...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1596"/>
        <source>Loading full catalog ...</source>
        <translation>Cargando el catálogo completo...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1604"/>
        <source>Error downloading catalog elements from the ERP</source>
        <translation>Se ha producido un error al descargar los elementos del catálogo de la ERP</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1605"/>
        <source>Impossible to download the catalog elements from the ERP. Check the logs for more information.</source>
        <translation>No ha sido posible descargar los elementos del catálogo de la ERP. Consulte los registros para más información.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1609"/>
        <source>Error downloading catalog elements from the ERP:
</source>
        <translation>Se ha producido un error al descargar los elementos del catálogo de la ERP:
</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1750"/>
        <source>Session &lt;b&gt;{}&lt;/b&gt; has been successfully merged.</source>
        <translation>La sesión &lt;b&gt;{}&lt;/b&gt; se ha aplicado correctamente.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1759"/>
        <source>Session &lt;b&gt;{}&lt;/b&gt; could not be merged. Check the logs for more information.</source>
        <translation>La sesión&lt;b&gt;{}&lt;/b&gt; no se ha podido aplicado. Consulte los registros para más información.</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1763"/>
        <source>Session {} could not be merged</source>
        <translation>La sesión {} no se ha podido aplicar</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1846"/>
        <source>Activating session &lt;b&gt;{}: {}&lt;/b&gt;</source>
        <translation>Activando la sesión &lt;b&gt;{}: {}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1964"/>
        <source>Downloading visible layers from current canvas extent...</source>
        <translation>Se están descargando las capas visibles de la extensión actual del lienzo...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1976"/>
        <source>Downloading full catalog from current canvas extent...</source>
        <translation>Se está descargando el catálogo completo de la extensión actual del lienzo...</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="1995"/>
        <source>An update for the QGIS project is available.&lt;br&gt;The new project template will be installed as the default project.&lt;br&gt;The new project will use a different name and you will be able to reload your current (old) project in case you wanted to copy over some of your changes.&lt;br&gt;PROJECT PATH: (&lt;pre&gt;%s&lt;/pre&gt;)</source>
        <translation>Hay disponible una actualización del proyecto QGIS.&lt;br&gt;La nueva plantilla del proyecto será instalada como proyecto por defecto.&lt;br&gt;El nuevo proyecto utilizará un nombre diferente y se podrá volver a cargar el proyecto actual en caso que se quiera copiar algunos de los cambios realizados.&lt;br&gt;RUTA DEL PROYECTO: (&lt;pre&gt;%s&lt;/pre&gt;)</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.py" line="83"/>
        <source>The new project will be loaded automatically at the next QGIS start.&lt;br&gt;Do you want to load the default project now?</source>
        <translation>El nuevo proyecto será cargado automáticamente una vez se vuelva a encender el QGIS.&lt;br&gt;¿Le gustaría cargar el proyecto por defecto ahora?</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="2106"/>
        <source>1 item found for layer &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>Se ha encontrado 1 elemento para la capa &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="2110"/>
        <source>{} items found for layer &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>Se han encontrado {} elementos para la capa &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="2122"/>
        <source>Search result</source>
        <translation>Resultado de la búsqueda</translation>
    </message>
    <message>
        <location filename="../qgisce.py" line="2122"/>
        <source>No items found for layer &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>No se encontraron elementos para la capa &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="141"/>
        <source>Topology snapping enabled for layer %s</source>
        <translation>Se ha habilitado el snapping para la capa% s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/topology.py" line="440"/>
        <source>Edge id is %s for feature id %s</source>
        <translation>El identificador del Edge es %s para la característica id %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="130"/>
        <source>Dirty</source>
        <translation>Sucio</translation>
    </message>
    <message>
        <location filename="../qgisceutils/session.py" line="130"/>
        <source>Clean</source>
        <translation>Limpio</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="287"/>
        <source>Load layers from remote ERP server</source>
        <translation>Cargar las capas desde el servidor ERP remoto</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="325"/>
        <source>Waiting for main loader to stop subtasks ...</source>
        <translation>Se está esperando a que el cargador principal ature las subtareas ...</translation>
    </message>
    <message>
        <location filename="../qgisceutils/layer_loader.py" line="440"/>
        <source>AcotaciÃ³</source>
        <translation>Acotación</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="238"/>
        <source>Geometry change error</source>
        <translation>Error de cambio de geometría</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="239"/>
        <source>Impossible to change geometry for element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>No ha sido posible cambiar la geometría por el elemento.&lt;b&gt;{}&lt;/b&gt;en la capa &lt;b&gt;{}&lt;/b&gt;.Retrocediendo a los últimos cambios no guardados de la capa. Consulte los registros para más información.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="244"/>
        <source>Impossible to change geometry for element {} on layer {}</source>
        <translation>No ha sido posible cambiar la geometría por el elemento {} en la capa {}</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="309"/>
        <source>ERPSync value changed for layer %s on erp_id %s: %s</source>
        <translation>EPSync valor modificado en la capa %s con erp_id %s: %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="311"/>
        <source>Value change error</source>
        <translation>Error de cambio de valor</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="312"/>
        <source>Impossible to change values for element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>No ha sido posible cambiar los valores por el elemento &lt;b&gt;{}&lt;/b&gt; en la capa &lt;b&gt;{}&lt;/b&gt;.Retrocediendo a los últimos cambios no guardados de la capa. Consulte los registros para más información.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="317"/>
        <source>Impossible to change values for element {} on layer {}</source>
        <translation>No ha sido posible cambiar los valores por el elemento {} de la capa {}</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="354"/>
        <source>ERPSync DEFERRED feature_deleted %s erp_id is None, SKIPPING: fid %s</source>
        <translation>ERPSync DEFERRED feature_deleted %s erp_id es None, SKIPPING: fid %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="367"/>
        <source>ERPSync feature_deleted on layer %s fid: %s erp_id %s</source>
        <translation>ERPSync feature_deleted en la capa %s fid: %s erp_id %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="373"/>
        <source>Delete element error</source>
        <translation>Error al eliminar el elemento</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="374"/>
        <source>Impossible to delete element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>No ha sido posible eliminar el elemento &lt;b&gt;{}&lt;/b&gt; en la capa &lt;b&gt;{}&lt;/b&gt;.Retrocediendo a los últimos cambios no guardados de la capa. Consulte los registros para más información.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="379"/>
        <source>Impossible to delete element {} on layer {}</source>
        <translation>No ha sido posible eliminar el elemento {} en la capa {}</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="630"/>
        <source>ERPSync feature_added %s: erp_id: %s - %s</source>
        <translation>ERPSync feature_added %s: erp_id: %s - %s</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="637"/>
        <source>Error adding element</source>
        <translation>Error añadiendo el elemento</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="638"/>
        <source>Impossible to add element on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>No ha sido posible añadir el elemento en la capa &lt;b&gt;{}&lt;/b&gt;.Retrocediendo a los últimos cambios no guardados de la capa. Consulte los registros para más información.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="643"/>
        <source>Impossible to add element on layer {}</source>
        <translation>No ha sido posible añadir el elemento a la capa {}</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="701"/>
        <source>Error synchronizing the element</source>
        <translation>Error al sincronizar el elemento</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="702"/>
        <source>Impossible to synchronize the element &lt;b&gt;{}&lt;/b&gt; on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>No ha sido posible sincronizar el elemento &lt;b&gt;{}&lt;/b&gt; en la capa &lt;b&gt;{}&lt;/b&gt;.Retrocediendo a los últimos cambios no guardados de la capa. Consulte los registros para más información.</translation>
    </message>
    <message>
        <location filename="../qgisceutils/erp_sync.py" line="707"/>
        <source>Impossible to synchronize element {} on layer {}</source>
        <translation>No ha sido posible sincronizar el elemento {} en la capa {}</translation>
    </message>
    <message>
        <location filename="../qgiscegui/utils.py" line="104"/>
        <source>Could not zoom to feature with erp_id %s on layer %s</source>
        <translation>No se pudo hacer zoom al elemento con erp_id% s en la capa% s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/validation_results_widget.py" line="108"/>
        <source>Feature with id {} was not found on layer {}!</source>
        <translation>El elemento con id {} no ha sido encontrado en la capa {}!</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="214"/>
        <source>Error creating the element to the ERP</source>
        <translation>Error en crear el elemento en la ERP</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="218"/>
        <source>Impossible to create a new element on layer &lt;b&gt;{}&lt;/b&gt;. Rolling back the last unsaved changes of the layer. Check the logs for more information.</source>
        <translation>No ha sido posible crear un nuevo elemento en la capa &lt;b&gt;{}&lt;/b&gt;. Retrocediendo a los últimos cambios no guardados de la capa. Consulte los registros para más información.</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="223"/>
        <source>Impossible to create a new element on layer {}</source>
        <translation>No ha sido posible crear un nuevo elemento en la capa {}</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="227"/>
        <source>Error modifying the element to the ERP</source>
        <translation>Error en modificar el elemento en la ERP</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="228"/>
        <source>Impossible to modify the element on layer &lt;b&gt;{}&lt;/b&gt;. Changes had no effect. Check the logs for more information.</source>
        <translation>No ha sido posible modificar el elemento en la capa &lt;b&gt;{}&lt;/b&gt;. Los cambios no tuvieron ningún efecto. Consulte los registros para obtener más información.</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="233"/>
        <source>Impossible to modify the element on layer &lt;b&gt;{}&lt;/b&gt;.</source>
        <translation>No ha sido posible modificar el elemento en la capa &lt;b&gt;{}&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="182"/>
        <source>Validation errors</source>
        <translation>Errores de validación</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="182"/>
        <source>There were errors in the network validation, please check the validation results widget for details</source>
        <translation>Hubo errores en la validación de la red, Por favor consulte el widget de resultados de validación para obtener más información</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="189"/>
        <source>Validation warning</source>
        <translation>Aviso de validación</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="196"/>
        <source>The network validation was successfull, please check the validation results widget for details</source>
        <translation>La validación de la red se realizó correctamente, por favor consulte el widget de resultados de validación para obtener más detalles</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="196"/>
        <source>Validation ok</source>
        <translation>Validación ok</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/about_dialog.ui" line="27"/>
        <source>1.1.1</source>
        <translation>1.1.1</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.ui" line="51"/>
        <source>Available sessions</source>
        <translation>Sesiones disponibles</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/about_dialog.ui" line="34"/>
        <source>Changelog</source>
        <translation>Historial de cambios</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Diálogo</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/about_dialog.ui" line="78"/>
        <source>Do not show me again</source>
        <translation>No volver a mostrar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/about_dialog.ui" line="51"/>
        <source>QGISCE Plugin</source>
        <translation>Complemento QGISCE</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.ui" line="22"/>
        <source>Session name</source>
        <translation>Nombre de la sesión</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/about_dialog.ui" line="20"/>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/setup_dialog.ui" line="20"/>
        <source>Welcome to QGISCE plugin, please enter the connection configuration to the ERP backend in the form below and click &quot;Connect&quot; to check your connection.</source>
        <translation>Bienvenido al complemento QGISCE, p.f.v. configure la conexión con el ERP en el siguiente formulario, y clicke &quot;Conectar&quot; para verificar la conectividad.</translation>
    </message>
</context>
<context>
    <name>DockWidget</name>
    <message>
        <location filename="../qgiscegui/dialogs/validation_results_widget.ui" line="14"/>
        <source>DockWidget</source>
        <translation>DockWidget</translation>
    </message>
</context>
<context>
    <name>Form</name>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="145"/>
        <source>Connect</source>
        <translation>Conectar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="125"/>
        <source>Database</source>
        <translation>Base de datos</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="138"/>
        <source>Database name</source>
        <translation>Nombre de la base de datos</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="152"/>
        <source>Disconnect</source>
        <translation>Desconectar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="32"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="98"/>
        <source>Host</source>
        <translation>Host</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="68"/>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="118"/>
        <source>Port</source>
        <translation>Puerto</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="75"/>
        <source>Protocol</source>
        <translation>Protocolo</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="35"/>
        <source>User</source>
        <translation>Usuario</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="48"/>
        <source>Username</source>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="160"/>
        <source>http</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/erp_connection_widget.ui" line="165"/>
        <source>https</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="113"/>
        <source>&lt;h3&gt;Session Name&lt;/h3&gt;</source>
        <translation>&lt;h3&gt;Nombre Sesión&lt;/h3&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="248"/>
        <source>Created</source>
        <translation>Creada</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="292"/>
        <source>&lt;formated_creation_date&gt;, &lt;username&gt;</source>
        <translation>&lt;formated_creation_date&gt;, &lt;username&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="272"/>
        <source>(X time ago)</source>
        <translation>(X time ago)</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="285"/>
        <source>Last change</source>
        <translation>Última modificación</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="309"/>
        <source>(Y time ago)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="400"/>
        <source>Actions</source>
        <translation>Acciones</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="432"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Activate Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Sets this session as active Session (for security reasons, you are not able open two or more sessions simultaneously).&lt;/p&gt;

&lt;p&gt;When you activate the session, next actions occurs:&lt;/p&gt;
&lt;ul&gt;
	&lt;li&gt;Current open session will close.&lt;/li&gt;
	&lt;li&gt;Load the session data&lt;/li&gt;
	&lt;li&gt;Locate the viwer at last working zone&lt;/li&gt;
&lt;/ul&gt;
&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Activar la sesión&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Establecer esta sesión como sesión activa (por razones de seguridad, no es posible abrir dos o más sesiones simultáneamente).&lt;/p&gt;

&lt;p&gt;Cuando se activa la sesión, se producen las siguientes acciones:&lt;/p&gt;
&lt;ul&gt;
	&lt;li&gt;La sesión actual que se encuentra abierta se cerrará.&lt;/li&gt;
	&lt;li&gt;Los datos de la nueva sesión se cargarán.&lt;/li&gt;
	&lt;li&gt;La localización del lienzo sera la zona de trabajo de la nueva sesión.&lt;/li&gt;
&lt;/ul&gt;
&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="465"/>
        <source>Activate</source>
        <translation>Activar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="484"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Deactivate Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Turns this session inactive.&lt;/p&gt;

&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Desactivar la sesión&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Esta sesión pasará a estar inactiva.&lt;/p&gt;

&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="514"/>
        <source>Deactivate</source>
        <translation>Desactivar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="524"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Edit Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;You can edit name and session extesion.&lt;/p&gt;

&lt;ul&gt;
	&lt;li style=&quot;color: #844&quot;&gt;NOTE: this option is only available for &lt;b&gt;Closed&lt;/b&gt; sessions.&lt;/li&gt;
&lt;/ul&gt;
&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Editar la sesión&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Se podrá editar el nombre y la extensión de la sesión.&lt;/p&gt;

&lt;ul&gt;
	&lt;li style=&quot;color: #844&quot;&gt;NOTA: Esta opción está solo disponible para las sesiones que se encuentran &lt;b&gt;Cerradas&lt;b/&gt;.&lt;/li&gt;
&lt;/ul&gt;
&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="554"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="564"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Commit Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Merges and consolidates this session with information base.&lt;/p&gt;

&lt;ul&gt;
	&lt;li style=&quot;color: #844&quot;&gt;NOTE: &lt;b&gt;This action is not revesible.&lt;/b&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Aplicar la sesión&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Aplica y consolida las modificaciones de la sesión con los datos de producción.&lt;/p&gt;

&lt;ul&gt;
	&lt;li style=&quot;color: #844&quot;&gt;NOTA: &lt;b&gt;Esta acción no es reversible.&lt;/b&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="594"/>
        <source>Commit</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="610"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}

&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Discard Session&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;This session will be removed from sessions list&lt;/p&gt;

&lt;ul&gt;
	&lt;li style=&quot;color: #844&quot;&gt;Be aware: &lt;b&gt;All session changes will be lost. This action is not revesible.&lt;/b&gt;&lt;/li&gt;
&lt;/ul&gt;

&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;
&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
body {
	font-family:&apos;Ubuntu&apos;; 
	font-size:11pt; 
	font-weight:400; 
	font-style:normal;
	margin: 10px;
	color: #000;
}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}

&lt;/style&gt;
&lt;/head&gt;
&lt;body &gt;

&lt;h2&gt;Descartar la sesión&lt;/h2&gt;

&lt;p style=&quot;color: #444;&quot; &gt;Esta sesión será eliminada de la lista de sesiones.&lt;/p&gt;

&lt;ul&gt;
	&lt;li style=&quot;color: #844&quot;&gt;Alerta: &lt;b&gt;Todos los cambios que se han efectuado en esta sesión se perderán. Esta acción no es reversible.&lt;/b&gt;&lt;/li&gt;
&lt;/ul&gt;

&lt;p/&gt;
&lt;/body&gt;
&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.ui" line="649"/>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
</context>
<context>
    <name>FormFeatureDialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/form_feature_dialog.py" line="66"/>
        <source>QGISCE Form Dialog </source>
        <translation>Diálogo de formulario de QGISCE </translation>
    </message>
</context>
<context>
    <name>MessageBarProgressItem</name>
    <message>
        <location filename="../qgiscegui/message_bar_progress.py" line="48"/>
        <source>Abort</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>PluginDependenciesDialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="42"/>
        <source>Action</source>
        <translation>Acción</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="42"/>
        <source>Available</source>
        <translation>Disponible</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="42"/>
        <source>Installed</source>
        <translation>Instalado</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="42"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="38"/>
        <source>QGISCE Plugin Dependencies Manager</source>
        <translation>Administrador de las dependencias del complemento QGISCE</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/plugin_dependencies_dialog.py" line="42"/>
        <source>Required</source>
        <translation>Necesario</translation>
    </message>
</context>
<context>
    <name>QGISCEDialogBase</name>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="105"/>
        <source>Activate debug mode</source>
        <translation>Activar el modo de depuración</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="67"/>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="99"/>
        <source>Debug</source>
        <translation>Debug</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="79"/>
        <source>DSN</source>
        <translation>DSN</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="89"/>
        <source>Enable</source>
        <translation>Activar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="24"/>
        <source>ERP connection configuration</source>
        <translation>Configuración de la conexión con el ERP</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/qgisce_dialog_base.ui" line="35"/>
        <source>ERP Model</source>
        <translation>Modelo del ERP</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/qgisce_dialog_base.ui" line="22"/>
        <source>ERP MODEL LOADER</source>
        <translation>MODELOS DE ERP</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="115"/>
        <source>Identify</source>
        <translation>Identificar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/qgisce_dialog_base.ui" line="59"/>
        <source>Load Catalog</source>
        <translation>Cargar catálogo</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/qgisce_dialog_base.ui" line="52"/>
        <source>Open Model Form</source>
        <translation>Abrir formulario</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="37"/>
        <source>Project settings</source>
        <translation>Configuación del proyecto</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="14"/>
        <source>QGISCE</source>
        <translation>QGISCE</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="131"/>
        <source>Search radius in pixels</source>
        <translation>Radio de búsqueda (píxeles)</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="73"/>
        <source>Sentry</source>
        <translation>Sentry</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="59"/>
        <source>Set QGISCE project as default</source>
        <translation>Establecer el proyecto de QGISCE por defecto</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/qgisce_dialog_base.ui" line="45"/>
        <source>Type the model to show</source>
        <translation>Introduzca el modelo a mostrar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="46"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This function makes a copy of the plugin&apos;s provided project template and setup QGIS to always start with that project. &lt;/p&gt;&lt;p&gt;The project is also configured to automatically load the full catalog at start.&lt;/p&gt;&lt;p&gt;To disable this function, you can set a different option in QGIS global options dialog under &lt;span style=&quot; font-weight:600;&quot;&gt;General → Project files&lt;/span&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Esta función crea una copia de la plantilla del proyecto proporcionada por el complemento y configura el QGIS para que este siempre abra este proyecto una vez encendido.&lt;/p&gt;&lt;p&gt;Además, también se configurará el proyecto para que sea possible cargar el catálogo completo.&lt;/p&gt;&lt;p&gt;Para desactivar esta función, puede seleccionar otra opción en el diálogo de opciones globales del QGIS debajo de &lt;span style=&quot; font-weight:600;&quot;&gt;General → Ficheros del proyecto&lt;/span&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/manual_download_dialog.ui" line="25"/>
        <source>Download all catalog data for the selected extent (default to current canvas extent)</source>
        <translation>Descargar todos los datos del catálogo de la extensión seleccionada (por defecto a la extensión actual del lienzo)</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="141"/>
        <source>Multiform</source>
        <translation>Multiformularios</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="147"/>
        <source>This parameter defines the maximum number of forms that will be opened simultaneously</source>
        <translation>Este parámetro define el número máximo de formularios que se abrirán simultáneamente</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="164"/>
        <source>Download</source>
        <translation>Descarga</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="170"/>
        <source>Select a download mode</source>
        <translation>Selecciona un modo de descarga</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="178"/>
        <source>Sequential</source>
        <translation>Secuencial</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="183"/>
        <source>Multithread</source>
        <translation>Multihilo</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/dialog_config.ui" line="198"/>
        <source>Threads</source>
        <translation>Hilos</translation>
    </message>
</context>
<context>
    <name>SessionChangesModel</name>
    <message>
        <location filename="../qgiscegui/session_changes_model.py" line="38"/>
        <source>Unsaved changes</source>
        <translation>Cambios sin guardar</translation>
    </message>
    <message>
        <location filename="../qgiscegui/session_changes_model.py" line="40"/>
        <source>Saved changes</source>
        <translation>Cambios guardados</translation>
    </message>
</context>
<context>
    <name>SessionChangesReportDialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/session_changes_report_dialog.py" line="41"/>
        <source>QGISCE session </source>
        <translation>Sesión del QGISCE </translation>
    </message>
</context>
<context>
    <name>SessionChangesWidget</name>
    <message>
        <location filename="../qgiscegui/dialogs/session_changes_widget.py" line="43"/>
        <source>QGISCE session changes</source>
        <translation>Cambios de la sesión del QGISCE</translation>
    </message>
</context>
<context>
    <name>SessionCreateDialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="182"/>
        <source>A session must have a name</source>
        <translation>Es necesario definir un nombre para la sesión</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="185"/>
        <source>A session with this name already exists</source>
        <translation>Ya existe una sesión con este nombre</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="174"/>
        <source>Could not parse the CRS descriptor: %s</source>
        <translation>No se ha podido identificar el descriptor CRS: %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="170"/>
        <source>Empty BBOX from the CRS descriptor: %s</source>
        <translation>BBOX vacía al importar el descriptor CRS: %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="172"/>
        <source>Error parsing BBOX from the CRS descriptor: %s</source>
        <translation>Error identificando el BBOX utilizando el descriptor CRS: %s</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="65"/>
        <source>QGISCE session creation</source>
        <translation>Creación de sesión del QGISCE</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="70"/>
        <source>Select extent</source>
        <translation>Seleccionar zona del mapa</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_create_dialog.py" line="177"/>
        <source>You must select the extent for this session</source>
        <translation>Es necesario seleccionar la zona del mapa para la sessión</translation>
    </message>
</context>
<context>
    <name>SessionItem</name>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="89"/>
        <source>Today</source>
        <translation>Hoy</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="91"/>
        <source>Yesterday</source>
        <translation>Ayer</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="93"/>
        <source>{days} days ago.</source>
        <translation>Hace {days} días.</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="128"/>
        <source>Non active session</source>
        <translation>Sesión no activa</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="128"/>
        <source>You want to edit session &lt;b&gt;{session_name}&lt;/b&gt; which is a 
                non active session. &lt;br/&gt;&lt;br/&gt; In order to edit this session You 
                need to activate it previously, and then you can edit it.</source>
        <translation>Se quiere activar la sesión &lt;b&gt;{session_name}&lt;/b&gt; que es una 
                sesión no activa. &lt;br/&gt;&lt;br/&gt; Para que sea posible poder editar la sesión 
                es necesario activarla préviamente, para así poderla activar.</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="176"/>
        <source>Active Session</source>
        <translation>Sesión activa</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="212"/>
        <source> by user </source>
        <translation> por el usuario </translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/components/session_item.py" line="218"/>
        <source>Not modified yet.</source>
        <translation>Todavía no se ha modificado.</translation>
    </message>
</context>
<context>
    <name>SessionManagerDialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="169"/>
        <source>Discard session</source>
        <translation>Descartar session</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="169"/>
        <source>Do you really want to discard session &lt;b&gt;%s&lt;/b&gt;?</source>
        <translation>Realmente quiere descartar la sessión &lt;b&gt;%s&lt;/b&gt;?</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="59"/>
        <source>New session</source>
        <translation>Nueva sesión</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="51"/>
        <source>QGISCE sessions manager</source>
        <translation>Gestor de sesiones de QGISCE</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="85"/>
        <source>Save modifications</source>
        <translation>Guardar modificaciones</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="85"/>
        <source>There are unsaved modifications to the following layers:&lt;ul&gt;&lt;li&gt;%s&lt;/li&gt;&lt;/ul&gt;all session changes will be lost.&lt;br&gt;Do you want to save them now?</source>
        <translation>Hay cambios pendientes de guardar en las siguientes capas:&lt;ul&gt;&lt;li&gt;%s&lt;/li&gt;&lt;/ul&gt;se perderán todos los cambios de la sesión.&lt;br&gt;¿Desea guardar los cambios pendientes?</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/session_manager_dialog.py" line="191"/>
        <source>Merge session</source>
        <translation>Aplicar la sesión</translation>
    </message>
</context>
<context>
    <name>SetupDialog</name>
    <message>
        <location filename="../qgiscegui/dialogs/setup_dialog.py" line="35"/>
        <source>QGISCE setup</source>
        <translation>Configuración de QGISCE</translation>
    </message>
</context>
<context>
    <name>ValidationResultsModel</name>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="174"/>
        <source>Validated</source>
        <translation>Validado</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="163"/>
        <source>Is supplied</source>
        <translation>Está subministrada</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="139"/>
        <source>Is connected</source>
        <translation>Está conectada</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="174"/>
        <source>True</source>
        <translation>Si</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="60"/>
        <source>False</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="66"/>
        <source>Errors</source>
        <translation>Errores</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="111"/>
        <source>Name: {}</source>
        <translation>Nombre: {}</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="115"/>
        <source>ID: {}</source>
        <translation>ID: {}</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="119"/>
        <source>Right-click for zoom to element</source>
        <translation>Clic derecho para hacer zoom al elemento</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="127"/>
        <source>Critical</source>
        <translation>Críticos</translation>
    </message>
    <message>
        <location filename="../qgiscegui/validation_results_model.py" line="151"/>
        <source>Warning</source>
        <translation>Avisos</translation>
    </message>
</context>
<context>
    <name>ValidationResultsWidget</name>
    <message>
        <location filename="../qgiscegui/dialogs/validation_results_widget.py" line="45"/>
        <source>QGISCE validation results</source>
        <translation>Resultados de validación de QGISCE</translation>
    </message>
    <message>
        <location filename="../qgiscegui/dialogs/validation_results_widget.py" line="69"/>
        <source>Zoom to element</source>
        <translation>Zoom al elemento</translation>
    </message>
</context>
<context>
    <name>session_changes_widget</name>
    <message>
        <location filename="../qgiscegui/dialogs/session_changes_widget.ui" line="14"/>
        <source>DockWidget</source>
        <translation>DockWidget</translation>
    </message>
</context>
</TS>
